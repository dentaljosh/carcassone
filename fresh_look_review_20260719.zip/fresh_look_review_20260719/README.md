# Fresh-Look Review — Superhuman Carcassonne AI (2026-07-19)

> **What this is.** A self-contained packet for an outside reviewer taking a **first-principles
> fresh look** at a game-AI project at a fork in the road. It supersedes all prior review packets
> (2026-06-07, 06-21, 06-29, 07-01, 07-05 ×2).
>
> **The situation, in six sentences.** For ~13 weeks we have been building toward genuinely
> superhuman 2-player Carcassonne, ideally via a self-learning flywheel. Through early July every
> route to make *learned* components carry strength past a hand-crafted baseline ended in a null,
> a crater, or a parity — and by mid-July the classical side (leaf terms, search knobs) had closed
> null too. In the four days before this packet, a differently-designed flywheel was built, ran 17
> self-play iterations unattended over ~25 hours, and briefly appeared to produce the project's
> first real self-play growth — a decisive win over a fixed out-of-lineage anchor. The
> pre-registered follow-ups then **refuted that claim the next morning**: the gain failed
> replication on fresh decks, and it vanishes at production search depth; what survived is that
> the flywheel *held* its teacher's tier (a distilled net that exactly ties the hand-crafted
> champion at full budget) without exceeding it. So the project has a new, faithful, learned
> replica of its champion, a freshly-falsified growth signal, and no obviously-live lever. Before
> we choose what to do with that, we want fresh eyes with no inherited narrative: **where should
> this head next, and what have we missed?**
>
> **This packet is deliberately structured to protect your independence.** You are asked NOT to
> start from our framing (nor from the four prior reviews' — they are deliberately excluded). Form
> your own diagnosis from the goal, the game, the system description, and the **actual source
> code** (`phase1/`) — *before* you read what we tried (`phase2/`) or what we concluded
> (`phase3/`).

---

## How to run this review in one shot

**Paste [KICKOFF_PROMPT.md](KICKOFF_PROMPT.md) as the first message to a fresh AI agent that has
file access** (claude.ai with code execution enabled + this zip attached; or Claude Code / any
agent pointed at the unzipped directory). The kickoff prompt drives all phases autonomously; the
directory structure makes the blindness real (an agent cannot see a file it hasn't read, and its
read log is the audit trail). A human reviewer follows the same order manually.

Plain chat without file access cannot run this honestly — the model would see every phase at once.

## The phase protocol

**Phase 1 — blind diagnosis.** Read ONLY [phase1/](phase1/):
[A_GOAL_AND_GAME.md](phase1/A_GOAL_AND_GAME.md) →
[B_SYSTEM_DESCRIPTION.md](phase1/B_SYSTEM_DESCRIPTION.md) → the source code in
[phase1/code/](phase1/code/). Write down, before proceeding: every design decision that strikes
you as non-standard/risky/wrong for the goal; where you predict the strength ceiling comes from;
what you would build instead; the five cheapest decisive measurements.

**Phase 2 — collision with the record.** Now read
[phase2/C_EXPERIMENT_RECORD.md](phase2/C_EXPERIMENT_RECORD.md) (every experiment, its measured
result, the team's call kept separate — including the last four days' flywheel run, its apparent
breakout, and the pre-registered follow-ups that refuted it) and dig into
[phase2/sources/](phase2/sources/) as needed. For
each Phase-1 suspect: fairly killed / tested inadequately / never tested. Then write your
complete, final report.

**Phase 3 — the team's own conclusions and open questions, last, as an addendum only.** The
reviewer's report is **finalized at the end of Phase 2, before our conclusions are ever visible**
— so our doubts cannot anchor their recommendations. Only then read
[phase3/APPENDIX_TEAM_SELF_CRITIQUE.md](phase3/APPENDIX_TEAM_SELF_CRITIQUE.md) and append a
labeled addendum: verdicts on our doubts, answers to our open decision questions, anything on
**neither** list, and explicit amendments (never silent rewrites) if our appendix genuinely
changes one of your conclusions.

Deliverables spec: [REVIEWER_PROMPT.md](REVIEWER_PROMPT.md).

## Packet contents

| item | role | phase |
|---|---|---|
| [KICKOFF_PROMPT.md](KICKOFF_PROMPT.md) | the one-shot prompt that runs the whole review | — |
| [REVIEWER_PROMPT.md](REVIEWER_PROMPT.md) | role, deliverables, ground rules (no results inside) | 0 |
| [phase1/A_GOAL_AND_GAME.md](phase1/A_GOAL_AND_GAME.md) | goal, scope, resources, Carcassonne primer | 1 |
| [phase1/B_SYSTEM_DESCRIPTION.md](phase1/B_SYSTEM_DESCRIPTION.md) | neutral description of the system as built (incl. the current production agent and the new flywheel mechanism) | 1 |
| [phase1/code/](phase1/code/) | the 15 load-bearing source files, verbatim (~370KB) | 1 |
| [phase2/C_EXPERIMENT_RECORD.md](phase2/C_EXPERIMENT_RECORD.md) | complete factual experiment history through 2026-07-19 (the flywheel arc closed) | 2 |
| [phase2/sources/](phase2/sources/) | primary evidence: verdict docs, pre-registered plans, run narratives, governance CSVs, results subset, the final curve snapshot | 2 |
| [phase3/APPENDIX_TEAM_SELF_CRITIQUE.md](phase3/APPENDIX_TEAM_SELF_CRITIQUE.md) | the team's conclusions, its open decision questions, and its own steelmen | 3 |
| [MANIFEST.json](MANIFEST.json) | machine-readable manifest | — |

## Provenance

Repo branch `rod_v2_flywheel`, packet date 2026-07-19 (first assembled ~01:00 EDT with follow-up
evaluations mid-run; **refreshed ~12:30 EDT the same day after those pre-registered follow-ups
completed and closed the arc** — the packet reflects the final verdict). Code files are verbatim
copies from the repo at packet time. Every number in the record cites a file under
`phase2/sources/` or a named row in `phase2/sources/results_csv_relevant_rows.csv`; the full
final growth-curve tallies (re-verified against the raw per-game records on disk) are in
[phase2/sources/curve_snapshot_20260719.txt](phase2/sources/curve_snapshot_20260719.txt). No
experiments were run to build this packet. Nothing has been promoted: the production champion and
`PRODUCTION.yaml` are unchanged through the entire flywheel arc.
