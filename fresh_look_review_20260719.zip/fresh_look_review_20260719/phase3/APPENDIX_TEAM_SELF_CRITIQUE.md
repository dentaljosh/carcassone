# Appendix — The Team's Own Conclusions, Open Questions, and Self-Critique (2026-07-19, post-close-out)

> **Phase-3 material. Do not read until your Phase-1 (blind diagnosis) and Phase-2 (collision with
> the record) outputs are written.** This exists so you can (a) audit our reasoning, (b) answer
> the decision questions we are actually facing, and (c) find what appears on **neither** your
> list nor ours.

## The team's current conclusions (all interpretation)

1. **The classical improvement program is exhausted except for raw depth.** Leaf terms (C7),
   search knobs (T3), and determinization width (k_dets) all closed in a two-week squeeze — two
   powered nulls and one cost-neutral fold. The one demonstrated open classical lever is deeper
   fair search (the fair ladder scales through 5504 sims without saturating), which is a pure
   compute price.
2. **The flywheel arc closed with a retraction, and we believe the retraction.** The it16 "+88.7
   breakout" failed its pre-registered fresh-deck replication (−3.5 on 100 fresh decks, cross-band
   z=2.60) while the it20 control replicated; it also washes out to +1.7 (z=0.07) at production
   depth on the same decks. This is the third documented winner's-curse collapse in the project
   (c=3 "+47", t020 "+32", now it16 "+88.7") and it followed the identical statistical shape:
   a selected maximum killed by extension. We retracted the growth claim the same morning.
3. **What survived is real and, we think, under-weighted by the drama around the spike:** the
   first fair-trained net lineage, whose distilled policy priors **exactly tie the production
   champion at full budget** (100-100-0), and 17 self-play iterations that **held** that tier as
   a noisy tie-band — no crater, no drift. Every previous flywheel either collapsed or was never
   at tier. "Faithful, durable, not superior" is the arc's deliverable.
4. **Depth-washout is now a law of this project until shown otherwise.** Twice, independently
   (deepteacher 06-17; the it16 washout 07-19), policy-prior gains present at shallow search
   vanished at deep search. Any future learned-strength claim graded at low sims is provisional
   by construction.
5. **The pre-registration discipline worked as designed** — the continuation bar, the Plan-B
   branch, and the extension were all specified before their results landed, and each fired
   against our hopes. We note this not as self-congratulation but because the review should
   audit whether the *bars themselves* were well-chosen, not whether we honored them.
6. **The two structural blockers to the superhuman goal stand unchanged:** (a) no non-saturated
   external reference exists — every number is internal, and internal rulers have lied in every
   way we've now catalogued (circularity, clairvoyance leak, winner's curse); (b) the goal as the
   charter framed it needs learned components to exceed the v2.7/v2.9 heuristic family, which has
   still never happened at production depth — the amended CL-058 names exactly this ("exceed the
   anchor at production depth") as the open problem.

## The open decision questions (we ask you to answer these; we are deliberately not stating our leanings)

- **Q1 — what is the arc's lesson.** Given a flywheel that holds tier but does not grow, what is
  the correct causal reading — which ingredient(s) explain "held without collapsing", and is that
  fact strategically valuable or a dead end dressed up?
- **Q2 — restart or not.** Training is paused, resumable from iter_20.pt at ~78 min/iteration.
  Under what hypothesis, if any, would resuming iterations be worth the compute — and what
  measurement design would make a restart falsifiable rather than hopeful?
- **Q3 — stage-3 value-unlock.** The value head is currently severed and search value is the
  frozen champion leaf. Un-freezing/blending the learned value was the designed "stage 3" and is
  the one flywheel variant that attacks depth-robust strength rather than shallow policy gains —
  but every prior learned-value integration in this project cratered or tied. Should stage-3 run,
  in what form, and with what kill-bar?
- **Q4 — what (if anything) to ablate.** The 7 design levers were enumerated to explain a growth
  effect that no longer exists. Is any ablation still worth running (e.g., to attribute
  "held-tier-without-collapse", or to de-risk a future recipe), or is ablation spend now moot?
- **Q5 — the depth-washout mechanism.** Twice-replicated but never explained: why do shallow
  policy-prior gains vanish under deep search here? Is the mechanism worth identifying before any
  further learned-policy spend, and what is the cheapest experiment that would identify it?
- **Q6 — the measurement gap.** The standing blocker: no non-saturated external reference; no
  human anchor; internal rulers have failed in every catalogued way. What reference should exist
  before the next major promotion or spend, and is the human exam now overdue?
- **Q7 — anything we haven't thought of.** The reason this packet exists.

## The team's own doubts (written before your review)

- **Did we over-trust the band even after the correction?** The whole 8-point curve lives on one
  seed band (13.0e9); the extension used one other (13.2e9). Two bands resolve the it16 question,
  but per-band deck-luck at n=200 (±24.6 elo 1σ) is large relative to every effect we chased this
  arc. Doubt: our screening cadence (n=200 per point) may be structurally incapable of seeing
  the ~+10–20 elo effects that would actually matter at this stage — in which case the honest
  reading of the whole curve is "under-powered throughout," not "flat."
- **The anchor is mid-tier and shares our ecosystem.** rodv2_iter02 is a checkpoint of a dead
  in-house lineage, chosen for eval speed. "Held anchor tier" and "no growth vs the anchor" are
  claims about that anchor at k2×200 — not about the champion, and not about an external
  reference. (The one champion-referenced number, the stage-1 tie, is the arc's most solid fact.)
- **The ¼-budget gen choice was never cleared for this outcome.** We pre-agreed a NULL at sims200
  would be ambiguous (gen search possibly too weak to out-search the net's own distilled priors →
  no learning gradient). The final verdict IS a null — so by our own pre-registration logic it is
  ambiguous between "the flywheel can't grow" and "gen was too shallow to teach." The ½-budget
  escalation (k4×344) that the protocol prescribed for a null was never run.
- **"Held tier" may be less impressive than we present it.** The net was initialized as a faithful
  copy of the champion and trained on its own near-champion-quality games; not collapsing might be
  the expected behavior of any sufficiently-regularized loop at this horizon, not a design
  achievement of the 7 levers.
- **The severed value loop is untested in the direction that now matters.** It was designed to
  prevent the value-driven collapses of prior flywheels — and no collapse happened. But the
  amended open problem (exceed at production depth) is exactly where a *value* signal, not a
  policy prior, would have to carry the weight; the recipe that kept us safe may be the recipe
  that capped us.
- **Equal-sims vs equal-compute.** The net costs ~2.2×/move. Even the "tie" deliverable is an
  equal-sims tie; at equal wall-clock the champion gets ~2.2× sims (~+70–80 elo on the fair
  ladder). Deployment-honest pricing of the distilled net remains unflattering and unmeasured
  head-on.
- **The human anchor is still missing, and it is now purely operational.** The champion plays
  fair, runs on consumer hardware, and no code blocks a humans-vs-agent pilot. Every
  "superhuman?" judgment remains unmeasured while we spend on internal probes. If the classical
  champion is *already* superhuman, the strength program's framing inverts; if it is far below
  expert humans, the internal ladder has been lying about scale. Nothing in the project can
  currently distinguish these worlds — and we keep deferring the one measurement that could.

## Levers the team believes are genuinely dead (challenge only if a kill looks premature)

Learned value driving the MCTS leaf *at this scale* (weaned/convex/additive/frozen ×
scalar/structured × clairvoyant/fair × MSE/ranking, incl. the canonical sighted cell with FPU fix,
killed on the exact solver; plus the fair pooled-Q replacement and residual redo, CL-049/050) ·
weak-teacher / clairvoyant policy distillation (killed twice powered) · **strong-teacher fair
policy distillation as a *strength* lever** (the C.9 arc: faithful tie, held tier, no robust
growth at any iteration or depth — killed by pre-registered replication + washout; the *artifact*
it produced, the tie-tier fair net, remains) · shallow-graded policy gains as evidence of deep
strength (washout, twice) · classical leaf terms beyond curve125 (C7) · classical search-knob
tuning (T3, winner's-curse-guarded) · full-game alpha-beta (no fair form) · Gumbel top-m at our
sims · ML compute schedulers · relational/GNN heads · symmetry augmentation · solver-screen-driven
leaf tuning (v2.10) · deeper exact endgame as a *winrate* lever · external bot anchors (none exist
at usable strength).
