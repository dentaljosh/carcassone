"""AlphaZero-style Game wrapper around the wingedsheep Carcassonne engine.

Mirrors alpha-zero-general's Game.py method names so a Coach/Arena port is
trivial later, but does NOT inherit from it (its API assumes 2D board arrays).

Scope (2026-06-02 onward): 2 players, BASE tile set only, FARMERS supplementary
rule. River was DROPPED 2026-06-02 (competitive / world-championship play is
base-only; River is a non-scoring setup variant) — see DECISIONS.md. No Inns &
Cathedrals, no Abbots, no Big meeples. The engine still supports THE_RIVER if a
caller passes it explicitly, but production self-play/eval/training is base-only.

Window size is configurable via Game(window_size=...). Default is 25 based on
Phase 0 random-game measurements, but can be changed at construction time
without code changes if Phase 4 reveals 25 is wrong.
"""
from __future__ import annotations

import argparse
import math
import os
import random
import sys
from dataclasses import dataclass, field
from multiprocessing import Pool

import numpy as np

from wingedsheep.carcassonne.carcassonne_game_state import CarcassonneGameState
from wingedsheep.carcassonne.tile_sets.supplementary_rules import SupplementaryRule
from wingedsheep.carcassonne.tile_sets.tile_sets import TileSet
from wingedsheep.carcassonne.utils.action_util import ActionUtil
from wingedsheep.carcassonne.utils.state_updater import StateUpdater

from .action_space import (
    DEFAULT_WINDOW_SIZE,
    WindowOffset,
    WindowOverflowError,
    action_size,
    decode,
    encode,
)
from .board_repr import (
    N_CHANNELS,
    board_overflows_window,
    canonical_swap,
    centroid_sums,
    compute_window_offset,
    encode_board,
    offset_from_centroid_sums,
)
from wingedsheep.carcassonne.objects.actions.tile_action import TileAction
from .eta import measure_one, print_banner
from .features import N_FARM_SCALARS, N_SCALAR_FEATURES, encode_scalars


SCORE_NORM_SCALE = 15.0  # see DECISIONS.md (validated against 1000 random games)


# --- Window-overflow audit (measurement-only, DEFAULT OFF) -------------------
# Phase 0.2 post-review measurement. `get_valid_moves` already computes
# n_total / n_overflow (how many legal actions the centered window drops) but
# exposes them nowhere, and `encode_board` silently skips placed tiles outside
# the window. When CARCASSONNE_WINDOW_AUDIT=1, `get_valid_moves` appends one
# per-decision record to `_WINDOW_AUDIT_LOG` so an offline replay can quantify
# both effects. When the env var is unset (the default) the audit block is
# skipped entirely — the mask, the raise condition, and every leaf/eval
# semantic are byte-for-byte identical to before this change (asserted in the
# audit script by confirming the log stays empty with the flag off). This is
# read-only instrumentation: it NEVER alters the returned mask.
_WINDOW_AUDIT = os.environ.get("CARCASSONNE_WINDOW_AUDIT", "0") == "1"
_WINDOW_AUDIT_LOG: list = []

# --- Legal-cache collision detector (Phase 0.3, DEFAULT OFF) -----------------
# When CARCASSONNE_CACHE_COLLIDE_CHECK=1, every legal-moves-cache HIT recomputes
# the mask fresh and, if it disagrees with the cached one, logs a full repro
# (two distinct boards sharing one `string_representation` key) to
# CARCASSONNE_CLIP_TRACE_DIR/cache_collision_<pid>.jsonl. Read-only diagnostic:
# it returns the FRESH (correct) mask on a detected collision so the run is not
# itself corrupted, but the mask/raise semantics are otherwise unchanged.
_CACHE_COLLIDE_CHECK = os.environ.get("CARCASSONNE_CACHE_COLLIDE_CHECK", "0") == "1"


def _state_fingerprint(state) -> dict:
    """A DEEP fingerprint of the engine state — captures fields that
    `string_representation` may omit, so a collision's two boards can be diffed
    to find the missing key component. Diagnostic-only."""
    def _tile_full(t):
        if t is None:
            return None
        from wingedsheep.carcassonne.objects.side import Side
        farms = []
        for fc in getattr(t, "farms", ()) or ():
            farms.append({
                "farmer_positions": [getattr(s, "value", str(s)) for s in fc.farmer_positions],
                "tile_connections": [getattr(s, "value", str(s)) for s in fc.tile_connections],
                "city_sides": [getattr(s, "value", str(s)) for s in fc.city_sides],
            })
        return {
            "desc": t.description,
            "edges": [t.get_type(s).value for s in (Side.TOP, Side.RIGHT, Side.BOTTOM, Side.LEFT)],
            "shield": bool(t.shield), "chapel": bool(t.chapel), "flowers": bool(t.flowers),
            "farms": farms,
        }
    placed = []
    for coord in sorted(state.placed_coords, key=lambda c: (c.row, c.column)):
        placed.append((coord.row, coord.column, _tile_full(state.board[coord.row][coord.column])))
    meeples = []
    for p, lst in enumerate(state.placed_meeples):
        for mp in lst:
            cws = mp.coordinate_with_side
            meeples.append({
                "player": p, "type": mp.meeple_type.value,
                "row": cws.coordinate.row, "col": cws.coordinate.column,
                "side": cws.side.value, "repr": repr(mp),
            })
    lta = state.last_tile_action
    return {
        "phase": state.phase.value,
        "current_player": state.current_player,
        "scores": list(state.scores),
        "meeples_hand": list(state.meeples),
        "abbots": list(getattr(state, "abbots", []) or []),
        "deck_len": len(state.deck),
        "deck_order": [t.description for t in state.deck],
        "next_tile": _tile_full(state.next_tile),
        "last_tile_action_repr": repr(lta),
        "last_tile_coord": (
            (lta.coordinate.row, lta.coordinate.column) if lta is not None else None
        ),
        "last_tile_full": (_tile_full(getattr(lta, "tile", None)) if lta is not None else None),
        "placed": placed,
        "meeples_placed": meeples,
    }


def _log_cache_collision(game, board, key, cached_mask, fresh_mask) -> None:
    import hashlib
    import json
    import time
    d = os.environ.get("CARCASSONNE_CLIP_TRACE_DIR")
    cached_legal = sorted(int(i) for i in np.flatnonzero(cached_mask))
    fresh_legal = sorted(int(i) for i in np.flatnonzero(fresh_mask))
    this_fp = _state_fingerprint(board.state)
    other_fp = getattr(game, "_collide_shadow", {}).get(key)
    # Field-level diff of the two colliding boards' fingerprints.
    fp_diff = {}
    if other_fp is not None:
        for k in set(this_fp) | set(other_fp):
            if this_fp.get(k) != other_fp.get(k):
                fp_diff[k] = {"hit_board": this_fp.get(k), "cached_board": other_fp.get(k)}
    rec = {
        "ts": time.time(),
        "pid": os.getpid(),
        "key": key,
        "key_hash": hashlib.blake2b(key.encode(), digest_size=8).hexdigest(),
        "board_offset": [board.offset.origin_row, board.offset.origin_col, board.offset.size],
        "phase": board.state.phase.value,
        "cur_player": board.state.current_player,
        "cached_legal": cached_legal,
        "fresh_legal": fresh_legal,
        "cached_minus_fresh": sorted(set(cached_legal) - set(fresh_legal)),
        "fresh_minus_cached": sorted(set(fresh_legal) - set(cached_legal)),
        "has_other_board": other_fp is not None,
        "fingerprint_diff_fields": sorted(fp_diff.keys()),
        "fingerprint_diff": fp_diff,
    }
    if d:
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, f"cache_collision_{os.getpid()}.jsonl"), "a") as fh:
            fh.write(json.dumps(rec) + "\n")


def window_audit_enabled() -> bool:
    """True iff CARCASSONNE_WINDOW_AUDIT=1 was set at import time."""
    return _WINDOW_AUDIT


def drain_window_audit() -> list:
    """Return the accumulated per-decision audit records and clear the buffer.

    Each record is a dict:
      phase           'tiles' | 'meeples'
      n_total         legal actions the engine emitted at this decision
      n_overflow      how many of those the centered window dropped
      k_remaining     tiles left to place (total_tiles - tile_count); stage proxy
      n_oow_tiles     placed tiles outside the window (what encode_board skips)
      window_size     live window edge length (board.offset.size)
    """
    global _WINDOW_AUDIT_LOG
    out = _WINDOW_AUDIT_LOG
    _WINDOW_AUDIT_LOG = []
    return out


def _count_out_of_window_tiles(state, off) -> int:
    """Count placed tiles outside the centered window — exactly the tiles
    `encode_board` / `get_canonical_form` silently skip. Read-only; used only by
    the audit block (mirrors board_repr.board_overflows_window but counts)."""
    n = 0
    origin_row, origin_col, size = off.origin_row, off.origin_col, off.size
    for r, row in enumerate(state.board):
        for c, tile in enumerate(row):
            if tile is None:
                continue
            wr, wc = r - origin_row, c - origin_col
            if not (0 <= wr < size and 0 <= wc < size):
                n += 1
    return n


@dataclass
class Board:
    """Container for engine state plus the cached window offset.

    Mutating helpers return new Board instances; the underlying engine state
    is deep-copied to keep MCTS rollouts independent.
    """

    state: CarcassonneGameState
    total_tiles: int
    offset: WindowOffset
    # Incremental centroid tracker for the window offset. The offset centers the
    # window on the centroid of placed tiles; instead of re-scanning the whole
    # 35x35 board every transition (compute_window_offset), we keep a running
    # (sum_row, sum_col, tile_count) of placed-tile coordinates and recompute the
    # offset in O(1). Only a TILE placement changes these (meeple/pass do not),
    # so transitions that don't place a tile leave the offset untouched. Seeded
    # by a one-time scan in from_state; updated in Game.get_next_state /
    # apply_action_inplace. Plain ints -> copy correctly under the dataclass's
    # default deepcopy (used by NeuralMCTS._reshuffled_root) and the manual
    # Board(...) build in mcts._rollout (which forwards them). MUST stay
    # consistent with state.placed_coords at every ply (offset feeds action
    # encode/decode — a wrong offset shifts the action space). Reconciled
    # bit-identical vs the full scan by scripts/reconcile_window_offset.py.
    sum_row: int = 0
    sum_col: int = 0
    tile_count: int = 0
    # Memoized string_representation result. None = not yet computed.
    # Boards are created fresh per Game.get_next_state (apply_action returns
    # a NEW Board around a deepcopied state), so this cache is auto-invalidated
    # by replacement — no manual invalidation needed. apply_action_inplace
    # mutates state but does NOT create a new Board; callers MUST not call
    # string_representation on an inplace-mutated Board (rollout-only contract).
    _str_repr_cache: str | None = field(default=None, repr=False, compare=False)

    @classmethod
    def from_state(cls, state: CarcassonneGameState, total_tiles: int, window_size: int) -> "Board":
        # Seed the incremental centroid sums by a one-time scan, then derive the
        # offset from them (same math compute_window_offset uses) so the seed and
        # the per-ply incremental updates can never drift apart.
        sr, sc, tc = centroid_sums(state)
        return cls(
            state=state,
            total_tiles=total_tiles,
            offset=offset_from_centroid_sums(state, sr, sc, tc, window_size),
            sum_row=sr,
            sum_col=sc,
            tile_count=tc,
        )


class Game:
    """AlphaZero-style Carcassonne game interface."""

    def __init__(
        self,
        players: int = 2,
        tile_sets: tuple[TileSet, ...] = (TileSet.BASE,),
        supplementary_rules: tuple[SupplementaryRule, ...] = (SupplementaryRule.FARMERS,),
        window_size: int = DEFAULT_WINDOW_SIZE,
        enable_legal_moves_cache: bool = False,
        include_farm_scalars: bool = False,
        sighted: bool = False,
    ):
        if players != 2:
            raise NotImplementedError("Phase 1 wrapper is 2-player only")
        # Reject out-of-scope configurations at construction time so the
        # action-space encoder doesn't surprise the caller mid-game with a
        # ValueError on an ABBOT/BIG MeepleAction. (External review pass 4,
        # 2026-04-28.)
        if TileSet.INNS_AND_CATHEDRALS in tile_sets:
            raise NotImplementedError(
                "INNS_AND_CATHEDRALS is out of scope for Phase 1-5; "
                "the action-space encoder doesn't handle BIG/BIG_FARMER meeples."
            )
        if SupplementaryRule.ABBOTS in supplementary_rules:
            raise NotImplementedError(
                "ABBOTS supplementary rule is out of scope for Phase 1-5; "
                "the action-space encoder doesn't handle ABBOT meeples."
            )
        self.players = players
        self.tile_sets = tuple(tile_sets)
        self.supplementary_rules = tuple(supplementary_rules)
        self.window_size = int(window_size)
        # Path B Step E (2026-05-29): append the 2 farm-control scalars to the
        # network input. OFF by default so existing 10-scalar checkpoints load &
        # eval unchanged; the new-arch Path-B warmstart opts in (and builds its
        # net with n_scalar_features = get_scalar_feature_size()). MUST match the
        # net the Game feeds — a 12-scalar Game with a 10-scalar net (or vice
        # versa) is a shape error at the policy_fc/value_fc1 cat.
        self.include_farm_scalars = bool(include_farm_scalars)
        # M2 canonical-AZ "sighted" representation (opt-in; DEFAULT OFF). When on,
        # get_canonical_form appends +3 farm-connectivity planes to the board
        # tensor (78 -> 81 channels) and the +32 bag/deck histogram to the scalar
        # vector. The net must be built with matching dims (n_input_channels=81,
        # n_scalar_features = base(+farm) + 32). MEASUREMENT ONLY — with sighted
        # False the branch is never taken and the featurizer is byte-identical to
        # the production path. See measurement/canonical_az/M2_PLAN.md.
        self.sighted = bool(sighted)
        # Legal-moves cache. Off by default; MCTS turns it on per search and
        # calls clear_caches() between root moves. See DECISIONS.md
        # ("Phase 4 prerequisite: get_valid_moves performance strategy").
        self._legal_cache: dict[str, np.ndarray] | None = (
            {} if enable_legal_moves_cache else None
        )
        self._legal_cache_hits = 0
        self._legal_cache_misses = 0

    def clear_caches(self) -> None:
        """Reset all per-search caches. Call between MCTS root moves."""
        if self._legal_cache is not None:
            self._legal_cache.clear()
        self._legal_cache_hits = 0
        self._legal_cache_misses = 0
        if hasattr(self, "_collide_shadow"):
            self._collide_shadow.clear()

    def cache_stats(self) -> dict:
        """Returns hits/misses/size for the legal-moves cache."""
        size = len(self._legal_cache) if self._legal_cache is not None else 0
        total = self._legal_cache_hits + self._legal_cache_misses
        hit_rate = self._legal_cache_hits / total if total else 0.0
        return {
            "enabled": self._legal_cache is not None,
            "hits": self._legal_cache_hits,
            "misses": self._legal_cache_misses,
            "hit_rate": hit_rate,
            "size": size,
        }

    # --- Construction ----------------------------------------------------

    def get_init_board(self) -> Board:
        state = CarcassonneGameState(
            players=self.players,
            tile_sets=list(self.tile_sets),
            supplementary_rules=list(self.supplementary_rules),
        )
        # Scope guard (locked scope = 2p Base+Farmers, NO Abbots): a base+farmers
        # state has abbots == [0, 0] and no ABBOT meeple can ever be placed. If this
        # fires, an out-of-scope ABBOTS state slipped past the __init__ guard and
        # would silently mis-score — fail loud instead of scoring the wrong game.
        assert not any(state.abbots), (
            f"scope violation: abbots enabled ({state.abbots}); locked scope is "
            "2p Base+Farmers, no Abbots")
        # +1 for the first tile already drawn into next_tile.
        total_tiles = len(state.deck) + 1
        return Board.from_state(state, total_tiles, self.window_size)

    def get_input_channels(self) -> int:
        """Board-tensor channel count the net must accept (78, or 81 sighted)."""
        n = N_CHANNELS
        if self.sighted:
            from .sighted_planes import N_FARM_PLANES
            n += N_FARM_PLANES
        return n

    def get_board_shape(self) -> tuple[int, int, int]:
        return (self.get_input_channels(), self.window_size, self.window_size)

    def get_action_size(self) -> int:
        return action_size(self.window_size)

    def get_scalar_feature_size(self) -> int:
        n = N_SCALAR_FEATURES + (N_FARM_SCALARS if self.include_farm_scalars else 0)
        if self.sighted:
            from .sighted_planes import N_BAG
            n += N_BAG
        return n

    # --- Transitions -----------------------------------------------------

    @staticmethod
    def _next_centroid_sums(board: Board, action) -> tuple[int, int, int]:
        """Centroid sums after `action`, carried forward from `board`.

        The window offset centers on the centroid of placed tiles. Only a TILE
        placement adds a coordinate (engine: StateUpdater.play_tile is the sole
        writer of placed_coords); meeple actions and passes place no tile, so the
        centroid — and therefore the offset — is unchanged. This is the O(1)
        replacement for re-scanning the whole board every transition.
        """
        if isinstance(action, TileAction):
            coord = action.coordinate
            return (
                board.sum_row + coord.row,
                board.sum_col + coord.column,
                board.tile_count + 1,
            )
        return board.sum_row, board.sum_col, board.tile_count

    def get_next_state(self, board: Board, action_idx: int) -> tuple[Board, int]:
        """Apply `action_idx` to `board`. Return (new_board, next_player).

        Safe — input board is unmodified. Use for tree expansion in MCTS.
        For rollouts where the trajectory is discarded, prefer
        apply_action_inplace (3-5x faster mid-game).
        """
        state = board.state
        action = self._decode_for(state, board.offset, action_idx)
        new_state = StateUpdater.apply_action(game_state=state, action=action)
        # Carry the centroid sums forward (O(1)) instead of re-scanning the whole
        # board in Board.from_state. Bit-identical to the full scan; verified by
        # scripts/reconcile_window_offset.py.
        sr, sc, tc = self._next_centroid_sums(board, action)
        new_board = Board(
            state=new_state,
            total_tiles=board.total_tiles,
            offset=offset_from_centroid_sums(new_state, sr, sc, tc, self.window_size),
            sum_row=sr,
            sum_col=sc,
            tile_count=tc,
        )
        return new_board, new_state.current_player

    def apply_action_inplace(self, board: Board, action_idx: int) -> tuple[Board, int]:
        """Apply `action_idx` to `board` IN PLACE. Returns (board, next_player).

        WARNING: mutates `board.state` directly. Caller must not retain the
        prior state. Use only in MCTS rollouts and other discard-the-trajectory
        contexts. Saves the deepcopy that dominates mid-game state-copy cost.
        """
        state = board.state
        action = self._decode_for(state, board.offset, action_idx)
        StateUpdater.apply_action_inplace(game_state=state, action=action)
        # Offset depends on placed tiles. Update the running centroid sums in
        # O(1) (only a tile placement moves the centroid) and re-derive the
        # offset — replaces the full board re-scan (compute_window_offset).
        # Bit-identical; verified by scripts/reconcile_window_offset.py.
        sr, sc, tc = self._next_centroid_sums(board, action)
        board.sum_row, board.sum_col, board.tile_count = sr, sc, tc
        board.offset = offset_from_centroid_sums(state, sr, sc, tc, self.window_size)
        # Invalidate the memoized string_representation since state changed.
        # Required for rollouts and warmstart 2-ply lookahead that mutate a
        # Board in place and then re-query get_valid_moves / string_representation.
        board._str_repr_cache = None
        return board, state.current_player

    def _decode_for(self, state, offset, action_idx: int):
        return decode(
            action_idx,
            off=offset,
            phase=state.phase.value,
            next_tile=state.next_tile,
            last_tile_coord=(
                state.last_tile_action.coordinate if state.last_tile_action is not None else None
            ),
        )

    def get_valid_moves(self, board: Board) -> np.ndarray:
        """Return a length-action_size bool mask of legal action indices.

        Built from the engine's own enumerator: encode each emitted Action
        and flip the corresponding bit. Off-phase indices are guaranteed
        zero because our `encode()` only ever produces same-phase indices.

        If the engine has legal placements but ALL of them fall outside the
        centered window (window-overflow), this method raises
        WindowOverflowError so the caller can drop the game from training
        rather than silently see "no legal moves" (the engine's natural
        no-legal-moves signal is a single PassAction, which the mask still
        accepts). (External review pass 4, 2026-04-28.)

        If the legal-moves cache is enabled (constructor flag), checks for
        and writes to it. Returns the cached mask directly without copying
        — callers must NOT mutate the result.
        """
        if self._legal_cache is not None:
            key = self.string_representation(board)
            cached = self._legal_cache.get(key)
            if cached is not None:
                self._legal_cache_hits += 1
                if _CACHE_COLLIDE_CHECK:
                    # DIAGNOSTIC (Phase 0.3): recompute the mask fresh and, if it
                    # disagrees with the cached one, we have TWO distinct boards
                    # sharing one string_representation key — a cache-corrupting
                    # collision. Log a full repro, then return the FRESH mask so
                    # the diagnostic run itself is not corrupted.
                    fresh = self._compute_mask(board)
                    if not np.array_equal(fresh, cached):
                        _log_cache_collision(self, board, key, cached, fresh)
                        return fresh
                return cached
            self._legal_cache_misses += 1

        mask = self._compute_mask(board)
        if self._legal_cache is not None:
            mask.flags.writeable = False  # protect cached masks from mutation
            self._legal_cache[key] = mask
            if _CACHE_COLLIDE_CHECK:
                if not hasattr(self, "_collide_shadow"):
                    self._collide_shadow = {}
                self._collide_shadow[key] = _state_fingerprint(board.state)
        return mask

    def _compute_mask(self, board: Board) -> np.ndarray:
        """Enumerate the engine's legal actions into a bool mask (no cache)."""
        mask = np.zeros(self.get_action_size(), dtype=bool)
        n_total = 0
        n_overflow = 0
        for action in ActionUtil.get_possible_actions(board.state):
            n_total += 1
            try:
                idx = encode(action, board.offset, board.state.phase.value)
            except WindowOverflowError:
                n_overflow += 1
                continue
            mask[idx] = True

        # Window-overflow audit (measurement-only; skipped byte-for-byte when
        # CARCASSONNE_WINDOW_AUDIT is unset). Records the already-computed
        # n_total / n_overflow plus the out-of-window placed-tile count so an
        # offline replay can quantify how often either bug site fires. Placed
        # before the all-overflow raise so the pathological case is recorded too.
        if _WINDOW_AUDIT:
            _WINDOW_AUDIT_LOG.append({
                "phase": board.state.phase.value,
                "n_total": n_total,
                "n_overflow": n_overflow,
                "k_remaining": board.total_tiles - board.tile_count,
                "n_oow_tiles": _count_out_of_window_tiles(board.state, board.offset),
                "window_size": board.offset.size,
            })

        # If every legal action is outside the window, surface a clear signal
        # so the caller can drop the game (rather than seeing an empty mask
        # and confusing it with a genuine no-legal-moves terminal).
        if n_total > 0 and n_overflow == n_total:
            raise WindowOverflowError(
                f"All {n_total} legal actions fall outside the {board.offset.size}x"
                f"{board.offset.size} window centered at "
                f"({board.offset.origin_row}, {board.offset.origin_col}). "
                f"Caller should drop this game from training."
            )

        return mask

    # --- Termination / value ---------------------------------------------

    def get_game_ended(self, board: Board, player: int) -> float:
        """0.0 if game ongoing; otherwise normalized score differential.

        Result is from `player`'s perspective: positive = player won (more pts).
        Final value is tanh((score_player - score_opp) / SCORE_NORM_SCALE).
        Exact tie returns a tiny epsilon so callers can distinguish "ended in
        draw" from "still going" — anything in (-1e-4, 1e-4) means draw.
        """
        if not board.state.is_terminated():
            return 0.0
        opp = 1 - player
        diff = board.state.scores[player] - board.state.scores[opp]
        v = math.tanh(diff / SCORE_NORM_SCALE)
        # Exact tie: return a tiny epsilon (non-zero so callers can tell
        # "ended in a draw" from "still going"), but make it player-dependent
        # so the perspective contract get_game_ended(b,0) == -get_game_ended(b,1)
        # still holds for draws — MCTS value backup relies on antisymmetry.
        if v == 0.0:
            return 1e-6 if player == 0 else -1e-6
        return v

    # --- Canonical form / encoding --------------------------------------

    def get_canonical_form(self, board: Board, player: int) -> tuple[np.ndarray, np.ndarray]:
        """Return (board_tensor, scalar_features) from `player`'s perspective.

        Window coordinates are NOT mirrored — only the mine/opp channels
        and player-relative scalar features are perspective-flipped.

        encode_board already reads `player` and writes mine/opp accordingly,
        so no extra canonical_swap is needed here. (A prior version
        double-swapped when player != current_player, silently reversing the
        intended perspective for the one caller that requested non-current
        player. Caught by external review 2026-04-28.)
        """
        arr = encode_board(board.state, player, board.offset)
        scalars = encode_scalars(
            board.state, player, board.total_tiles, include_farm=self.include_farm_scalars
        )
        if self.sighted:
            # M2 sighted cell: append +3 farm-connectivity planes to the board
            # (78 -> 81 ch) and the +32 bag/deck histogram to the scalars. Both
            # are STRUCTURAL functions of state (no label leak). encode_board may
            # return via the Cython fast path (USE_CY_REPR) — we concatenate the
            # Python-computed planes onto whatever the first 78 channels are, so
            # the sighted path is fast-path-agnostic and the first 78 channels
            # stay byte-identical to the blind path.
            from .sighted_planes import bag_histogram, farm_connectivity_planes
            fp = farm_connectivity_planes(
                board.state, player, board.offset, board.offset.size
            )
            arr = np.concatenate([arr, fp], axis=0)
            scalars = np.concatenate([scalars, bag_histogram(board.state)])
        return arr, scalars

    encode_observation = get_canonical_form

    # --- Hashing ---------------------------------------------------------

    def string_representation(self, board: Board) -> str:
        """Stable string for MCTS transposition tables.

        Two distinct game positions yield distinct strings; identical
        positions yield identical strings. Returned as a string (not int)
        so it serializes consistently across processes.

        Implementation note: SPARSE — only emits entries for placed tiles
        (~80 mid/late-game) instead of walking the full 35x35 board (1225
        cells, mostly None) and `repr()`ing the dense nested tuple. The
        dense version was ~166ms in late game, dominating get_valid_moves
        and making the legal-moves cache net-negative. Sparse should be
        ~5-10x faster.

        Memoized on the Board (see Board._str_repr_cache). NeuralMCTS keys
        nodes by this string and calls it many times against the same
        root Board within one search; the cache turns ~22K calls/game
        into ~150 cache misses (one per unique state visited).
        """
        cached = board._str_repr_cache
        if cached is not None:
            return cached
        s = board.state
        # Iterate placed_coords (~80 cells) instead of walking the full 35x35
        # grid (1225 cells, mostly None). Sort for determinism — placed_coords
        # is a set. Patched 2026-05-13.
        placed = []
        for coord in sorted(s.placed_coords, key=lambda c: (c.row, c.column)):
            t = s.board[coord.row][coord.column]
            if t is None:
                continue  # defensive; shouldn't happen since the set tracks placements
            placed.append((coord.row, coord.column, t.description, _tile_rotation_signature(t)))
        meeples = tuple(
            tuple(
                (mp.meeple_type.value, mp.coordinate_with_side.coordinate.row,
                 mp.coordinate_with_side.coordinate.column, mp.coordinate_with_side.side.value)
                for mp in s.placed_meeples[p]
            )
            for p in range(self.players)
        )
        last_tile_coord = (
            (s.last_tile_action.coordinate.row, s.last_tile_action.coordinate.column)
            if s.last_tile_action is not None
            else None
        )
        result = repr(
            (
                tuple(placed),
                meeples,
                tuple(s.scores),
                tuple(s.meeples),
                s.current_player,
                s.phase.value,
                len(s.deck),
                s.next_tile.description if s.next_tile is not None else None,
                last_tile_coord,
            )
        )
        board._str_repr_cache = result
        return result


def _tile_rotation_signature(tile) -> tuple:
    """Capture tile orientation + scoring-relevant properties.

    `description` alone is rotation-blind — two `tile.turn(...)` results
    with the same description but different orientations would otherwise
    collide. The 4 outer edges uniquely encode rotation.

    Defense-in-depth: also pin shield/chapel/flowers. The vendored engine
    has had at least one description-collision bug (city_diagonal_top_left_road
    vs city_diagonal_top_left_shield_road shared the same description string;
    fixed in our fork). Shields change scoring (+1 per city tile), so a state
    key that doesn't distinguish them would cause MCTS transpositions to
    merge positions with different value functions.

    Cached on the Tile instance: Tiles are canonically-shared immutable refs
    (base_tiles dict + Tile.turn() builds a fresh Tile per rotation), so the
    signature for any given Tile reference is stable for the lifetime of the
    process.
    """
    cached = tile._rot_sig_cache
    if cached is not None:
        return cached
    from wingedsheep.carcassonne.objects.side import Side
    edges = (
        tile.get_type(Side.TOP).value,
        tile.get_type(Side.RIGHT).value,
        tile.get_type(Side.BOTTOM).value,
        tile.get_type(Side.LEFT).value,
    )
    sig = (edges, bool(tile.shield), bool(tile.chapel), bool(tile.flowers))
    tile._rot_sig_cache = sig
    return sig


# --- CLI entry point ---------------------------------------------------------

@dataclass
class _GameOutcome:
    completed: bool
    rule_violation: bool
    mask_violation: bool
    had_overflow: bool
    score_sum: int
    error: str | None = None


def _play_one_random_game(args: tuple[int, int]) -> _GameOutcome:
    """Run a single random self-play game. Module-level so it pickles for Pool."""
    seed, window_size = args
    game = Game(window_size=window_size)
    random.seed(seed)
    board = game.get_init_board()
    had_overflow = False
    try:
        while game.get_game_ended(board, 0) == 0.0:
            if board_overflows_window(board.state, board.offset):
                had_overflow = True
            mask = game.get_valid_moves(board)
            legal = np.flatnonzero(mask)
            if legal.size == 0:
                return _GameOutcome(False, True, False, had_overflow, 0,
                                    error=f"seed {seed}: empty legal-move mask")
            idx = int(random.choice(legal))
            if not mask[idx]:
                return _GameOutcome(False, False, True, had_overflow, 0,
                                    error=f"seed {seed}: chose idx {idx} not in mask")
            board, _ = game.get_next_state(board, idx)
    except Exception as exc:
        return _GameOutcome(False, True, False, had_overflow, 0,
                            error=f"seed {seed}: {type(exc).__name__}: {exc}")
    return _GameOutcome(
        completed=True,
        rule_violation=False,
        mask_violation=False,
        had_overflow=had_overflow,
        score_sum=int(sum(board.state.scores)),
    )


def _self_play_random(
    n_games: int,
    seed: int = 0,
    window_size: int = DEFAULT_WINDOW_SIZE,
    workers: int | None = None,
) -> dict:
    """Run n_games of random-vs-random through the wrapper. Verify integrity.

    Parallelized via multiprocessing.Pool. Worker count defaults to
    `os.cpu_count()` (full SMT fan-out — see DECISIONS.md and
    scripts/bench_workers.py for why this beats physical-core cap on this
    workload).
    """
    if workers is None:
        workers = min(os.cpu_count() or 1, n_games)
    args_list = [(seed + i, window_size) for i in range(n_games)]

    # Skip the ETA banner for tiny runs (test fuzz reuses this helper)
    if n_games >= 16:
        per_item = measure_one(_play_one_random_game, args_list[0])
        print_banner(
            label=f"random self-play (window={window_size})",
            n_items=n_games,
            workers=workers,
            measured_per_item_seconds=per_item,
        )

    if workers <= 1 or n_games <= 1:
        outcomes = [_play_one_random_game(a) for a in args_list]
    else:
        with Pool(processes=workers) as pool:
            outcomes = pool.map(_play_one_random_game, args_list)

    rule_violations = sum(1 for o in outcomes if o.rule_violation)
    mask_violations = sum(1 for o in outcomes if o.mask_violation)
    completed = sum(1 for o in outcomes if o.completed)
    overflow_games = sum(1 for o in outcomes if o.had_overflow)
    score_sums = [o.score_sum for o in outcomes if o.completed]

    for o in outcomes:
        if o.error:
            print(f"  {o.error}", file=sys.stderr)

    return {
        "n_games": n_games,
        "completed": completed,
        "rule_violations": rule_violations,
        "mask_violations": mask_violations,
        "overflow_games": overflow_games,
        "overflow_rate": overflow_games / max(n_games, 1),
        "mean_score_sum": (sum(score_sums) / len(score_sums)) if score_sums else 0.0,
        "workers": workers,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="carcassonne_ai.game_wrapper")
    parser.add_argument("--self-play-random", action="store_true",
                        help="Run random-vs-random games through the wrapper")
    parser.add_argument("--n", type=int, default=100, help="Number of games")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--window-size", type=int, default=DEFAULT_WINDOW_SIZE)
    parser.add_argument("--workers", type=int, default=None,
                        help="Pool size (default: os.cpu_count())")
    args = parser.parse_args(argv)
    if not args.self_play_random:
        parser.error("nothing to do; pass --self-play-random")

    print(f"Running {args.n} random-vs-random games (window={args.window_size}, workers={args.workers or 'auto'})...")
    summary = _self_play_random(
        args.n, seed=args.seed, window_size=args.window_size, workers=args.workers
    )
    for k, v in summary.items():
        print(f"  {k}: {v}")
    if summary["rule_violations"] > 0 or summary["mask_violations"] > 0:
        print("FAIL: rule or mask violations detected", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
