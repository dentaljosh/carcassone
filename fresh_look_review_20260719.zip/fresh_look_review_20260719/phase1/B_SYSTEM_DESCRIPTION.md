# B — The System As Built

*(Phase-1 material. A neutral description of the mechanism — no results. The 15 load-bearing
source files are in [code/](code/) — **where this prose and the code disagree, the code is the
truth.** Line-level reading is encouraged; foundational mistakes hide in details.)*

## B.0 Code index

| file | what it is |
|---|---|
| `code/mcts.py` | all search: base `MCTS` (heuristic), `NeuralMCTS` (net priors), selection/backup/transposition table, Dirichlet noise, virtual loss, FPU knob, visit-distribution extraction |
| `code/heuristic_prior_mcts.py` | the current champion agent: PUCT search whose *priors* come from the hand-crafted leaf itself (softmax over child leaf values), no net |
| `code/network.py` | the ResNet (policy + value + auxiliary ownership heads; optional global-pool value head) |
| `code/board_repr.py` | board → tensor encoding (spatial input planes; opt-in farm-connectivity planes) |
| `code/sighted_planes.py` | the opt-in "sighted" extension: farm-connectivity planes + bag-histogram scalars (the 81ch/42sc representation) |
| `code/features.py` | the scalar input features (opt-in bag histogram) |
| `code/action_space.py` | the 2511-action encoding |
| `code/game_wrapper.py` | AlphaZero-style Game facade: state transitions, terminal reward, value normalization constants |
| `code/virtual_score_v2.py` | the hand-crafted leaf evaluator ("v2.7" family), object implementation |
| `code/flat_leaf.py` | the production de-objectified (union-find) implementation of the same leaf |
| `code/leaf_v29.py` | opt-in v2.8/v2.9/v2.9.x leaf variants (meeple-economy term / liquidity curve / caps / curve scaling / bag-close) |
| `code/fair_agent.py` | the fair-information (non-clairvoyant) production agent: PIMC determinizations, pooled-Q aggregation, marginalized endgame handoff |
| `code/gen_fair_distill.py` | the distillation data emitter: plays the fair champion against itself and records pooled root-visit distributions as policy targets |
| `code/selfplay.py` | self-play game generation: policy/value target construction, temperature, resign/overflow handling |
| `code/train_iter.py` | the training loop: losses, batching, checkpointing, sliding replay window |

## B.1 Engine

A vendored, patched fork of the open-source `wingedsheep` Carcassonne engine provides rules, legal
moves, and scoring. The team fixed several real engine bugs over the project's life (tied-feature
scoring; a farmer-adjacency connectivity bug; a farm-scoring double-count; a tile-dictionary
duplicate). Board is a 35×35 grid; the network sees a centered **25×25 window**.

## B.2 The current production agent (as of 2026-07-13)

**Deep-classical, no neural net.** `HeuristicPriorAgent` — **PUCT search whose priors are derived
from the hand-crafted leaf itself** (children pre-evaluated with the leaf; softmax at prior
temperature `tau_p=5` supplies PUCT priors; `c_puct=1.5`; final move = visit-argmax; the search
tree is **re-rooted between moves** rather than discarded), with the leaf evaluator
**`v2.9.2 Bmild_cap8 curve125`** (the v2.7 `virtual_score` base + a nonlinear meeple-liquidity
curve scaled ×1.25 + closure cap 8) at a per-move budget of **~2750 simulations** (pinned to equal
wall-clock with the previous h6400 plain-UCT champion on the reference box).

Deployment is **fair-information mode** (`fair_agent.py`): PIMC — **k_dets=4 determinizations** of
the unseen deck order × 688 sims each (same 2752 total), **pooled-Q** aggregation across them, the
determinization shuffle made provably independent of the hidden true order (a canonical sort
before reshuffle), and an **exact marginalized expectiminimax handoff for the last K≤2 tiles**.
A clairvoyant variant (true deck order, exact alpha-beta K≤4 endgame) exists as the internal
reference/eval configuration. Config: [../phase2/sources/PRODUCTION.yaml](../phase2/sources/PRODUCTION.yaml)
(config only — safe to consult; everything else in phase2/ stays closed during Phase 1).

**A neural stack also exists**, held the production title 2026-06-11→07-02, and is the substrate
of the project's newest work (B.6). It is fully described below.

## B.3 The neural stack

**Network:** 96-channel × 6-block ResNet, ~7M parameters (`network.py`).
- **Input:** ~78 spatial channels over 25×25 — per-cell tile-edge terrains, placed meeples by
  player/type, occupancy — plus 12 scalars (free-meeple counts, scores, diffs, deck size, player
  index). **Opt-in "sighted" extension** (read `sighted_planes.py` / the flags in
  `board_repr.py`/`features.py`): +3 live farm-connectivity planes (from the leaf's own union-find
  decomposition) and a per-tile-type bag-histogram scalar block — the **81ch/42sc** representation
  — plus a global-pool value-head variant.
- **Action space: 2511** (`action_space.py`): 625 positions × 4 rotations, tile-pass, 5 regular
  meeple slots, 4 farmer slots, meeple-pass.
- **Heads:** policy → 2511 logits (legality-masked); value → scalar `tanh` ∈ [−1,1]; an auxiliary
  per-cell ownership head used only as a training loss.

**Search** (`mcts.py`): PUCT MCTS. Neural play plane: sims=200, c_puct=3.0 historically (the
fair-mode wrapper uses the champion's c=1.5/τ5 knobs); root Dirichlet noise; temperature τ=1 for
the opening plies then greedy; transposition table keyed by board state (with de-aliasing of
rotationally-symmetric actions); optional virtual loss; an **FPU (first-play urgency) knob** for
unvisited children.

**What evaluates a leaf (the signature design choice):** in the neural stack's historical standard
configuration, the value driving search is the **hand-crafted heuristic**, with the network's
value head added as a small residual:

```
leaf_value = tanh( virtual_score(state, player) / 15 ) + 0.25 · v_net     (clipped)
```

Configurations where the net's value fully drives the leaf, and weaned/additive blends, exist as
flags. Historical neural search descends the **true future tile order** (clairvoyant); the PIMC
fair mode is the deployable alternative.

## B.4 The heuristic leaf (`virtual_score_v2.py` / `flat_leaf.py` / `leaf_v29.py`)

For the player to move: (1) **finish-the-game score diff** — flood-fill/union-find every
city/road/farm component and count final points per placed meeple; (2) a **closure-anticipation
bonus** per meeple on unfinished features, with closure probability a step function of open-edge
count (1 open → P=1.0, 2 → 0.5, 3 → 0.25, ≥4 → 0), farm bonuses per adjacent unfinished city, and
self/opponent caps; (3) a **meeple-economy term** — a nonlinear per-free-meeple-count liquidity
curve (v2.9), scaled ×1.25 in the current production variant, cap 8. Weeks of hand-tuning sit
behind the constants. The leaf reads the **current board only** — it does not read deck
composition; an opt-in "bag-close" gate exists in `leaf_v29.py` (off in production).

## B.5 The self-play loop (generic machinery)

One iteration (`selfplay.py`, `train_iter.py`): generate games with a configured search (policy
target = root visit distribution; value target configurable — game-outcome margin
`tanh(score_diff/15)` default, wide/root-Q/residual variants exist); train on a **sliding window
of the most recent iterations** (policy CE + value MSE-or-ranking + ownership auxiliary; batch
256, ~3 epochs, Adam); gate/promote vs the incumbent and/or a fixed ruler, deck-paired.

## B.6 The distillation flywheel (the newest construction — mechanism only; results are Phase-2)

A two-stage construction on the neural stack, designed after the classical agent took the
production title. **Its design differs deliberately from every earlier self-play recipe in this
project; the differences are enumerated as testable choices in Phase 2/3 material.**

- **Stage 1 — distill the champion.** `gen_fair_distill.py` plays the **fair (blind-PIMC)
  production champion** against itself at full production budget (k4×688 = 2752 sims/move) and
  records, per move, the **root visit distribution pooled across the k determinizations**. The
  net (sighted 81ch/42sc representation) trains its **policy head to imitate that search output**
  (CE on pooled visits). The **value head is trained on game outcomes but is never consulted at
  play or search time** — it is deliberately severed.
- **Stage 2 — self-play over a frozen value.** Self-play iterations where search uses the **net's
  policy head for priors** and the **frozen champion leaf (curve125) for all leaf values** — the
  only thing that can improve is the policy prior. Generation runs fair (PIMC k4) at **200 sims
  per determinization (k4×200 = 800, ¼ of the production budget)** for throughput; training uses a
  **12-iteration sliding replay window** (so the stage-1 teacher data ages out of the window as
  iterations accumulate); there is no per-iteration strength gate (health screens only).
- **Evaluation plane** (mechanism, for orientation): checkpoints are compared by deck-paired games
  against fixed out-of-lineage reference agents, at configurable search depth; a
  cross-representation harness allows a sighted net to play a non-sighted one.

## B.7 Evaluation methodology

- Head-to-head, **deck-paired** (same deck both colors). Reference σ: n=400 paired ≈ ±17.5 elo;
  n=200 ≈ ±24.6; n=100 ≈ ±35.
- The standard internal rulers are **heuristic-leaf search agents** at various budgets
  (`h200 … h6400, h12800`) and, more recently, **fixed frozen checkpoints of earlier learned
  lineages** as out-of-lineage anchors; a **fair sub-ladder** (PIMC agents at graded budgets)
  exists for deployable-strength pricing. There is no human/external anchor to date.
- Offline (non-game) evaluation uses **sibling-set ranking**: Kendall-τ / top-1 / held-out regret
  over ~10k position sets with all legal children labeled — either by a deep-search teacher
  (`h6400`; note such a teacher shares the leaf) or by the **exact solver** (below).
- An **exact alpha-beta solver** for the last K≈2–4 tiles provides non-circular ground truth,
  including a **marginalized (fair-information) K≤2 mode** used as a ~1,100-root ranking ruler.

## B.8 Scale, for calibration

By AlphaZero standards everything here is small: 7M params, ≤ ~1.2k games/iter, flywheels of ≤ ~20
iterations, offline rankers ~0.4M params, two consumer boxes. Whether conclusions drawn at this
scale generalize is a legitimate review question.
