# C — The Experiment Record (Phase-2 material)

> **Do not read before completing Phase 1** (your blind diagnosis from A + B + code).
>
> This is the complete factual history through **2026-07-19** (the newest arc, C.9, ran to a
> closed verdict the morning of packet day — nothing is left in flight). **FACT** columns are
> measured numbers (each citing a row in
> [sources/results_csv_relevant_rows.csv](sources/results_csv_relevant_rows.csv) or a verdict doc
> in [sources/](sources/)). **"Team's call"** is the team's interpretation — recorded for
> completeness, *not* to be inherited. Stats reminder: deck-paired; n=400 ≈ ±17.5 elo (1σ);
> n=200 ≈ ±24.6; n=100 ≈ ±35.

---

## C.1 Corrections & audits that gate everything (trust base)

| date | event | detail |
|---|---|---|
| 2026-05-29 | engine farm-connectivity bug fixed | farmer adjacency was non-bijective → farm regions start-dependent (~2.2% of games nondeterministic) |
| 2026-06-02 | 6-agent foundational audit ([sources/foundational_audit_2026-06-02.md](sources/foundational_audit_2026-06-02.md)) | found 2 live data-corrupting bugs, both fixed same day: **C1** farm scoring double-counted cities (~17% of farms over-scored → corrupted reward + leaf) and **C2** MCTS transposition visit double-count (~20% of decision nodes → corrupted every policy target). Also named architectural caps: value never in the search loop; representation blind to farm connectivity + bag; saturated `tanh(diff/15)` target; no symmetry aug; advisory (non-rejecting) promotion gate |
| 2026-06-02 | River dropped; base-only reframe | all pre-June "River-era" numbers demoted to historical |
| 2026-06-07 | clean-eval audit | runtime evaluator-provenance guards + 11 semantic contracts; several historical claims re-judged/invalidated |
| 2026-07-01 | **oracle-circularity correction (review "F4")** | offline rankers had been scored against an `h6400` teacher whose Q correlates **0.995** with the v2.9 leaf → "beats/approaches the leaf" claims on that ruler are circular. Fixed by re-scoring against the **exact solver** (marginalized K≤2, 1,119 roots) — the non-circular ruler used for everything after 07-01 |
| 2026-07-14 | **PIMC fairness fix (CL-056)** | the deployed fair agent's determinization was **correlated with the hidden true deck order** (audit probe: 19% of trials flipped a move — a real clairvoyance leak); fixed by canonically sorting the unseen deck before reshuffle. Past fair numbers remain valid PIMC but are **not bit-reproducible** against the fixed agent; new fair evals re-establish their own baselines |
| 2026-07-18 | eval-json semantics correction | in the head-to-head result jsons, `won_by_champ` = **the candidate won** (the harness names the candidate side "champion"); two result rows were first tallied inverted, caught same day via a sign contradiction, verified (0/312 disagreements vs margin signs), corrected in results.csv |
| ongoing | results discipline | every eval writes a manifest; results.csv is the source of truth; deck-pairing standard; pre-registration of decision rules is house practice |

## C.2 The hand-crafted leaf kept improving (classical line)

| date | leaf | change | FACT | team's call |
|---|---|---|---|---|
| 2026-05-14→17 | v2.5 → v2.7 | closure-anticipation + caps + dedup fixes, hand-tuned | became the production leaf & the baseline of everything | "strong-human by construction" |
| 2026-06-22 | **v2.8** | turn ON the flat meeple-economy term (`k=2`) | heur +179.5 elo @200 / +94.9 @800; `v28@200` beats `v27@800` (+202.6); lifts the neural agent too: `iter8+v2.8` vs `iter8+v2.7` **+154.5 (z9.8)** | real, large classical gain that lifts *everyone* — the learned agent still loses to deep search at equal leaf |
| 2026-06-25 | **v2.9** | nonlinear meeple "liquidity curve" (Bmild) + retuned cap 8 | vs real v2.8 production config: **0.579 wr / +55 elo / z+3.94** @s200, depth-robust | another real classical gain |
| 2026-07-02 | v2.9 at depth | the deferred deep arbiter | vs v2.8-prod at **h6400**, fresh band, n=399: **+64.3 elo / z=3.77 / wr 0.591** | promotion evidence (→ C.6, S1) |
| 2026-07-04/05 | **v2.10 arc — CLOSED NULL** | first *solver-screen-first* leaf loop: screen candidate changes on exact-solver endgame τ/regret, then game-gate the winners | Track A screen winner `cap6` (solver-τ 0.615→0.648, monotone in cap, replicated) — **game gate NULL** (+4.3 elo, z0.45, n=800); Track B `bag-close` gate **NULL** (−6.1, z0.40) | **the solver-endgame screen does NOT predict full-game leaf strength** — the offline↔online dissociation now demonstrated on the *classical* side too; v2.9 stays |
| 2026-07-11→13 | **v2.9.2 "curve125" — ADOPTED** (rows `c5_*`; [sources/DECISIONS_excerpt_2026-07_arc.md](sources/DECISIONS_excerpt_2026-07_arc.md)) | scale the meeple liquidity curve ×1.25 | screen +81.4/z2.05 on a **coherent monotone axis** (nocurve −92.5 → ×0.75 −34.9 → base 0 → ×1.25 +81.4); n=400 fresh-band confirm **+66.8, paired z=4.59**, compute-neutral; **fair-mode re-confirm +48.8 elo z3.13** (blind PIMC vs the fixed rung); peak-find n=400 across ×0.75–2.0 = noisy plateau, no cell beats ×1.25 | **first leaf change ever folded into the champion** (2026-07-13). The leaf can still be improved — but see C.9: the *next* wave of leaf terms all failed |

Note: the v2.8 term was **bit-identical to a legacy knob that had been OFF since v3** — killed
weeks earlier by an n=20 screen later shown to be noise.

## C.3 Self-play / flywheel attempts through June (games are the metric)

| date | run | FACT | team's call |
|---|---|---|---|
| 2026-05 | warmstart + recipes v1–v6 | NN-value-as-leaf self-play plateaued; a pure net-value leaf scored ~**−800 elo**; switching the leaf to the v2.7 heuristic was the breakthrough | net value catastrophic as sole leaf |
| 2026-06-07 | residual flywheel #1 (3 iters) | +14.3 elo cumulative (within noise) | no flywheel |
| 2026-06-10 | **residual flywheel #2 → champion `iter8`** | vs incumbent **+67.4 / z2.73** (sealed out-of-lineage ruler, n=400); vs `heur@800` **+58.7**; decomposition: ~95% of the gain is **policy**, residual-value contribution static ~+22, plateau by iter5 | real but bounded; production champion 2026-06-11 → 07-02 |
| 2026-06-17 | deepteacher (sims-800 teacher, 12 iters) | iter12 vs iter8 = **TIE** (+14.6 @s200 / +12.4 @s800, z<1); a later "+53.7/z2.14" for iter2 **refuted on a third fresh band 2026-07-02: +2.0/z0.09**. Separately: iter12−iter0 = **+82.8/z3.48 at sims200 but +8/z0.34 at sims800** (same nets, same decks — **policy gains wash out under deep search**) | deeper policy teacher doesn't help (powered, twice); and low-sims policy gains are not depth-portable |
| 2026-06-19 | ladder placement of iter8 | `iter8` vs heur ladder, same band: **+40.1 @800 → +24.4 @1600 → −28.7 @3200** | learned edge erased by deeper heuristic search |
| 2026-06-22 | **RoD** — continuation on the v2.8 leaf | `RoD_iter_01+v2.8` vs frozen parent `iter8+v2.8`: **+53.4 / z3.51** — the first continuation ever to beat its parent; vs `heur@3200+v2.8` (equal leaf, n=800): winrate +16.5 / margin −0.36 = **parity** | a stronger leaf unstuck a real gain, but only *to* parity with deep search |
| 2026-06-23 | v2.8 overnight flywheel (16 iters) | best iter: +33.1/z2.0 internal, but vs `heur@3200+v2.8` (n=800) **+6.5/z0.53 = TIE** | internal gain washed out vs the external ruler |
| 2026-06-24 | deeper-search ruler probe | `h6400` beats h3200 on margin (z+2.61); **RoD_iter_01 LOSES to h6400 (−45.4, margin z−3.24)**; h12800 > h6400 on margin | heuristic depth ladder not saturated; adopt h6400 as reference |
| 2026-06-24 | exact endgame hybrid (solver plays last K tiles) | Δmargin scales with K (+0.65 K2 → +1.94 K4) but **winrate NS at every depth** | margin-sharpening, outcome-neutral |
| 2026-06-27 | **RoD v2** — continuation on the v2.9 leaf (5 iters) | every iter LOSES to `h6400+v2.9` (−22…−32), no climb; root audit: policy prior diffuse, value-head corr flat. (Its `iter_02` checkpoint later becomes the fixed **out-of-lineage anchor** of C.10) | "the v2.9 leaf swap changed nothing; stop the blind flywheel" |

## C.4 Learned-component pilots (offline; sibling-ranking — note the C.1 F4 caveat: pre-07-01 rows used the near-circular h6400 ruler)

| date | pilot | FACT | team's call |
|---|---|---|---|
| 2026-06-19 | value-ranking kill-test (CL-021) | learned value/rankers rank siblings at τ≈0.03–0.10 vs the leaf's τ≈0.58–0.895 | value inert |
| 2026-06-27 | value/search autopsy (CL-032) | value residual scale 0/0.25/0.5 indistinguishable at the root; classical h200 agrees with h6400 **0.911** vs production neural 0.799; yet **in games** classical-vs-neural at matched compute = NS (z−1.19, slight lean *neural*) | root metrics don't predict game strength |
| 2026-06-28 | value resurrection (CL-033) | best blend α=**0** for every variant; net-alone τ peaked 0.105 vs leaf 0.895 | value stays inert vs the v2.9 leaf |
| 2026-06-28 | **feature-graph comparator (CL-034)** | 50 explicit structural/action scalars + linear/listwise ranker: **beats the leaf offline** — held-out regret **−41%** — the first learned object to clear the leaf; **but under MCTS@200** no integration beats plain search | offline win, washes out under search |
| 2026-06-28 | post-search residual / adaptive compute (CL-035) | escalation signal predictable (AUROC 0.78) but a one-line heuristic captures it; magnitudes tiny | no ML scheduler |
| 2026-06-29 | typed GNN on post-search residual (CL-036) | GNN generalizes worse than a flat MLP; **ablation: zeroing the graph embedding *improves* it** | relational structure inert |
| 2026-06-2x | policy-repair & distillation pilots (CL-030/031) | "hard-state" policy target signal-free (one-hot: 0.775 train → 0.061 test); high-gap distillation learns offline (top1 0→0.18) but **in games −64 elo** | policy distillation dead as a strength lever *(with a weak-teacher / clairvoyant recipe — see C.10)* |

## C.5 The representation gates and closure probes (2026-06-29 → 07-01)

*(From a pre-registered plan with an explicit decision rule —
[sources/CHARTER_INTEGRATED_REVIEW_PLAN_2026-06.md](sources/CHARTER_INTEGRATED_REVIEW_PLAN_2026-06.md) §10.)*

| step | FACT | team's call |
|---|---|---|
| **Gate A — representation** ([sources/measurement_feature_planes_gate_STEP1_GATE_RESULTS.md](sources/measurement_feature_planes_gate_STEP1_GATE_RESULTS.md)) | Adding **farm-connectivity planes (+3)** and a **bag histogram (+32 scalars)**: held-out regret **−20.5%** vs blind baseline −1.9%, α 0.05>0, τ 0.140→0.207; shuffled-plane negative control collapses to +0.0%/α=0; farm-only −17.1% / bag-only −19.7% (**largely redundant substitutes**) | PASS — the old "α=0" was partly a representation confound; bag = information the heuristic cannot see. (Scored on the h6400 ruler — see C.1 F4) |
| **Gate B — the weaned flywheel** (rows `step2_*`; [sources/DECISIONS_excerpt_CL037_038_039.md](sources/DECISIONS_excerpt_CL037_038_039.md)) | A structure-aware sighted value **ranks well at every tree depth** (interior τ: d1 0.42 / d2-3 0.45 / d4-7 0.43; +43% offline) — yet at blend 0.27 play **craters vs its own parent**: convex/MSE wr **0.19 (−246 elo)**, additive **0.28 (−160)**, ranking 0.287, **frozen never-retrained 0.21 (−225, z−7.5)**; pure-heuristic anchor exactly 0.500 | FAIL — three nails excluded distribution-mismatch (τ flat by depth), heuristic-subtraction (additive craters too), retraining-drift (frozen craters). "Value can RANK but cannot DRIVE search." *(The mechanism was found later — C.6, M3.)* |
| **Probe A — structured value leaf** | 24-dim per-component value emit feasible (2.2–2.7× leaf cost, bit-exact); farm/bag independence on the structured head: Δ_indep **+0.05pp** vs a pre-registered ≥+3pp bar (~8σ below) | killed cheaply; "residual value signal is low-dimensional" |
| **Probe B — fair vs clairvoyant value targets** ([sources/measurement_probe_b_4a_PROBE_B_4A_RESULTS.md](sources/measurement_probe_b_4a_PROBE_B_4A_RESULTS.md)) | One-variable-clean, matched depth 800, full n: **all six arms inert (α=0)** — *including clairvoyant* (Gate A's α>0 had required h6400-deep targets) | depth-saturated → inconclusive alone; route closed "on the accumulated ledger"; deliverable **B1** = deployable fair-info agent |
| **Probe §5A — tempo third axis** ([sources/measurement_probe_5a_PROBE_5A_RESULTS.md](sources/measurement_probe_5a_PROBE_5A_RESULTS.md)) | gate-zero: naive tempo counts ≥0.72 reconstructible (dropped); a 10-feature residualized timing-depth core survives; single-seed `tempo_only` **+44.7%** on the h6400 ruler — but the control arm broke (init fragility) and the ruler is the circular one (F4) | initially "live offline lead"; resolved non-circularly in C.6 |

## C.6 The post-review program (2026-07-01 → 07-04) — a fresh-look review ran; its plan was executed

*(The review's plan: [sources/POST_REVIEW_PLAN.md](sources/POST_REVIEW_PLAN.md); the resulting
autopsy: [sources/AZ_VALUE_ROUTE_AUTOPSY_2026-07-01.md](sources/AZ_VALUE_ROUTE_AUTOPSY_2026-07-01.md).
It ordered five actions: S1/S2 strategic, M1/M2/M3 mechanism reopeners. All five read out.)*

| action | FACT | team's call |
|---|---|---|
| **S1 — promote the classical agent** | v2.9 `Bmild_cap8` vs real v2.8-prod at **h6400** (fresh band, n=399): **+64.3 elo / z=3.77** | **PRODUCTION FLIPPED (the first champion change of the project):** champion = **deep-classical HeuristicMCTS on the v2.9 leaf @ h6400 + exact K≤4 endgame handoff**; neural `iter8` demoted to lineage |
| **S2 — external bot anchor** ([sources/measurement_bot_anchor_S2_BOT_ANCHOR_SCOPING.md](sources/measurement_bot_anchor_S2_BOT_ANCHOR_SCOPING.md)) | both readily-available open-source Carcassonne AIs are **weaker than a 1-ply greedy**: a MuZero implementation (195k net; also a rotation bug in its API makes it unbridgeable to a rules-correct engine) and an MCTS-RAVE implementation (rules-correct, bridgeable, sub-greedy) | **clean negative — no usable external bot anchor exists.** Remaining non-circular references: the exact solver + (deferred) humans |
| **M1 — deepteacher re-kill** | iter2 vs iter8, third fresh band, fixed-rung paired n=400: **Δ +2.0 elo, z=0.09** | the one surviving "maybe" was band noise; kill stands, powered |
| **M3 — Gate-B mechanism (calibration/tails)** | Full n=400 **FPU curve** on the additive weaned-value crater: fpu None **0.265** → 0.4 **0.391** → 0.6 **0.496 = PARITY** (z−0.15 vs the 0.500 anchor) → 0.8 0.483 → 1.0 0.476. Isotonic calibration recovered **less** than FPU | 🔥 **Gate-B is refuted as a law.** The crater was a **fixable search artifact**: the MCTS max-operator hunts the learned value's optimistic tail on unvisited children; FPU tames it. But recovery is **to parity, not past it** |
| **M2 — the never-run canonical-AZ cell** ([sources/measurement_canonical_az_M2_PLAN.md](sources/measurement_canonical_az_M2_PLAN.md); pre-registered read-out) | The one cell every prior null left structurally open — **sighted rep × global-pool value head × `score_diff_wide` target × FPU=0.6 × the net's value fully driving the leaf** — ran a real 5-iteration self-play loop. **Primary read (non-circular):** value-head τ vs the **exact K≤2 solver** (1,119 marginalized roots) = **0.018 → 0.023 across iters, FLAT**, vs leaf **0.615** (paired sign-z −17). Heads do track score-diff (corr 0.50→0.65) — the failure is **between-sibling discrimination**. **Conversion read:** rs-sweep 0/6 cells ≥2σ, non-monotone, harm at weight (−22…−68 elo) | ❌ **KILL on both pre-registered reads → the AZ-value route closure is "EARNED"** (anchored non-circularly). **Scope guard (the team's own):** valid *at this scale* — 7M params, ≤5 iters, sims≤200 |
| **§5A resolution — tempo re-scored non-circularly** | 12 retrains, solver pass vs the same 1,119-root exact ruler: `tempo_only` solver-τ mean **0.145** — genuine (~7× the M2 value heads' 0.02) but **leaf-dominated 4×** (leaf 0.615; best seed sign-z −9.2). The circular +44.7% was a tail draw | REAL-BUT-DOMINATED; no route implication |

## C.7 Deployment & classical-side work (2026-07-04 → 07-05)

| item | FACT | team's call |
|---|---|---|
| **Fairness probe → production fair mode** ([sources/measurement_fairness_probe_README.md](sources/measurement_fairness_probe_README.md)) | exact-solver move regret at champion config (n=300, sims=1600, K=8 determinizations): CLAIR 0.447 / FAIR pooled-N 0.393 / **FAIR pooled-Q 0.383** (top1 0.807 ≥ clair 0.793); paired Δ NS; pooled-Q never blunders | **production runs fair (PIMC pooled-Q + marginalized K≤2 handoff)** — genuinely non-clairvoyant/deployable |
| **v2.10 leaf arc** (C.2 row) | solver-screen winners do **not** convert to game strength | leaf-improvement-via-solver-screen closed; v2.9 stays |
| **Capacity probe** ([sources/measurement_capacity_probe_CAPACITY_PROBE.md](sources/measurement_capacity_probe_CAPACITY_PROBE.md)) | pre-registered ranker-capacity slope probe; **crashed on WSL-OOM** (the 30GB observation dataset kills the VM); scale question left **weakly-dead on indirect evidence only** (386K rankers already reach τ≈0.13; no capacity-binding signature) | a clean slope needs a memory-safe subset re-run (deferred; unfunded) |
| **Phone-budget bench** | single-thread ms/move harness for the v2.9 champion measured on local hardware | deployment sizing (analyzer / playable agent) |

## C.8 The classical squeeze (2026-07-06 → 07-15) — the champion improved twice more, then every remaining classical lever closed null

*(A fourth external review ran 2026-07-05; this arc executed and exhausted its classical
prescriptions. Sources: [sources/DECISIONS_excerpt_2026-07_arc.md](sources/DECISIONS_excerpt_2026-07_arc.md),
[sources/STATUS_snapshot_20260719.md](sources/STATUS_snapshot_20260719.md), result rows `rr_puct*`,
`fair_puct*`, `fair_ladder_*`, `c5_*`, `kdets_*`, `c7_*`, `t3_s3*`, `fairnet_v2_*`.)*

| item | FACT | team's call |
|---|---|---|
| **PUCT-priors search rebuild (Phase 1.1, 2026-07-06/07)** | replace the champion's random-expansion UCT with **PUCT + heuristic-leaf priors** (leaf pre-evaluates children → softmax priors): **+148.2 elo / z=10.17 / n=400 fresh band** at equal wall-clock vs the h6400 champion; **transitivity-verified** (round-robin vs an independent lineage; beats h12800 while h6400 ties its own double); K=3 endgame confirm +108.1/z6.11 | **second champion change** — a pure *search* win over the SAME leaf; "the hand-crafted-leaf ceiling wasn't where the charter drew it" |
| **Tree reuse + knob closures (2026-07-08)** | re-root the tree between moves: **+39.3/z2.81/n=400** equal wall-clock → folded; LCB selection wash (0.0/z0.11); value_norm=15 confirmed (both wings negative); Gumbel top-m **negative** (−81/−98), completed-Q variant +15.6/z2.30 flag-gated only | free depth banked; selector axes closed |
| **The clairvoyance-currency correction (2026-07-09)** | every strength number above the h-ladder had been measured **clairvoyant** (both sides see the deck order). Fair-PIMC screen: the same champion **clair +205 → fair +49** vs an h800 rung → **clairvoyance tax ≈156 elo (~4:1 discount)**. A **fair sub-ladder** (blind PIMC at graded budgets) becomes ruler of record: **+27.9/+61.4/+81.4/+149.3 @ 800/1600/2752/5504 total sims** (paired z up to 6.80), cleanly scaling, not saturating; tax persists ~120 at every rung | clairvoyant ladders demoted to screens; **"search deeper, fair" is a live (compute-hungry) strength lever**; deployable strength is what counts |
| **C-cheap: deck-aware learned value in the fair leaf (CL-049/050, 2026-07-10)** | v1 (full leaf replacement, pooled-Q): **W0/L100, avg_diff −58** — the net value is globally sane (corr +0.5) but has near-zero **local sibling discrimination** (sibling std ~0.01 vs the leaf's ~0.04); v2 (residual redo, full pre-registered pipeline): offline gate PASSED (25% MSE gain; deck-awareness ~5% of signal) → **online +9.2 elo (gate ≥+35 FAIL), paired Δz +0.18** | value-inertness confirmations #7 and #8 (strongest forms); nothing attacks the ~120 clairvoyance tax |
| **C5 curve125 (CL-051)** | (C.2 last row) — clair +66.8/z4.59 AND fair +48.8/z3.13, monotone axis | **first leaf fold; adopted 2026-07-13** |
| **C6 full-game alpha-beta (CL-053)** | ID-αβ+TT plays clairvoyant games: **+34.9/z2.94** vs the PUCT champion — but alpha-beta **has no fair form** (chance nodes break minimax cutoffs; can never deploy blind); early +206/+190 calibration smokes were small-n noise that regressed to +35 | clairvoyant-only dead-end; strategically inert for the goal |
| **k_dets width bracket (CL-054)** | at FIXED total budget 2752, deck-matched delta vs the deployed k8: **k4×688 +5.18±1.24 pts/deck z=4.17 (winner)**, k2×1376 +3.36/z2.38, k16≈k8, k32 −6.28/z−3.55 — a coherent **inverted-U peaked at k4** | **fair deploy re-tuned k8→k4×688, cost-neutral, adopted 2026-07-13** — the first fair (deployable) lever to fire, confirm, and fold |
| **C7 second-wave leaf terms (CL-055, 2026-07-14)** | Term F (farm majority-flip): monotone-decreasing dose axis, best cell **+20.9/z1.50 < the pre-registered ≥+35∧z≥1.5 gate** → dead. Term R (meeple-return liquidity): **−34.9 (k=0.5) → −251.9/z−10.17 (k=1.0)** — decisively, monotonically harmful | curve125 already soaked the extractable meeple-economy headroom; **the leaf's remaining headroom is NOT in cheap adjacent terms** |
| **T3 joint 7-knob Optuna sweep (CL-057, 2026-07-15)** | TPE over c_puct/tau_p/value_norm + curve/closure/cap scales, nested successive-halving, clair-screen→fair-confirm: clair stage FIRED two candidates (**t020 +36.3/z2.97**, t27 +34.9/z2.35) — **both died at the fair-transfer gate**: t27 fair +4.7/z−0.55; **t020 = a winner's-curse spike** (+32.1/z1.68 at n=400 → extended to n=800 fresh decks → **collapsed to +3.4/z0.73**) | **knob-tuning the heuristic-leaf search has no free FAIR strength** (clair edges wash ~4:1 under PIMC). With C7: **leaf AND search now both tapped out** → the frontier bet named at close-out: *distill the champion into a net, then flywheel* (→ C.9) |

## C.9 The distillation flywheel (2026-07-15 → 07-19) — the newest arc: an apparent breakout, then its pre-registered refutation; arc CLOSED

*(Design: [sources/distill_DESIGN.md](sources/distill_DESIGN.md) +
[sources/distill_DESIGN_FAIR_ADDENDUM.md](sources/distill_DESIGN_FAIR_ADDENDUM.md) +
[sources/distill_STAGE2_FLYWHEEL_SPEC.md](sources/distill_STAGE2_FLYWHEEL_SPEC.md). Run state doc:
[sources/distill_HANDOFF.md](sources/distill_HANDOFF.md) — ⚠️ a dated working doc frozen 07-19
00:15, BEFORE the refutation: its "GROWTH CONFIRMED" banner is superseded by the rows below and by
the 2026-07-19 DECISIONS close-out. The 25-hour autonomous run narrative (whose morning CHECKLOG
carries the refutation as it happened):
[sources/distill_SHABBOS_OPS_20260718.md](sources/distill_SHABBOS_OPS_20260718.md). Audits:
[sources/distill_PRIOR_GEN_MODE_AUDIT.md](sources/distill_PRIOR_GEN_MODE_AUDIT.md),
[sources/distill_PRIOR_TOP1_CALIBRATION.md](sources/distill_PRIOR_TOP1_CALIBRATION.md),
[sources/distill_INPUT_EXPOSURE_HISTORY.md](sources/distill_INPUT_EXPOSURE_HISTORY.md). Fresh
curve tallies: [sources/curve_snapshot_20260719.txt](sources/curve_snapshot_20260719.txt). The
design's deliberate first-time choices: [sources/FLYWHEEL_DESIGN_LEVERS.md](sources/FLYWHEEL_DESIGN_LEVERS.md).)*

**The recipe** (mechanism in phase1/B.6): stage-1 distills the **fair production champion's search
output** (pooled root-visit distributions at full k4×688=2752 budget) into the sighted 81ch/42
net's **policy head**; the **value head is trained on outcomes but severed** (search value = the
**frozen curve125 champion leaf**, always); stage-2 self-play runs **net-policy-priors +
frozen-leaf** generation fair (PIMC k4) at **200 sims/det (¼ production budget)** with a
**12-iteration replay window** and no strength gate. A pre-run audit
(`distill_PRIOR_GEN_MODE_AUDIT.md`) established that **every previous net in the project had been
clairvoyant-trained** — this is the first fair-trained lineage.

| step | FACT | team's call |
|---|---|---|
| **Stage-1 distillation (07-16)** | top-1 agreement with the fair champion: 0.32 (warmstart) → **0.60** ≈ 80% of the ~0.75 teacher-vs-teacher agreement ceiling; the old neural champion `iter8` retro-scores ~0.37 on the same probe. Sighted vs non-sighted: **tie** (bag adds nothing detectable; ~3pp noise floor; consistent with the CL-050 bag-blind control ~95%) | distillation works; the bag stays for optionality only |
| **Equal-sims screen (07-17)** | distilled-net priors + frozen leaf vs the fair champion, same 2752 budget/leaf (pure prior-swap): **+88.7 elo, n=100, z=1.92**; the net costs ~2.2×/move at batch-16 | a screen with a known-collapse statistical profile → confirm demanded |
| **Stage-1 confirm (row `distill_s1_confirm_n200`)** | n=200 paired at production budget: **exact 100-100-0 TIE, avg margin +1.87** | the screen regressed exactly as pre-registered caveats warned. **Distillation is FAITHFUL at production depth, not superior.** The flywheel must now *exceed* the teacher |
| **Stage-2 viability flywheel (07-17→18)** | **17 iterations (4–20) trained unattended in ~25h** on 2 boxes (~78 min/iter, zero crashes; 300 games/iter) | the viability question was "does self-play improve the net at all, and does it plateau early?" |
| **The full 8-point curve vs the fixed out-of-lineage anchor `rodv2_iter02`** (rows `eval_iter{07,09,11,13,14,16,18,20}_vs_rodv2iter02`; each n=200 deck-paired, k2×200, seed band 13.0e9; full tallies + deltas: [sources/curve_snapshot_20260719.txt](sources/curve_snapshot_20260719.txt)) | **it7 +17.4 (z=0.71) · it9 +8.7 (0.42) · it11 +10.4 (0.42) · it13 +49.0 (2.00) · it14 +26.1 (1.00) · it16 +88.7 (3.65) · it18 +15.6 (0.62) · it20 +17.4 (0.71)**. Shape: **flat (7–11) → rise (13–16, NON-monotone: it14 sits below it13; every single-step deck-matched delta sub-2σ) → back to tie (18–20; it18 ≡ it20, deck-matched z=0.02)**. it16→it18 −3.48±1.78 (z=−1.95); it16→it20 −3.43±1.87 (z=−1.83) | at first read (07-18 night): "the first statistically decisive out-of-lineage anchor win by any learned lineage" (it16, z=3.65). **That claim did not survive the next morning's pre-registered follow-ups — next three rows** |
| **Pre-registered continuation branch (decided BEFORE the it20 result landed)** | GO-bar: deck-matched it16→it20 ≥ +1.5 pts/deck → blind continuation iters 21–28. Measured: **−3.43** → bar FAILED → **Plan B fired**: no blind continuation (wall-clock preserved; continuation can resume from `iter_20.pt` at any time) | the pre-registration held against the temptation to keep training |
| **Plan B — production-depth washout check (row `eval_iter16_vs_rodv2iter02_PROD_DEPTH`)** | it16 vs the anchor at **k4×688 (production budget) on the SAME 100 decks**: **100-99-1, +1.7 elo (z=0.07)** vs +88.7 at k2×200; per-deck margin +8.19 → +1.15; deck-matched depth delta **−7.04±4.09 (z=−1.72)** | **WASHOUT CONFIRMED** — the shallow gain does not survive production depth; the deepteacher precedent (C.3: +82.8/z3.48 @s200 → +8/z0.34 @s800) replicates. Low-depth policy gains are now depth-local twice-over in this record |
| **Fresh-deck extension — the replication test (rows `eval_iter{16,20}_vs_rodv2iter02_EXT132`, band 13.2e9)** | **it16 on 100 fresh decks: 98-100-2, −3.5 elo (z=−0.14)** vs +88.7 on band 13.0e9 → **cross-band discrepancy z=2.60 — the peak FAILED replication**. The **it20 control REPLICATED** (+26.1/z1.06 vs +17.4/z0.71; pooled n=400 +21.7/z1.25). The deck-matched it16−it20 delta **flips sign across bands** (+6.86±3.74 → −5.91±4.14). (it16 pooled n=400 = +41.9/z2.40 — but pooling inconsistent halves is exactly the trap the extension exists to catch) | ❌ **the +88.7 "breakout" is RETRACTED as a winner's-curse noise-crest** — the selected max of 8 curve points, killed by the pre-registered extension; the identical statistical shape to the documented t020/CL-057 collapse (C.8). The original results row carries a REFUTED stamp |
| **Final verdict of the arc ([sources/DECISIONS_excerpt_2026-07_arc.md](sources/DECISIONS_excerpt_2026-07_arc.md), 2026-07-19 entry; CL-058 as amended)** | the flywheel **HELD anchor tier** across all 17 iterations (a noisy tie-band; the stage-1 production-budget exact tie vs the fair champion stands and is the arc's real deliverable) but produced **no robust growth at any iteration, at any depth**. The window-aging "late growth" mechanism story is **moot** (no rise left to explain) | trigger (a) of the pre-registered decision rule fired negative; the open problem for any restart is trigger (b): **exceed the anchor at production depth** — which policy-only gains demonstrably cannot do even when present at shallow search |
| **Known cost asymmetry** | the net-prior agent costs ~2.2× the champion per move (batch-16); an equal-wall-clock comparison would give the champion ~2.2× sims (~+70–80 elo on the fair ladder) | equal-sims wins ≠ equal-compute wins; deployment pricing still open |

**The 7 first-time design choices** ([sources/FLYWHEEL_DESIGN_LEVERS.md](sources/FLYWHEEL_DESIGN_LEVERS.md) —
written 07-18 as candidate causal levers for the growth signal, then amended 07-19 with the
refutation; the packet carries the corrected version): (1) **severed value loop** — search value is the
frozen champion leaf; the net's value head is never consulted; (2) **strong-teacher warmstart** —
stage-1 distills the champion's *search output* at full budget, not weak-teacher data; (3) **FAIR
(blind-PIMC) teacher** — first fair-trained lineage; (4) **policy targets = pooled root-visit
counts** across the k determinizations; (5) **sighted 81ch/42 representation** (no distillation
gain; kept for optionality); (6) **cheap generation (k4×200 = ¼ production budget)**; (7)
**12-iteration replay window**. The memo's window-aging "late growth" timing hypothesis is **moot
post-refutation** (there is no late growth to explain). The choices remain the honest description
of what this recipe did differently from every dead predecessor — what they now explain is a
flywheel that *held* its teacher's tier without collapsing, not one that grew.

## C.10 Where things stand (2026-07-19, packet time — the flywheel arc closed the same morning)

- **Production champion (unchanged through the whole flywheel arc):** deep-classical
  `HeuristicPriorAgent` — PUCT + heuristic-leaf priors (c=1.5, τp=5, reuse), leaf **v2.9.2
  curve125**, ~2750 sims, fair PIMC **k4×688** pooled-Q, exact marginalized K≤2 endgame
  ([sources/PRODUCTION.yaml](sources/PRODUCTION.yaml)).
- **Classical levers:** leaf terms (C7), search knobs (T3), determinization width (k_dets) — all
  now closed (two nulls, one cost-neutral fold). The one *proven* open classical lever is **deeper
  fair search** (the fair ladder scales through 5504 sims), which is compute-priced.
- **The flywheel arc is closed with a two-part verdict.** What stands: **distillation is faithful**
  — a first-of-its-kind fair-trained net whose policy priors exactly tie the production champion
  at full budget (the stage-1 100-100-0 confirm), and 17 self-play iterations that **held** that
  tier without collapsing (every dead predecessor either cratered or was never at tier). What was
  retracted: the growth claim — the it16 "+88.7 breakout" failed fresh-deck replication
  (cross-band z=2.60; the it20 control replicated) and washes out to +1.7 (z=0.07) at production
  depth. **No robust growth at any iteration, at any depth.** Training is paused, resumable from
  `iter_20.pt`; the open problem (CL-058 trigger (b)) is a variant that exceeds the anchor **at
  production depth**.
- **Twice-demonstrated now:** low-depth policy-prior gains do not transfer to deep search
  (deepteacher 2026-06; the flywheel washout 2026-07-19). Any future flywheel bet has to answer
  this specifically.
- **Still true, and unchanged all project:** no human-anchored measurement of anything exists; no
  usable external bot anchor exists; the exact solver (endgame-only) is the only non-circular
  ruler; the champion is deployable against humans and that exam remains unfunded/deferred.
- The owner's request for this review: **"where should the project head next, and what have we
  missed?"** This is the fifth external review; the packet's phase structure exists so you don't
  inherit the first four's frames — they are deliberately excluded.
