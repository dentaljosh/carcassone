# The 7 design levers — the distill-flywheel recipe record (as CORRECTED 2026-07-19, post-refutation)

> Team memo, reproduced verbatim from the project auto-memory (`project_flywheel_design_levers.md`).
> Originally written 2026-07-18 to explain an apparent growth effect; amended 2026-07-19 after the
> refutation. The correction header is part of the record.


⚠️ **CORRECTED 2026-07-19 (CL-058 as amended):** the growth this memory originally
credited to the recipe was NOT real. The it16 "+88.7 breakout" failed the pre-registered
fresh-deck extension (band 13.2e9: −3.5 elo z=−0.14; cross-band z=2.60; the it20 control
replicated; the deck-matched it16−it20 delta flipped sign across bands) — a textbook
winner's curse over 8 curve points, and it also washed out at production depth
(k4×688 same decks: +1.7). What the run DID establish: **stage-1 distillation is
faithful** (net policy priors TIE the fair champion at production budget, 100-100-0)
and the flywheel **held** anchor tier over 17 self-play iters without collapsing.
It never exceeded it.

The 7 recipe choices no prior flywheel had (still the reference recipe for restarts —
but there is no growth effect to ablate toward; the open problem is CL-058 trigger (b):
exceed the anchor AT PRODUCTION DEPTH):

1. **Severed value loop** — search value = FROZEN curve125 champion leaf; net value
   head trained on outcomes but NEVER consulted. Sidesteps the learned-value <
   heuristic-leaf ceiling. Improvement channel = policy priors only — and this is
   now the suspected LIMITER: policy-only gains wash out at depth even when present
   at k2×200, so **stage-3 value-unlock is the sharpest restart bet**.
2. **Strong-teacher warmstart** — stage-1 distilled the fair champion's SEARCH
   OUTPUT (root visit distributions @ k4×688=2752), not weak-teacher data.
3. **FAIR (blind-PIMC) teacher** — first fair-trained lineage (PRIOR_GEN_MODE_AUDIT:
   every earlier net was clairvoyant-trained → strategy fusion).
4. **Policy targets = pooled root-visit counts** from the fair k4 search.
5. **Sighted 81ch/42 rep** kept for bag-optionality (no distillation gain observed).
6. **Cheap gen (k4×200 = ¼ production budget)** — under this budget the flywheel
   held tier but did not grow; whether full-budget gen changes that is untested.
7. **12-iter replay window** — the window-aging "late growth" story built on it is
   MOOT (no real late growth to explain).

**Why:** any flywheel restart should start from this recipe record plus the refutation
history, not from the optimistic 07-18 read. See [[rodv2-iter2-eval-anchor]],
[[feedback_sims_washout_net_eval]] (depth-check before believing any low-sims gain),
[[feedback_results_table_source_of_truth]] (the extension-kills-spike house pattern:
t020/CL-057, now it16/CL-058).

**How to apply:** before changing the recipe, note which lever the change touches;
demand survival at PRODUCTION depth (k4×688) and on a FRESH deck band before calling
any future curve point real. Full record: measurement/distill_flywheel_20260715/
SHABBOS_OPS_20260718.md + results.csv eval_iter*_vs_rodv2iter02* (incl. _EXT132 +
_PROD_DEPTH rows) + DECISIONS 2026-07-19.
