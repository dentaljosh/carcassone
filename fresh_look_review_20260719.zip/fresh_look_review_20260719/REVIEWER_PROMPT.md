# Reviewer Prompt — Fresh-Look Review (first principles, round 4)

> Step-0 material: role, deliverables, ground rules. Contains no results. The operational way to
> run this in one shot is [KICKOFF_PROMPT.md](KICKOFF_PROMPT.md) (paste it to an agent with file
> access; the phase directories enforce the blindness). A human reviewer follows the same order.

---

You are an independent expert reviewer — assume deep familiarity with AlphaZero-family methods
(AZ/MuZero/Gumbel/KataGo), classical game AI (search, evaluation, imperfect information), and the
practice of ML experimentation. A small team has spent ~13 weeks trying to build a **genuinely
superhuman 2-player Carcassonne agent, preferably via a self-learning flywheel.** For most of that
time every attempt to make the *learned* components carry strength past a hand-crafted baseline
failed, and by mid-July the classical improvement levers had run dry as well. In the days
immediately before this packet, a differently-constructed flywheel briefly produced what looked
like the project's first real self-play growth — and the team's own pre-registered follow-ups
(a fresh-deck replication and a production-depth check) then **refuted the growth claim** the
next morning. What survived is a distilled net that exactly ties the hand-crafted champion at
full budget without exceeding it, and a project with no obviously-live strength lever.

They are NOT asking you to referee a single experiment, and they are NOT asking you to co-sign
either their brief excitement or their retraction. They are asking:

> **Take a fresh look from first principles. Where should this project head next, and what has
> been missed — in the game-theoretic setup, the architecture, the training signal, the search,
> the evaluation methodology, the scale, the new flywheel's design, or the framing of the goal
> itself?**

## The phase protocol (strict)

**Phase 1 — blind diagnosis** (materials: `phase1/` only — goal/game, system description, and the
actual source code; you have NOT yet seen any results or conclusions):
1. List every design decision that strikes you as non-standard, questionable, or wrong **for the
   stated goal** — from game-theoretic structure down to encodings, formulas, targets, and
   constants. Read the code, not just the prose; flag anything the prose undersells.
2. Predict where this system's strength ceiling comes from, and why.
3. Say what you would build (or change first) if this were your project, at their resources.
4. Name the five cheapest measurements you would run first and what each decides.
Commit this list in writing before proceeding.

**Phase 2 — collision with the record, then your COMPLETE report** (materials: `phase2/`):
For each Phase-1 suspect: tested or not? If tested — convincingly? (Check n, pairing, sims regime,
baselines, which *ruler* scored it — the record documents one ruler that turned out to be circular
and one fair-play agent that turned out to leak — and whether the *right variant* of the idea was
the one tested. This applies to kills in **both directions**: audit the team's retraction of its
newest positive result with the same rigor as its older kills.) Produce three lists: **(i)** suspects
fairly killed; **(ii)** suspects tested inadequately (say what a fair test looks like);
**(iii)** suspects never tested at all. Then — still without opening `phase3/` — write your
**complete, final report** (all deliverable sections below). It is final as of the end of this
phase; Phase 3 may only append.

**Phase 3 — cross-check, as a labeled addendum only** (material: `phase3/`):
The team's conclusions, open decision questions, and self-critique are sequenced last precisely so
they cannot anchor your report. Append a **PHASE-3 ADDENDUM**: (1) a doubt-by-doubt verdict on the
team's own doubts (endorse / reject / qualify, with reasons); (2) direct answers to the team's
open decision questions, insofar as your Phase-2 report has not already answered them; (3)
anything on **neither** your list nor theirs — the most valuable possible output; (4) explicit
labeled amendments ("AMENDED: … because …") if the appendix genuinely changes any of your
conclusions — no silent rewrites.

## Deliverables (the report is written at the END of Phase 2; Phase 3 appends the addendum)

- **BLIND DIAGNOSIS** — your Phase-1 output, unedited by hindsight.
- **FACTS** — what the record actually establishes (cite `phase2/sources/` files / result rows),
  kept sharply separate from what is merely suggested by partial or single-band data.
- **THE MISSED THING** — your top 1–3 candidates for what has been missed. For each: the claim,
  why everything observed to date is consistent with it, and the **cheapest decisive experiment**
  (design, metric, success/kill criterion, rough cost at their resources).
- **VERDICT AUDIT** — which team kills were fair; which were premature and exactly what would
  reopen them. This includes the newest kill: was the retraction of the flywheel growth claim
  correctly reasoned by the team's own statistical rules, or over- or under-drawn?
- **THE PATH** — a prioritized, concrete plan toward superhuman play from exactly where the
  project stands (with a self-learning flywheel if you honestly believe one is available; without,
  if not — say so plainly). Include how superhuman would be *established*, not just reached, given
  no human-anchored measurement exists yet.
- **STOP RULES** — the evidence that should make the team (a) declare the self-learning dream dead
  for good, and (b) declare superhuman reached.

## Ground rules

- Statistical floor: deck-paired head-to-heads; n=400 ≈ ±17.5 elo (1σ), n=200 ≈ ±24.6, n=100 ≈
  ±35; **a lone value that beats its parameter- or iteration-neighbors by ~1–2σ is a noise
  signature, not a peak** — the project's own record contains multiple confirmed instances.
  Offline metrics and in-game strength have dissociated repeatedly in this project — in both
  directions, and for both learned and hand-crafted components; treat any offline→online inference
  as suspect. Policy-head gains measured at low search depth have now vanished at high depth
  **twice** in this project's record; treat any low-depth gain as depth-local until shown
  otherwise.
- Be adversarial about designs and interpretations — in both directions: the team has retracted
  its own newest favorable result, and both the original claim and the retraction are auditable —
  but do not manufacture doubt about heavily replicated measurements. If the honest answer is
  "the retraction is right and the dead end stands," or "something real is being thrown away,"
  give that answer with the same rigor.
- The goal is a superhuman **agent**. Whether any particular component must be learned is a means
  question — treat it as open in both directions.
