# 3 — What Was Tried (Chronological Arc)

**FACT** = a measured number or a code/config reality. **INTERPRETATION** = the team's reading of
it. The two are labeled throughout so you can accept the facts and reject the readings.

Numbers cite [sources/results_csv_relevant_rows.csv](sources/results_csv_relevant_rows.csv) (rows
named in `04_RESULTS_DIGEST.md`) and the per-pilot verdict docs in [sources/](sources/).

---

## 3.1 The heuristic leaf evolved faster than the network ever did

| Leaf | What changed | Headline (FACT) | Team verdict (INTERPRETATION) |
|---|---|---|---|
| **v2.5** (2026-05-14) | First swept `virtual_score`; cap/closure tuned; dedup bug fixed | ~80–90% vs Tier-1 after re-tune | Usable leaf; enabled the whole self-play program. |
| **v2.7** (2026-05-17) | Closure-anticipation + farm-scoring refinements | The baseline everything is measured against | "The ceiling" — strong-human-level by construction. |
| **v2.8** (2026-06-22) | Turn on a **flat meeple-economy term** (`meeple_k=2`) | Heur **+179.5 elo @200**, **+94.9 @800**; neural `iter8+v2.8` vs `iter8+v2.7` **+154.5**; **but** `iter8+v2.8` vs `heur@3200+v2.8` (equal leaf) = **−38.4** | A **real, large classical-engine gain** that lifts heuristic, neural, and hybrid roughly uniformly — i.e. it raises the floor for *everyone*, so the learned agent **still loses to deep search at equal leaf**. "Not an ML/superhuman lever." |
| **v2.9** (2026-06-25) | Replace flat meeple term with a nonlinear curve (`Bmild`) + retuned `cap8` | Throne test vs real v2.8 prod = **0.579 wr / +55 elo / z+3.94**, depth-robust | Another real classical leaf win; **neural transfer untested**; not promoted (production still v2.7). |

> **INTERPRETATION (team):** the leaf kept finding real gains by hand; the *learned* components
> never produced a comparable structural gain. **A reviewer should note the asymmetry** — months of
> human leaf-tuning vs a handful of small, short network training runs (file 06, Assumption E).

## 3.2 The flywheel attempts

| Date | Run | What it tested | Headline (FACT) | Verdict (INTERPRETATION) |
|---|---|---|---|---|
| 2026-05-14 | warmstart + v1–v6 recipes | NN-value-leaf self-play | v1–v6 plateaued; a **pure NN-value leaf scored ~−800 elo** | NN-as-sole-value is catastrophic; reverted to the heuristic leaf. |
| 2026-05-20 | anchor-fraction + c_puct | eval-time knobs | "c=3 +47 elo" → re-validated to **+18.5** at n=1600 | Most knobs are flat at proper n; a famous **noise-spike lesson**. |
| 2026-06-07 | **residual flywheel, attempt 1** | residual value head | +14.3 elo cumulative over 3 iters (within noise) | No flywheel; gated by an unreliable in-lineage metric. |
| 2026-06-10 | **residual flywheel, attempt 2 → champion `iter8`** | residual value head, sealed external ruler | `iter8` vs incumbent **+67.4 / z2.73**; vs `heur@800` **+58.7** (n=400, sealed band) | **Real but bounded.** Decomposition: the gain is **~95% policy distillation**, plateaued by iter5; the **residual value contribution is static (~+22) and non-growing**. Not a ceiling break. |
| 2026-06-17 | **deepteacher** (sims=800 teacher, 12 iters from iter8) | deeper policy teacher | `iter12` vs `iter8` = **TIE** (+14.6 @200, +12.4 @800, both z<1) | A clean powered-null: a deeper teacher does not raise strength. **Note:** earlier "+82.8/z3.48" numbers were a *provenance defect* (wrong baseline); the corrected comparison is a tie. |
| 2026-06-22 | **RoD ("Revenge of Demis") — v2.8 continuation** | does the *stronger leaf* restart compounding? | `RoD_iter_01` vs **frozen `iter8`** (both v2.8) = **+53.4 / z3.51 — the FIRST continuation to ever beat its parent**; vs `heur@3200+v2.8` (equal leaf) = **TIE / parity** | **The v2.7 leaf *was* a real ceiling** — a stronger leaf unstuck a gain v2.7 could not. **But** the agent only reached **parity** with deep search, did not **exceed** it → not superhuman. |
| 2026-06-23 | **v2.8 overnight flywheel** (16 continuation iters) | does the +53 compound past parity? | best iter `iter08` = **+33.1 / z2.0** over its parent internally, but vs `heur@3200+v2.8` (n=800) = **+6.5 / z0.53 = TIE**; tail iters 11–17 no better | Compounded a **modest internal gain that washed out non-transitively** against the external ruler — sits at the same heuristic parity. An autopsy localized the residual gap to the **endgame** and found the internal gain was a concentrated "rock-paper-scissors" tail (top 10% decks = 132% of the margin). |
| 2026-06-27 | **RoD v2** (current branch, v2.9 leaf) | does the *v2.9* leaf restart compounding? | iters 02–06 **all LOSE to `h6400+v2.9`** (−22…−32 elo), no climb across iters | **Confirmed NULL — "the v2.9 leaf swap changed nothing."** Reproduces the v2.8 autopsy exactly. **DECISION: stop the AlphaZero-style blind flywheel; classical v2.9 is the strength.** |

> **The arc the team reads from this:** raising the leaf raises the *floor* (everyone gets stronger,
> the learned agent reaches parity with deep search) but never lets the *learned* part get **above**
> deep search. So the flywheel "compounds the heuristic, not beyond it."

## 3.3 The six recent "can a learned component beat the leaf?" pilots

After RoD v2 was called null, the team ran six tightly-scoped, **measurement-only** pilots (no
promotion, champion unchanged) on the `rod_v2_flywheel` branch, each attacking a different learned
object. Verdict docs are in [sources/](sources/).

| Pilot (CL-#) | The question | Headline (FACT) | Verdict (INTERPRETATION) |
|---|---|---|---|
| **Hard-policy repair** (CL-030) | Can h6400-labeled exposure fix the policy on hard states? | One-hot **memorizes train (0.775) but generalizes to 0.061**; "disagreement" states have near-tied Q (gap 0.002 vs 0.040) | The target is **signal-free** there — "disagreement" selected value-*indifferent* states, not deep ones. (decision A) |
| **High-gap distillation** (CL-031) | Distill the high-Q-gap decision signal into the policy | Signal exists, learnable, generalizes (prior top1 **0→0.18**); but games R2 vs h6400 = **WR 0.409 / −64 elo** (below parent) | Learnable but **does not convert through search**; policy distillation is a dead end for strength. (decision B) |
| **Value/search autopsy** (CL-032) | *Where* does the learned stack fail? | Value head **inert** (residual scale 0/0.25/0.5 indistinguishable); the **policy prior makes worse root decisions than bare classical search** (h6400-agreement: classical-h200 0.911 > neural 0.799); **yet** classical-h200 vs neural at matched compute (n=96 paired) = **WR 0.438 / z−1.19 = NS** | **The headline correction:** root-level metrics **do NOT predict game strength** — the net is game-*neutral*, not game-harmful. Binding constraint = search depth + a value head that beats the leaf. (decision D) |
| **Value resurrection** (CL-033) | Can a learned value/ranking beat the v2.9 leaf at sibling ordering? | Best blend weight **α=0 for every variant**; net τ peaked **0.105** vs leaf **0.895**; **endgame no exception** | Value head **stays inert** against the stronger v2.9 leaf + deeper h6400 teacher. (decision B) |
| **Feature-graph comparator** (CL-034) | Vary the **representation** — explicit action/structure features + a sibling-relative learned ranker | **Offline gate PASS — the FIRST learned ranker to beat the static leaf:** full-pool decisive regret **−41%** (linear), top1 0.464→0.535, decisive tail −44%/−52%; **reverses** CL-033's α=0. **But the search screen FAILED:** no integration beats `search_leaf`; all α>0 regress | **Washout:** search alone already cuts the leaf's decisive regret ~6× and explores every sibling at 200 sims, so the offline win is **behind** search. "A learned component must beat what **search** extracts, not what the **static leaf** misses." (decision C) |
| **Feature-graph search-residual (GNN)** (CL-036) | A typed GNN on the **post-search residual** (`h6400 − h200`) | Offline gate FAIL; a flat MLP matches/beats the GNN; **ablation: zeroing the graph embedding *lowers* tail regret → the relational structure is INERT**; ~20% of the decisive tail is structurally blind even to a perfect leaf-readoff | The relational redesign does not learn the post-search residual either. (decision B) |
| *(companion)* **Post-search residual / adaptive compute** (CL-035) | Predict *when* to search deeper | Oracle gate passes (+92.5% at matched compute) but a **one-line heuristic captures the signal**; learned ML does not robustly beat it; magnitudes tiny | No ML scheduler justified; possible compute-*efficiency* tool, not a strength lever. (decision C) |

> **INTERPRETATION (team):** these six converge on the same wall — *learned components are at best
> redundant with what shallow search already extracts from the heuristic leaf.* The comparator
> (CL-034) is the one genuinely new data point: a learned ranker with **explicit structural
> features finally beat the leaf offline** — but it washed out under search. **A reviewer should
> weigh whether "washes out in a fixed-sims offline screen" is the same as "would not compound in a
> full self-play loop"** (file 06, Assumption C).

## 3.4 The measurement story (why the team calls measurement "blocker #1")

| Stage | FACT | Consequence |
|---|---|---|
| Early | Tier-1 (1-ply heuristic) was the opponent | **Saturated**: self-anchored / chain-vs-prev elo can climb hundreds of points while absolute strength regresses. Abandoned. |
| 2026-05-31 | Pivot to **HeuristicMCTS** (UCT + v2.7 leaf, no learned policy) as a non-saturated reference | First trustworthy absolute signal; iter_11 beat matched-sims heuristic. |
| 2026-06-07 | **Clean-eval audit**: runtime-verified evaluator provenance (R1/R7 guards), 11 semantic contracts, re-judged old claims | Established a "trustworthy ruler"; some historical claims invalidated. |
| 2026-06-19+ | The heuristic ladder is **not saturated** — deeper search keeps gaining (+76→+55→+35 per doubling through @3200). **`iter8` is *caught* at @3200** (−28.7), and **RoD_iter_01 LOSES to `h6400`** (−45.4) | Adopt **`h6400`** as the non-saturated reference for learned-agent gates. |
| Throughout | n=400 paired ≈ ±17.5 elo; deck-pairing halves variance; "screens" (n=100) systematically over-state | Institutionalized n-discipline; several "wins" were single-screen noise. |

> **INTERPRETATION (team):** every elo in this project is **clairvoyant and in-ecosystem** (built on
> the v2.7-family leaf). The clairvoyance *strength* gap was measured small (~+27 elo, CL-022), but
> "beats strong/expert humans" is **literally unmeasurable** without an external/human anchor, which
> the team does not have. Hence "measurement is the blocker on the *claim*." **A reviewer should
> decide whether it is also a blocker on *progress*** (file 06, Assumption D; reviewer question F).

---

## 3.5 The charter arc (2026-06-29 → 07-01) — the previous review's experiments were actually run

The 2026-06-29 packet went to an outside reviewer. The review's recommendations were integrated
into a **pre-registered charter** with an explicit program-level decision rule
([sources/CHARTER_INTEGRATED_REVIEW_PLAN_2026-06.md](sources/CHARTER_INTEGRATED_REVIEW_PLAN_2026-06.md),
"§10"): abandon AZ-style self-learning **iff** (a) the representation gate fails **and** (b) the
weaned flywheel fails; *"if (a) passes but (b) fails: value can rank but can't drive search — keep
the analyzer, representation was the issue."* Both gates then ran. Everything below was
**measurement-only** (champion / production unchanged).

| Step | The question | Headline (FACT) | Verdict (INTERPRETATION) |
|---|---|---|---|
| **Step 1 — representation gate ("Gate A", CL-037, 2026-06-29)** | Was the value head's inertness a *representation* confound? Add **farm-connectivity planes (+3)** and a **per-tile-type bag histogram (+32 scalars)**, rerun the exact CL-033 sibling-ranking protocol | `both`: τ 0.207, **α=0.05 > 0**, held-out regret **−20.5%** vs blind baseline's −1.9%; **negative control (shuffled planes) collapses to +0.0% / α=0**; ablation: farm-only −17.1%, bag-only −19.7% (**largely redundant**) | **PASS — CL-033's "α=0 as a law" refuted.** The representation *was* part of the inertness. The **bag** is information the heuristic *structurally cannot see*, and alone recovers ~the whole effect. Also: a cheap explicit-feature model beats the dense board-CNN at this task → Step 2's value head made **structure-aware** (89 scalars), not a CNN. First genuine learned-value positive in the program. |
| **Step 2 — weaned-value-leaf flywheel ("Gate B", CL-038, 2026-06-30)** | Does the sighted value **convert through search** when the heuristic is weaned out of the MCTS leaf and the learned value in — gated on **games**? | The sighted value **ranks well at every tree depth** (interior τ: d1 0.42 / d2-3 0.45 / d4-7 0.43; **+43% offline**) — yet at blend 0.27 play **craters vs its own parent**: MSE arm **0.212**, ranking arm **0.287**, frozen arm **0.215** win-rate (≈ **−160 to −246 elo**, paired, n=100–172, ~5–7σ) | **FAIL — "genuine Gate B."** Three pre-registered **nails** killed the recoverable readings: (1) interior-τ flat across depth → *not* a train/serve distribution mismatch; (2) an **additive** leaf (heuristic at full weight + value added) craters too → it's the value's *addition*, not the heuristic's removal; (3) a **frozen** never-retrained value craters identically → not retraining drift. **"The value can RANK but cannot DRIVE search."** The verdict itself survived an external challenge (a reviewer caught the in-loop τ was depth-1-only → that *became* nail 1) and a 3-round code review (5 bugs found+fixed; crater results verified not poisoned). |
| **Probe A — structured value leaf (killed at §3A, 2026-07-01)** | Was the *scalar* value output the bottleneck? Build a 24-dim **per-component structured** value emit (feasible: 2.2–2.7× leaf cost, bit-exact Cython) and re-run the farm/bag independence gate on the structured head | Δ_indep = both − max(farm-only, bag-only) = **+0.05pp** (paired σ 0.36, CI [−0.61, +0.78]) vs a pre-registered **≥+3pp** "separated" bar — **~8σ below** | **KILLED at the cheap gate** (no in-loop budget spent). Farm/bag stay redundant in the structured object too → the residual value signal beyond the leaf is **genuinely low-dimensional**; the scalar wasn't the bottleneck. |
| **Probe B — fair-information flywheel (closed on the ledger, 2026-07-01)** | Is Gate B a **clairvoyance** artifact? Train the same head on **fair (12-determinization-averaged)** vs **clairvoyant** targets at matched depth 800 — one-variable-clean (datasets bit-identical except the target) | Full-n (n_test=1544): **ALL SIX arms inert** (α=0, +0.0%) — *including clairvoyant*. (An n=150 preview said "clair non-inert" — refuted at full n as an 8-group artifact.) CL-037's α>0 needed the **h6400-deep** teacher; at depth 800 even clairvoyant targets add nothing | **Depth-saturated → inconclusive alone**; the clairvoyance question is *deliberately left unresolved*. The flywheel bet was closed **on the accumulated ledger** (CL-029/032/033/034/036/038 + Probe-A §3A), not on this screen. **Deliverable: B1** — a leak-fixed, deployable **fair-information (non-clairvoyant) agent**, i.e. the first human-anchorable artifact. |
| **Probe §5A — tempo/timing third axis (IN FLIGHT at packet time)** | The "low-dimensional" claim rests on two *mutually redundant* axes (farm, bag). Does it survive a third, uncorrelated-by-construction axis — **tempo/timing** (depth-weighted meeple lockup, closure races)? | Gate-zero: naive structural counts are ≥0.72 reconstructible from existing features (dropped); a **10-feature residualized tempo core survives** (mean R² 0.28) → proceeding to the 4-arm head at h6400 | **PARTIAL / RUNNING** — [sources/measurement_probe_5a_PROBE_5A_RESULTS.md](sources/measurement_probe_5a_PROBE_5A_RESULTS.md) is included as-is with its verdict section empty. |

**The resulting decision (CL-039, 2026-07-01):** the AZ-**value** route is exhausted across
**scalar / structured / clairvoyant / fair** → per the charter's own §10 branch, **ship the
analyzer** (endgame-2 — the original prompt's Phase-5 win condition), served by the proven sighted
value head, with **B1** as the deployable agent. The team's own scoping note: *"Gate-B closes the
weaned-learned-value-LEAF lever, NOT the superhuman goal — fresh approaches remain open."*

> **For the reviewer, three things to notice about this arc.** (1) It is by far the most rigorous
> work in the project — pre-registered gates, negative controls, adversarial code review,
> nails-vs-alternatives. (2) The previous review's central challenge (representation) was **right**
> offline and then **bounded** by games — both packets' framings partially survived. (3) The new
> load-bearing joints are different ones: *why* a value that ranks at every depth craters as a leaf
> (no positive mechanism was identified — the nails only excluded three); whether "low-dimensional"
> can be claimed from two redundant axes (§5A pending); and whether closing a *route* on an
> accumulated ledger of individually-limited screens is sound. Those are file 06's subjects.
