# 5 — The Team's Current Conclusions (all INTERPRETATION)

Everything here is the team's **reading** of the facts in files 03–04, stated plainly so you can
attack it. Each carries the team's own confidence. **Treat none of it as established for the
purpose of your review.**

## 5.1 The load-bearing beliefs (updated 2026-07-01)

**C1 — The value head's historical inertness was partly a representation confound (Gate A).**
Farm-connectivity planes + a bag histogram flip the old α=0 result; the bag axis is information the
heuristic structurally cannot see. The learned value is a real — weak — *sighted ranker* (offline
−20.5%; interior τ ≈ 0.43 at every tree depth on the Step-2 substrate).
*Team confidence: high (pre-registered, negative-controlled, ablated).*

**C2 — But the sighted value cannot DRIVE the MCTS leaf (Gate B, "genuine").** Weaning the heuristic
out and the value in craters games by −160…−246 elo vs its own parent, across MSE / ranking /
frozen objectives, with three nails excluding distribution-mismatch, heuristic-subtraction, and
retraining-drift as escapes. *Team confidence: high — this is the most adversarially-vetted result
in the project (external challenge absorbed as nail 1; 3-round code review; 5 bugs fixed; craters
verified not poisoned).* **Note what is NOT claimed: a positive mechanism.** The nails say what the
crater *isn't*; nothing yet says what it *is*.

**C3 — The residual value signal beyond the leaf is low-dimensional.** Farm and bag are largely
redundant substitutes (Gate A ablation); a *structured* per-component head extracts nothing more
(Probe A §3A, ~8σ below the independence bar). *Team confidence: medium-high — and honestly
provisional: the claim currently rests on two mutually-redundant axes, and the third-axis test
(§5A, tempo/timing) was still running at packet time.*

**C4 — The AZ-value route is exhausted (scalar / structured / clairvoyant / fair) — closed on the
LEDGER.** No single screen carries the close (the fair-vs-clair screen in particular is depth-
saturated and inconclusive alone); the accumulated weight of CL-029/032/033/034/036/038 + Probe-A
§3A + the Gate-B offline→online mechanism does. *Team confidence: high on the conclusion; the
epistemics of ledger-closure are explicitly offered up for review (file 06, N2).*

**C5 — Decision: ship the analyzer (endgame-2) + B1.** Per the charter's pre-registered §10 branch
("value can rank but can't drive search — keep the analyzer, representation was the issue"): build
the original prompt's Phase-5 analyzer, served by the proven sighted value head, with **B1** (the
fair-information agent) as the deployable, human-anchorable artifact. *Team confidence: this is
the pre-registered fallback being executed as written.*

**C6 — Scoping note the team itself insists on:** Gate B closes the **weaned-learned-value-LEAF**
lever. It does **not** claim "superhuman is impossible" — "fresh approaches remain open" (a new
thread was to start on exactly that question). *This packet is that question.*

**Unchanged beliefs carried forward:** root/offline metrics do not predict game strength (now 4+
instances → gate on games); every number is in-ecosystem and (except B1) clairvoyant; no human
anchor exists; the heuristic ladder (h3200 → h6400 → h12800) is not saturated.

## 5.2 The resulting strategic stance

- Learned-value-driving-search: **closed.** Policy distillation: closed (prior arc). ML compute
  scheduler: closed. Relational/GNN heads: closed.
- Classical strength (the v2.9 leaf + deep search) is the program's strength, and classical leaf
  work keeps landing real gains — but the team treats this as "not the goal" under its
  "learned-must-exceed-heuristic" framing.
- The concrete next build is the **analyzer** + **B1**. Superhuman-strength work is paused pending
  "fresh approaches" — i.e., pending exactly the kind of outside input this packet requests.

## 5.3 What the team is *not* claiming

- Not that the agent is superhuman, nor that it beats deep heuristic search.
- Not that "no learned value can ever work" — only that every formulation tried (scalar, structured,
  clairvoyant-target, fair-target, weaned, additive, frozen) fails to *drive search* here.
- Not that the Gate-B mechanism is understood (only three alternatives excluded).
- Not that §5A's outcome is known (it was mid-run at packet time).

## 5.4 The question the team cannot answer about itself

> The charter told us to stop doing "more of what's already been done." We did the two experiments
> it prescribed instead; one passed, one failed, and we followed its decision rule to the letter.
> But the rule, the gates, and the interpretation all live inside the same frame: *superhuman via a
> learned value inside this MCTS, measured on our own heuristic-family rulers.* Is the frame itself
> the local minimum — and if so, what is the cheapest way out of it that still points at genuinely
> superhuman play?
