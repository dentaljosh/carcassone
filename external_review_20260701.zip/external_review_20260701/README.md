# External Review Packet — Superhuman Carcassonne AI (2026-07-01)

> **What this is.** A self-contained snapshot of an AlphaZero-style Carcassonne AI project,
> assembled for an **outside reviewer** with no prior access to the codebase. We want you to
> (a) look for **obvious mistakes** in the approach, and (b) suggest **how to move forward toward
> genuinely superhuman play, ideally with a self-learning flywheel**.
>
> **This packet supersedes three earlier ones** (2026-06-07, 2026-06-21, 2026-06-29). It matters
> this time more than usually: the 2026-06-29 packet **was reviewed externally, and the review's
> own prescribed experiments have now been run to completion.** The results went both ways — the
> review's central representation hypothesis was **vindicated offline**, and then the prescribed
> flywheel **failed decisively in games**. The team has since closed its "AlphaZero-value" route
> and decided to ship a fallback deliverable. Whether that closure and that decision are *sound*
> is precisely what we want reviewed.
>
> **The one thing we are most afraid of: a local minimum.** The team (and its AI assistant) have
> converged on a story. Facts are separated from interpretations throughout, and
> [06_ASSUMPTIONS_TO_CHALLENGE.md](06_ASSUMPTIONS_TO_CHALLENGE.md) hands you the load-bearing
> assumptions — including a scoreboard of how the *previous* reviewer's challenges fared — and
> invites you to break what remains.

---

## The 90-second orientation

- **Goal (since 2026-05-28):** genuinely **superhuman** play at **2-player Carcassonne, Base +
  Farmers** (no River, no other expansions). Aspirationally, beat the world champion — preferably
  via a self-learning flywheel.
- **Method:** AlphaZero-style — a ~7M-param ResNet (policy + value) guiding MCTS — **with a twist:**
  the MCTS leaf is evaluated by a *hand-crafted heuristic* ("v2.7"/"v2.9"), with the network's
  value contributing only a small residual. Strength has always been carried by search + heuristic.
- **What just happened (2026-06-29 → 07-01), the reason for this packet:**
  1. **Gate A (representation) — PASS.** Farm-connectivity planes + a bag histogram flipped the
     long-standing "learned value is inert (α=0)" result: with those inputs the value head becomes
     a real (weak) ranker (−20.5% held-out regret; clean negative control). The bag is information
     the heuristic *structurally cannot see*. The prior "value can't learn" conclusion was partly
     a **representation confound** — the previous review called this.
  2. **Gate B (conversion) — FAIL, hard.** The sighted value (ranks well at *every* tree depth,
     τ≈0.43, +43% offline) was then **weaned into the MCTS leaf** as prescribed — and **cratered
     play** (−160 to −246 elo vs its own parent at blend 0.27), across MSE, ranking, *and* frozen
     objectives. Three pre-registered "nails" ruled out distribution mismatch, heuristic-
     subtraction, and retraining drift. The verdict survived an external challenge and a 3-round
     code review. Team's phrase: **"the value can RANK but cannot DRIVE search."**
  3. **Two boxed follow-on probes closed the route.** A *structured* (per-component) value leaf
     died at a pre-registered independence gate (the residual signal is genuinely low-dimensional);
     a *fair-information* (non-clairvoyant) target arm came back all-inert but depth-saturated
     (inconclusive alone). The team closed the "AZ-value" route **on the accumulated ledger** —
     scalar/structured × clairvoyant/fair — and decided to **ship the analyzer** (the original
     project's win condition) plus **B1**, a deployable non-clairvoyant agent.
  4. **Still in flight:** a third-axis probe (**tempo/timing**, §5A) testing whether "the residual
     value signal is low-dimensional" survives an axis uncorrelated with farm/bag.
- **The team's bottom line now:** learned-value-driving-search is exhausted; classical search +
  heuristic is the strength; superhuman via learned value is closed; "fresh approaches remain open."

That bottom line is the team's **interpretation**. Your job is to decide whether it is *supported* —
and, since the goal is superhuman play rather than any particular method, whether the **route to the
goal** (not just the route that was closed) is being chosen correctly.

---

## How to read this packet (in order)

| File | What it gives you |
|---|---|
| [01_GOAL_SCOPE_AND_RULES.md](01_GOAL_SCOPE_AND_RULES.md) | The goal, the mid-project goal change, the locked rule scope, a Carcassonne primer. |
| [02_HOW_THE_SYSTEM_WORKS.md](02_HOW_THE_SYSTEM_WORKS.md) | The mechanism: engine, network, MCTS, the heuristic leaf, the self-play loop, the residual value head. |
| [03_WHAT_WAS_TRIED.md](03_WHAT_WAS_TRIED.md) | The full chronological arc — including §3.5, the **charter arc** (Gate A / Gate B / Probes A & B / §5A) that is new since the last review. FACTS vs INTERPRETATION labeled. |
| [04_RESULTS_DIGEST.md](04_RESULTS_DIGEST.md) | The load-bearing numbers with exact citations — including §4.7, the new gate/probe numbers. |
| [05_THE_TEAMS_CONCLUSIONS.md](05_THE_TEAMS_CONCLUSIONS.md) | The team's current beliefs, labeled as interpretation, with confidence levels. |
| [06_ASSUMPTIONS_TO_CHALLENGE.md](06_ASSUMPTIONS_TO_CHALLENGE.md) | **★ The heart of the packet.** A scoreboard of the previous review's challenges (what got tested, what flipped), and the **new** load-bearing assumptions with steelmen against each. |
| [REVIEWER_PROMPT.md](REVIEWER_PROMPT.md) | A standalone brief you can paste into a fresh context (human or model). |
| [sources/](sources/) | Primary evidence: gate/probe results docs, pre-registered specs, the charter with its decision rule, governance CSVs, verdict docs for all earlier pilots, DECISIONS excerpts, a results-table subset. |

## Ground rules (statistical hygiene — the project's own)

- **n=400 paired ≈ ±17.5 elo (1σ)**; a +20 elo effect is not resolvable at n=400. A lone >1σ spike
  vs neighbors is noise. (The Gate-B craters are −160…−246 elo at n=100–172, i.e. ~5–7σ — *not* a
  power issue.)
- Same-band paired comparisons compose; cross-band ones stack noise.
- Keep sharp: **clairvoyant** vs **fair-information**; **in-ecosystem ruler** vs **human-anchored**;
  **strongest known practical agent** vs **optimal/superhuman**; **offline ranking** vs **in-game**.
- **Do not manufacture doubt where the evidence is sound.** Several kills here are heavily nailed.

## Provenance

- Repo branch `rod_v2_flywheel`; packet date **2026-07-01**. Probe §5A was mid-run at packet time
  (its partial results doc is included as-is).
- Every number cites a file under [sources/](sources/) or a named row in
  [sources/results_csv_relevant_rows.csv](sources/results_csv_relevant_rows.csv). No experiments
  were run to build this packet. Nothing has been promoted: the production champion, PRODUCTION.yaml,
  and the v2.7/v2.9 evaluators are unchanged through this entire arc (it was measurement-only).
