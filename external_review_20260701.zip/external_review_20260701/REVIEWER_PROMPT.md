# Reviewer Prompt — External Review of a Superhuman Carcassonne AI Effort (round 2)

> Paste everything below the line into a fresh context (or hand it to a human expert) **together
> with this packet directory**. The reviewer needs only this packet and its [sources/](sources/).

---

You are an **independent external reviewer** of a game-AI project whose goal is a **genuinely
superhuman** 2-player Carcassonne agent (Base + Farmers), preferably via a **self-learning
flywheel**. This is the second external review. The first review's recommendations were integrated
into a pre-registered charter and **actually executed**: its representation hypothesis was
vindicated offline (Gate A: farm/bag inputs turn the "inert" learned value into a real ranker), and
its prescribed weaned flywheel then **failed decisively in games** (Gate B: the sighted value ranks
well at every search depth yet craters play by −160…−246 elo when driving the MCTS leaf; three
pre-registered nails excluded the recoverable readings). Two boxed follow-up probes closed the
team's "AZ-value" route, and the team has decided to ship a fallback deliverable (an analyzer plus
B1, a deployable non-clairvoyant agent), holding that "fresh approaches to superhuman remain open."

Your job is **not** to rubber-stamp that closure. It is to:

1. **Find obvious mistakes** — in the new gate/probe designs, the statistics, and the framing.
2. **Adjudicate the closure.** Was the AZ-value route closed correctly, or one experiment too early?
3. **Chart the path forward toward superhuman play, preferably with a self-learning flywheel** —
   even if that means telling the team the frame itself is the problem.

Read in order: `README.md` → `01_…` → `02_…` → `03_…` (§3.5 is the new arc) → `04_…` (§4.6 the new
numbers) → `05_…` → `06_ASSUMPTIONS_TO_CHALLENGE.md`. Sources include the pre-registered specs, the
charter with its §10 decision rule, results docs for every gate/probe, and DECISIONS excerpts.

## Context you must hold onto

- The production system's MCTS leaf is a **hand-crafted heuristic** (v2.7/v2.9); the net's value is
  a small residual. Gate B tested *changing* that (weaning the heuristic out) and it cratered.
- **The single most important unexplained fact:** the same learned value simultaneously (a) ranks
  sibling moves well at *every* tree depth (interior τ ≈ 0.43, +43% offline vs the leaf) and
  (b) destroys play when it drives the leaf. The team's three nails say what this *isn't*
  (distribution mismatch, heuristic-subtraction, retraining drift) — **nothing yet says what it
  is.** Candidate untested mechanisms are laid out in file 06, N1 (cross-subtree calibration;
  variance/optimism exploitation by search; blend schedule; PUCT re-tuning under the new leaf).
- The "low-dimensional residual signal" claim rests on **two mutually-redundant axes** (farm, bag);
  a third-axis probe (§5A tempo) was mid-run at packet time.
- **No number in the project is human-anchored.** B1 (deployable, non-clairvoyant) now makes an
  external anchor cheap; it remains unfunded.
- The team's "learned components must exceed the heuristic" requirement is a **means-constraint it
  imposed on itself**, tied to the flywheel preference — the goal as stated is a superhuman *agent*.
  The classical route (deeper search + stronger leaf + exact endgame + engine speedups) has never
  been scoped to the superhuman question, and the *policy*-side learned route was closed before the
  new representation existed.

## Statistical ground rules (the project's own — honor them)

- n=400 paired ≈ ±17.5 elo (1σ). The Gate-B craters (−160…−246 at n=100–172, 1σ≈35) are ~5–7σ:
  treat them as real. A lone >1σ spike vs neighbors is noise.
- Same-band paired comparisons compose; cross-band ones stack noise.
- Keep sharp: clairvoyant vs fair-information; in-ecosystem vs human-anchored; offline ranking vs
  in-game strength (they have dissociated 4+ times in this project — in both directions).
- **Do not manufacture doubt where the evidence is sound.** Several kills are heavily nailed.

## Answer these, in order

**A. Obvious mistakes.** Anything plainly wrong or non-standard in the new work (Gate A/B designs,
the probes, the ledger-close, the stats). Rank by expected impact.

**B. The Gate-B verdict audit.** Is "the value can rank but cannot drive search" *earned* as
stated? Specifically: do the three nails license the conclusion, or do the untested mechanisms in
file 06 N1 (cross-subtree calibration, variance/optimism exploitation, blend schedule, PUCT
re-sweep) leave a recoverable reading open? **Name the single cheapest experiment that would
distinguish "the signal isn't there" from "the integration was broken."**

**C. The closure audit.** (i) Is closing the AZ-value route "on the ledger" sound, given the
entries share teachers, root pools, and protocol families — and given the ledger contains two
protocol-sensitive *positives* (Gate A; the CL-034 comparator)? (ii) Is "the residual signal is
low-dimensional" supportable from two redundant axes with §5A still running?

**D. The frame audit.** The goal is a superhuman *agent*, preferably self-learning. Evaluate the
two un-run programs in file 06 N4 against the closed one: (i) **classical-to-superhuman** (deeper
search, tile-counting leaf, exact endgame, engine speedups — measured against a real anchor);
(ii) **sighted-policy / modern-AZ** (policy retrained on the Gate-A representation, Gumbel-style
low-sims improvement, policy scale). Is either more likely to reach the goal than continuing to
attack the value leaf — or than the analyzer pivot?

**E. The path forward.** A concrete, prioritized plan toward superhuman play (with a self-learning
flywheel if you believe one is still live). For each step: hypothesis, cheapest decisive
experiment, success metric, kill criterion. Be explicit about what you would do **differently**
from the team — and from the previous reviewer.

**F. The anchor.** Given B1 exists, specify the cheapest credible external/human anchor (platform,
ported bot, recruited players), what it would cost, and which of the team's decisions you would
condition on its result. Should it precede everything else?

## Output format — keep these sections strictly separate

- **FACTS** — what the packet's evidence establishes (cite `sources/` files / result rows).
- **INTERPRETATIONS** — defensible readings beyond the raw numbers; mark each.
- **SPECULATION** — untested hypotheses; label clearly.
- **RECOMMENDATIONS** — your prioritized path (E), your answer to the single-cheapest-experiment
  question (B), and a decision rule for when the team should (a) declare the flywheel dream dead
  for good, and (b) declare superhuman reached — including what evidence each requires.

Be adversarial where it matters; be equally willing to say the team's closure is correct. If the
honest answer is "the classical route is the road and the flywheel was the rut" — or the reverse —
say it plainly, with the test that proves it.
