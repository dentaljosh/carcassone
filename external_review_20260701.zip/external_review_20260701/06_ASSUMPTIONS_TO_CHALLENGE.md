# 6 — Assumptions to Challenge (the anti-local-minimum file)

> **Why this file exists.** The team has converged on the story in file 05. This file helps you
> break that story if it deserves breaking. It has two parts: **Part 1** is a scoreboard of the
> *previous* review's challenges — most were actually run in the last 72 hours, and you should know
> which survived so you don't re-litigate settled ground. **Part 2** is the **new** set of
> load-bearing assumptions, each with the team's evidence FOR, a deliberate **steelman of the
> opposite**, and what was **never tested**. The steelmen are prompts for you, not the team's view.
> Where the evidence is genuinely solid we say so — do not manufacture doubt.

---

## Part 1 — Scoreboard: what happened to the last review's challenges

| 2026-06-29 assumption | What was run | Outcome |
|---|---|---|
| **A. "The heuristic leaf is a crutch, not a ceiling — wean it and the value will learn to walk."** | Step 2: the weaned-value-leaf flywheel (convex wean, plus additive and frozen control arms), gated on games | **The steelman lost as stated.** Weaning cratered −160…−246 elo with three nails excluding the recoverable readings. *Residue for Part 2: no positive mechanism identified; the wean jumped to blend 0.27; the loop never reached §10's envisioned "~20–30 iters across two bands" because the crater was immediate and huge.* |
| **B. "It's the representation — farms and the bag were never actually tested."** | Step 1: farm planes + bag histogram on the exact prior protocol, with negative control + ablation | **The steelman WON offline.** Gate A PASS; the old "α=0 law" was a representation confound; bag = information the heuristic cannot see. **Then bounded by Gate B** (ranks, can't drive). The previous review's sharpest call. |
| **C. "Offline screens can't kill a flywheel — the loop is the arbiter."** | The charter adopted this verbatim; Step 2 *was* the loop (gen→train→eval iterations, three objectives) | **Adopted, then the loop itself cratered.** Mostly closed — with the same residue as A (short loop, fixed blend rung). |
| **D. "Measurement gates the claim, not the work — and external anchors were never pursued."** | Probe B built **B1**, a deployable fair-information (non-clairvoyant) agent — the first human-anchorable artifact | **Half-done.** The blocking *artifact* now exists; the anchor itself (humans, platforms, external bots) is **still not pursued**. Now the cheapest it has ever been. → Part 2, N5. |
| **E. "The runs are tiny — scale was never tried."** | Not run (no scaled net/loop) | **Still open** — though Probe A's low-dimensionality finding weakens "a bigger value net" specifically. The *policy/search* side of scale remains untested. |
| **F. "Clairvoyance is unsettled for value-learning."** | Probe B §4A: fair vs clairvoyant targets, one-variable-clean, matched depth 800 | **Attempted, came back inconclusive** (depth-saturated: even clairvoyant targets are inert at depth 800). Deliberately left unresolved. A h6400-depth §4A would answer it; unfunded. |
| **G. "You stopped right after the first positive signal."** | The team pushed the prescribed program to completion instead | **Retired.** The push happened; it cratered. The question has changed shape → Part 2, N4/N6. |

**Net:** the previous review moved the project substantially — one confound found and fixed
offline, one hypothesis killed properly in games. The surviving frontier is different now.

---

## Part 2 — The NEW load-bearing assumptions

### N1 — "The value can rank but can't drive search" (Gate B) — *mechanism unknown*

**FOR.** The craters are huge (5–7σ), reproduced across three objectives, and the three nails are
clean: not distribution mismatch (interior τ flat by depth), not heuristic-subtraction (additive
craters too), not retraining drift (frozen craters identically).

**Steelman of the opposite — the nails exclude three mechanisms; they do not license "cannot drive."**
Candidate mechanisms that were **not** measured, each with a different fix:

1. **Within-sibling ranking ≠ cross-subtree calibration.** Every "the value ranks" number (τ 0.43,
   +43%) is *within a sibling set*. An MCTS leaf must produce values comparable **across different
   subtrees, depths, and phases** — backup and selection compare Q's globally. A value with a
   position-dependent bias (e.g. per-phase or per-board-density offset) can have perfect sibling τ
   and still catastrophically misroute search. *Cheap test: measure cross-set calibration (e.g.
   regress value error on phase/depth/board features; or evaluate pairs sampled across sets).* Fixes
   exist (calibration layer, per-phase normalization) and were never tried.
2. **Variance / optimism exploitation ("search delusion").** Search is a max-operator over many
   evaluations: it *seeks out* the evaluator's idiosyncratic optimistic errors and propagates them.
   A deterministic, smooth heuristic is robust to this; a learned value with heavy-tailed errors is
   not — even when its *average* ranking is better. This predicts exactly "ranks fine offline,
   craters as a leaf." *Cheap test: compare the value's error distribution (tails) vs the leaf's on
   the same positions; or run the leaf with ensembled/pessimistic value (lower-confidence-bound) and
   see if the crater shrinks.* Uncertainty-aware backup, ensembling, and pessimism were never tried.
3. **The blend/wean schedule.** Craters were measured at **blend 0.27** (all three arms). The
   offline-optimal α was **0.05**. Was a 0.05-in-games rung run — and is the crater a cliff or a
   slope in blend? (An earlier-era probe saw λ0.25 ≈ fine / λ0.5 = −123 on a different net,
   suggesting a cliff exists somewhere.) If play degrades smoothly with blend, the mechanism differs
   from a cliff at first contact.
4. **Search-dynamics coupling.** c_puct, FPU, and virtual-loss were tuned *for the heuristic's value
   scale and smoothness*. Swapping the leaf changes the Q-landscape those knobs were tuned on
   (project's own lesson: "a bug fix in scored heuristics shifts hyperparameter optima"). Was the
   PUCT re-swept under the new leaf before reading the crater?

**Why this matters:** if the mechanism is (1) or (2), the correct headline is "an *uncalibrated /
unregularized* value can't drive search" — a fixable engineering property, not a dead route. If it
is genuinely "the signal isn't there," the close is right. The packet's most valuable possible
output is a cheap experiment distinguishing these.

### N2 — Closing a route "on the ledger"

**FOR.** Six-plus independent nulls spanning scalar/structured objects and (weakly) fair targets;
no single-screen overreach; the team explicitly labels the one inconclusive screen inconclusive.

**Steelman of the opposite — the ledger's entries are correlated, not independent.** Most share the
same 10,067-root pool, the same h6400_v2.9 teacher, the same protocol family, the same sims regimes,
and the same underlying architecture lineage. Correlated nulls accumulate less evidence than they
appear to. And the ledger conspicuously contains **one genuine positive under a protocol change**
(Gate A — when the *representation* changed) and **one genuine offline positive** (CL-034 — when the
*object* changed). A ledger with two protocol-sensitive positives in it supports "we haven't found
the right formulation" nearly as well as "the route is exhausted." Decide which reading the evidence
actually prefers.

### N3 — "The residual value signal is low-dimensional"

**FOR.** Farm/bag redundancy (Gate A ablation); the structured head's Δ_indep ≈ 0 (Probe A, ~8σ
below the bar).

**Steelman of the opposite — two redundant axes are effectively ONE axis.** The claim generalizes
from farm+bag to "low-dimensional." §5A (tempo/timing) is the first test of a third axis and was
**still running at packet time** — the claim is provisional by the team's own admission. Other axes
never emitted: threat/safety structure, endgame parity/zugzwang-like timing, opponent-modeling. Also
note the direction of the redundancy finding: farm and bag *substitute* for each other, which is
consistent with both encoding the same underlying "completability" latent — i.e., the *one* thing
the leaf's closure-probability step function gets wrong. If so, the cheapest fix may be to put
completability **into the classical leaf** (tile-counting closure probabilities), not into a net.

### N4 — The value monoculture (the biggest frame-level challenge)

**FOR (the team's frame).** "Superhuman requires the learned components to exceed the heuristic;
the value is the binding learned component; therefore attack value."

**Steelman of the opposite — the goal is a superhuman AGENT, not a superhuman VALUE HEAD.** Since
RoD, essentially every experiment has attacked the value side. But the only *in-game* positives the
project has ever produced are **policy/search-side** (the +67 champion = policy distillation; RoD's
+53 parent-beat = policy on a better leaf) and **classical** (v2.8 +179, v2.9 +55, exact endgame
margin gains, a still-unsaturated depth ladder). Two un-run programs follow:

- **The classical route to superhuman.** Nothing in this packet shows the heuristic ladder
  saturates *below expert human level*. h6400 beats everything learned; h12800 beats h6400 on
  margin; the engine has known 3–5× speedups un-banked (make/unmake, Rust port); the leaf has known
  precision upgrades un-built (tile-counting closure P — the very "completability" latent Gate A
  says carries the value signal); exact endgame play scales with K. A "superhuman = deep-searched
  v2.9+ + exact endgame + opening preparation" program was never scoped, because the team's frame
  scores it as failure ("not learned"). **The user's goal statement does not require the learned
  components to win — that constraint is self-imposed** (it matters only for the *flywheel
  preference*). At minimum, the classical ceiling should be *measured* (vs a human anchor) before
  being dismissed as "not the goal."
- **The policy/search-side learned route.** Never tried: Gumbel-AlphaZero-style root selection
  (designed for exactly this low-sims regime), policy-net scale, learned time/compute allocation at
  the *root* (distinct from the killed leaf-scheduler), self-play tuned for the *policy* to exceed
  h6400's move choice at matched compute (it already nearly matches it), search-parameter learning.
  The policy line was closed on distillation experiments *within the old representation era* —
  before Gate A's planes existed. A sighted *policy* (farm/bag inputs) has never been trained.

### N5 — The human anchor is now cheap and still unfunded

B1 (deployable, non-clairvoyant) exists. An online-platform account, a ported public Carcassonne
bot, or a handful of recruited strong players would produce the project's first absolute strength
datum. Every strategic decision above — including "is classical already near-superhuman?" and
"how far is parity-with-h6400 from expert humans?" — is currently made **blind on the only axis the
goal is defined on.** The previous review flagged this; it is *more* true now. Challenge the team:
what decision would you make differently once anchored, and why hasn't this been step 1?

### N6 — The analyzer pivot

**FOR.** It is the pre-registered §10 fallback, it is the *original* prompt's win condition, and it
ships value from the sighted evaluator.

**Steelman of the opposite.** The §10 rule was written (by the previous review + team) *inside* the
AZ-value frame; "(a) passes, (b) fails → analyzer" hard-codes the assumption that no third option
exists between "learned value drives search" and "give up on strength." N1's untested mechanisms,
N4's two un-run programs, and N5's missing anchor are all third options. Shipping the analyzer is
not wrong — but treating it as the *terminal* strength decision would be premature if any of
N1/N4/N5 is live. Also flag the sunk-cost inversion: the analyzer was demoted for six weeks of
strength work; re-promoting it *now* is only correct if the strength routes really are exhausted.

---

## Directions NOT yet committed to (a menu, not recommendations)

1. **Anchor first (N5):** put B1 (and h6400) against an external reference — online platform, ported
   bot, or recruited experts. Cheapest decision-changing datum in the program.
2. **Mechanism autopsy for Gate B (N1):** cross-subtree calibration measurement; error-tail
   comparison vs the leaf; pessimistic/ensembled value leaf; blend-curve (incl. α=0.05 in games);
   PUCT re-sweep under the learned leaf.
3. **Classical-to-superhuman scoping (N4a):** tile-counting closure P in the leaf; make/unmake →
   deeper search per second; exact-endgame K extension; measure the ladder against the anchor.
4. **Sighted policy / Gumbel line (N4b):** retrain the *policy* on Gate-A's representation; Gumbel
   root selection at low sims; policy-scale test.
5. **§5A completion (N3):** the tempo axis verdict, plus any further orthogonal axes if it cracks.
6. **Fair-info flywheel at depth (F):** the h6400-depth §4A that would actually resolve
   clairvoyance-vs-depth (currently unfunded).

## Levers the team believes are genuinely dead (challenge only if you think the kill was premature)

- **Learned value driving the MCTS leaf** — weaned/convex/additive/frozen, scalar+structured,
  MSE+ranking objectives, at blend 0.27, sims=100 games: *heavily nailed* (see N1 for the one
  gap — mechanism, and with it the possibility of a calibrated/pessimistic variant).
- **Policy distillation from deeper teachers** (deepteacher, high-gap) — learnable, doesn't convert. *Solid within the old representation era; see N4b.*
- **ML compute scheduler / adaptive escalation** — one-line heuristic captures it. *Solid.*
- **Relational/GNN heads on post-search residual** — ablation-proven inert. *Solid.*
- **Symmetry augmentation; c_puct/cap re-tuning; deeper exact endgame as a winrate lever.** *Solid.*

---

## The one-paragraph challenge we most want answered

Gate B is the best-vetted negative result this project has produced, and we are *still* not sure it
means what we've concluded it means. If "ranks at every depth but craters as a leaf" is really
**miscalibration-across-subtrees or variance-exploitation-by-search** (N1) — both standard, fixable
failure modes that our nails did not test — then the AZ-value route was closed one experiment too
early. And if the goal is a superhuman *agent* rather than a superhuman *value head* (N4), then two
whole programs — classical-deep and sighted-policy — plus the now-cheap human anchor (N5) are
sitting untouched while we ship the fallback. Tell us which of these is the rut and which is the
road, and what the cheapest decisive experiment is for each.
