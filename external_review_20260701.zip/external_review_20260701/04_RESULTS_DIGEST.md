# 4 — Results Digest (the load-bearing numbers)

All game results are **deck-paired** (same deck played both colors) head-to-head. `elo` is the
paired elo estimate; `±1σ` from the row. **n=400 paired ≈ ±17.5 elo (1σ); a +20 elo effect is not
resolvable at n=400.** Rows are in [sources/results_csv_relevant_rows.csv](sources/results_csv_relevant_rows.csv).
Offline (non-game) metrics cite the per-pilot verdict doc in [sources/](sources/).

## 4.1 The champion and where deep search catches it

| Comparison | n | elo (±1σ) | record W/L/D | reading | row |
|---|---|---|---|---|---|
| `iter8` vs incumbent (sealed out-of-lineage ruler) | 400 | **+67.4 / z2.73** | — | real, significant gain over the prior champion | (PRODUCTION.yaml) |
| `iter8` vs `heur@800` (v2.7) | 400 | **+58.7** (±17.4) | 232/165/3 | beats shallow heuristic search | `flywheel2_SEALED_champ_iter8_vs_heur800_v27_n400` |
| `iter8` vs `heur@1600` | 400 | **+24.4** | — | edge shrinking | (l22 same-band ladder) |
| `iter8` vs `heur@3200` (v2.7) | 400 | **−28.7** (±17.4) | 180/213/7 | **caught / slight loss** (paired margin −0.85, z−0.70) | `l22_iter8_vs_heur3200_b310_n400` |

> The champion's edge over heuristic search **shrinks monotonically with search depth and is erased
> by `heur@3200`**. (INTERPRETATION: the learned agent is a *search-efficiency / policy* gain
> bounded by the leaf, not a strength gain above deep search.)

## 4.2 The v2.8 leaf and the "RoD" continuation (the most important recent result)

| Comparison | n | elo (±1σ) | paired margin | reading | row |
|---|---|---|---|---|---|
| `iter8+v2.8` vs `iter8+v2.7` | 400 | **+154.5 / z9.8** | — | the meeple leaf helps the **neural** agent a lot | (V28_LEAF_SWAP_REPORT) |
| `iter8+v2.8` vs `heur@3200+v2.8` (**equal leaf**) | 200 | **−38.4** (±24.7) | NA | at equal leaf the neural **still loses** to deep search | `iter8_v28_vs_heur3200_v28_n200` |
| **`RoD_iter_01+v2.8` vs frozen `iter8+v2.8`** | 400 | **+53.4 / z3.51** | +3.68 | **first continuation to ever beat its parent** | `rod_iter01_v28_vs_iter8_v28_n400` |
| `RoD_iter_01+v2.8` vs `heur@3200+v2.8` | 800 | **+16.5** (±12.3) | **−0.36 (z−0.47)** | **parity** — closed the gap but does not exceed deep search | `rod_iter01_v28_vs_heur3200_v28_n800` |

> The winrate-elo (+16.5) and the score-margin (−0.36) disagree → the team reads this as **parity,
> not a win**: the learned agent reached deep-search strength at equal leaf but did **not** surpass
> it. (This is the closest the project has come to "learned ≈ heuristic"; it never got to
> "learned > heuristic.")

## 4.3 The overnight v2.8 flywheel (does +53 compound?)

| Comparison | n | elo (±1σ) | paired margin | reading | row |
|---|---|---|---|---|---|
| `iter08` vs `RoD_iter_01` (internal) | 400 | **+33.1 / z2.0** | +2.23 | modest internal compounding | `rod_ov_iter08_vs_rod1_v28_n400` |
| `iter08` vs `heur@3200+v2.8` (the ruler) | 800 | **+6.5 / z0.53** | −0.38 | **TIE — washed out non-transitively** | `rod_ov_iter08_vs_heur3200_v28_n800` |

## 4.4 Solver-grounded endgame & deeper-ruler probes

| Comparison | n | elo (±1σ) | paired margin | reading | row |
|---|---|---|---|---|---|
| exact-solver tail (K=2) vs `heur@3200+v2.8` | 400 | +18.3 | +1.09 | exact endgame beats deep heuristic on **margin**… | `exact2_vs_heur3200_v28_n400` |
| exact-solver tail (K=4) vs `heur@3200+v2.8` | 94 | +52.1 | +3.54 | …and more so deeper, **but winrate is NS** (outcome-neutral) | `exact4_vs_heur3200_v28_n94` |
| `RoD_iter_01` vs **`h6400`** (v2.8) | 200 | **−45.4** (±24) | −4.41 (z−3.24) | the deeper ruler **erodes** the learned agent → `h6400` adopted as the non-saturated reference | `deepsearch_rod1_vs_h6400_v28_n200` |
| classical `h200` vs neural `iter04` (matched compute, v2.9) | 96 | −44 (for classical) | −2.6 (z−1.19) | NS; **slight lean to the neural agent** → net is game-*neutral* vs classical at matched compute | `valsearch_m1_classical_h200_vs_neural_iter04_n96` |

## 4.5 Offline (non-game) metrics that matter most

These are *offline ranking* numbers (how well a scorer orders sibling moves vs a deep-search
teacher), not game results. They are the crux of the "value head is inert" conclusion — and its one
counterexample.

| Metric (vs h6400 teacher) | Value | Source |
|---|---|---|
| v2.9 **leaf** sibling-ranking τ (Kendall) | **0.895**, top1 0.455 | `…VALUE_RESURRECTION_DECISION.md` |
| Learned **value head** τ (best variant, any α) | **≤0.105**; optimal blend **α = 0** | `…VALUE_RESURRECTION_DECISION.md` |
| **Feature-graph comparator** (explicit features) — offline decisive regret vs leaf | **−41%** (linear) / **−52%** (listwise); top1 0.464→0.535 | `…FEATURE_GRAPH_DECISION.md` |
| …same comparator, **under MCTS@200** | **no integration beats `search_leaf`**; search alone already cuts leaf decisive regret ~6× and explores every sibling | `…FEATURE_GRAPH_DECISION.md` (Stage 5) |
| GNN on post-search residual — graph-embedding ablation | zeroing the graph **lowers** tail regret (structure **inert**) | `…FGSR_DECISION.md` |

> **The single most interesting number in this packet:** the comparator's **−41% offline decisive
> regret** is the *only* time a learned object beat the heuristic leaf at its own job. It reversed a
> prior "α=0, value is hopeless" result. It then "washed out under search." Whether that washout is
> a true ceiling or a testing artifact is the question in file 06, Assumption C.

## 4.6 NEW since 2026-06-29 — the charter gates and probes (the numbers this review turns on)

### Gate A — representation gate (offline sibling ranking vs the h6400 teacher; n_test=1544 groups)
Source: [sources/measurement_feature_planes_gate_STEP1_GATE_RESULTS.md](sources/measurement_feature_planes_gate_STEP1_GATE_RESULTS.md)

| mode | net-alone τ | best α | regret reduction | beats leaf |
|---|---|---|---|---|
| `none` (blind 78-ch baseline) | 0.140 | 0.05 | +1.9% | (noise) |
| **`both`** (+3 farm planes, +32 bag scalars) | **0.207** | **0.05** | **+20.5%** | **yes** |
| `both_shuffled` (**negative control**) | 0.139 | **0.0** | **+0.0%** | no |
| farm-only | 0.180 | 0.05 | +17.1% | yes |
| bag-only | 0.180 | 0.05 | +19.7% | yes |

Pre-registered PASS criterion (α>0 with ≥15% reduction) met; control clean; farm/bag **largely
redundant**; the leaf's own τ is 0.895 — the sighted net is a *weak residual ranker*, not a rival.

### Gate B — the weaned-value-leaf craters (games, deck-paired, sims=100, vs parent `RoD2 iter02`)
Rows: `step2_nail2_*`, `step2_frozen_*` in [sources/results_csv_relevant_rows.csv](sources/results_csv_relevant_rows.csv);
full entry [sources/DECISIONS_excerpt_CL037_038_039.md](sources/DECISIONS_excerpt_CL037_038_039.md).

| arm (all blend 0.27) | n | win-rate | elo (±1σ≈35) | reading |
|---|---|---|---|---|
| pure-heuristic anchor (blend 0) | 100 | **0.500** | 0.0 | the harness is exact — anchor sanity |
| **convex** (h·(1−b) + b·v), MSE value | 100 | 0.19 | **−246.3** | craters |
| **additive** (h at full weight + b·v) | 100 | 0.28 | **−159.8** | **still craters → it's the value's addition** (nail 2) |
| **frozen** offline-winner value (never retrained) | 172 | 0.21 | **−224.9** (z−7.47) | **not retraining drift** (nail 3) |
| (ranking-objective arm, in-loop) | — | 0.453→0.287 | — | craters too → not objective mismatch |

Meanwhile the same value **ranks well at every tree depth** (interior τ d1 0.42 / d2-3 0.45 /
d4-7 0.43; n=4156/9126/1327 — nail 1: not a distribution-mismatch). **The tension between this row
and the table above is the single most important unexplained fact in the project.**

### Probe A — structured-value independence gate (§3A)
Δ_indep = both − max(farm-only, bag-only) = **+0.05pp**, paired σ 0.36, 95% CI [−0.61, +0.78],
pre-registered bar **≥ +3pp** → ~8σ below → killed. (Feasibility itself PASSED: 24-dim per-component
Cython emit at 2.24–2.71× leaf cost, aggregate R² 0.99 — the *capability* exists, the *signal* doesn't.)

### Probe B — fair vs clairvoyant targets at matched depth 800 (full-n, n_test=1544)
All six arms (fair|clair × full/farm-only/bag-only): **best α = 0.0, regret reduction +0.0%**,
net-alone τ ≈ 0.00–0.04. The clairvoyant arms are inert too → the screen is **depth-saturated**
(CL-037's α>0 required h6400-deep targets) and cannot isolate clairvoyance. Included because the
*close* was made on the accumulated ledger with this screen only "consistent."
Source: [sources/measurement_probe_b_4a_PROBE_B_4A_RESULTS.md](sources/measurement_probe_b_4a_PROBE_B_4A_RESULTS.md).

## 4.7 Known measurement caveats attached to every number above

- **Clairvoyant.** All search descends the true deck. Strength inflation measured small (~+27 elo,
  CL-022); value-target inflation never fully closed.
- **In-ecosystem.** Every ruler is built on the v2.7/v2.8/v2.9 heuristic family. **No number here is
  human-anchored.** "Strongest known *practical* agent" (deep heuristic search) is **not** optimal.
- **Band-specific.** The champion's +67.4 is on one sealed deck band; iter0's absolute strength
  swings ±30+ elo across bands. The honest cumulative range is ~+40–67, not +67 alone.
