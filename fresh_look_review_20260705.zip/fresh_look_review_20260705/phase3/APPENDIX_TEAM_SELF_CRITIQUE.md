# Appendix — The Team's Own Conclusions and Self-Critique (2026-07-05)

> **Phase-3 material. Do not read until your Phase-1 (blind diagnosis) and Phase-2 (collision with
> the record) outputs are written.** This exists so you can (a) audit our reasoning and (b) find
> what appears on **neither** your list nor ours.

## The team's current conclusions (all interpretation)

1. **The AZ-value route is closed, and the closure is now "earned," not just accumulated.** The
   one structurally-open cell (sighted representation × pooled value head × de-saturated target ×
   FPU fix × value-driven leaf) was actually run as a real self-play loop and its value head ranks
   endgame siblings at τ≈0.02 against the **exact solver**, where the hand-crafted leaf ranks
   0.615 — flat across iterations, with conversion harm at weight. Scope guard (ours): valid at
   this scale (7M net, ≤5 iters, sims≤200, ~0.4M rankers) — not a claim about 10–100× or
   Gumbel-style search.
2. **The Gate-B mechanism was found, and it partially rehabilitates the value head:** the game
   crater was a **fixable search artifact** — MCTS's max-operator hunts the learned value's
   optimistic tail on unvisited children; FPU=0.6 recovers the crater to exact parity (0.496).
   "A learned value can't drive search" is refuted **as a law**; what remains true is that the
   *current* values give search nothing beyond the leaf (parity, never exceed).
3. **The residual value signal beyond the leaf is genuinely small and low-dimensional:** farm/bag
   redundant; structured heads extract nothing more; tempo is real (solver-τ 0.145) but
   leaf-dominated 4×.
4. **Classical is the champion** — deep search + the v2.9 leaf + exact endgame handoff, now in fair
   (PIMC pooled-Q) mode at no measured decision cost. The v2.10 attempt to improve the leaf via
   solver-endgame screens failed its game gates → even *classical* offline screens don't predict
   game strength here.
5. **No usable external bot anchor exists** (both public Carcassonne AIs are sub-greedy). The only
   remaining external references are the exact solver and **humans** — and the champion is now
   deployable against humans.
6. **Ship decision:** the analyzer (the original win condition) + the deployable fair agent, while
   the capacity probe (pre-registered) finishes.

## The team's own doubts (written before your review)

- **The scope guard is the elephant.** Every kill is at 7M/≤5-iters/sims≤200/386K-rankers on three
  consumer boxes. We pre-registered a capacity probe (running) to test the cheapest slice of this,
  but 10–100× scale, Gumbel/modern-AZ search, and long (100+ iter) loops remain unfunded
  hypotheticals. If the honest summary is "AlphaZero doesn't work *at hobby scale* on this game,"
  the route-closure language overstates what we know.
- **Offline↔online dissociation is now ~6-for-6, including classical leaf changes.** No offline
  metric we have constructed — h6400-teacher ranking (circular), exact-solver endgame ranking
  (non-circular!), root agreement, interior τ — has predicted game strength in either direction.
  Doubt: our *game gates* are all sims=100–800 deck-paired internal matches; if those have their
  own blind spot, every conclusion in this project inherits it. What's the right external check?
- **FPU parity is suggestive, not terminal.** We recovered a *weak* value to parity with one knob
  found by a mechanism probe. Never tried: re-tuning the whole search-knob stack (c_puct, FPU,
  virtual loss) *jointly* for a value-driven leaf; LCB/pessimistic backup; ensembles; parity-plus
  configurations (value for exploration ordering, leaf for evaluation, etc.). We closed the FPU
  *axis* after one curve.
- **The leaf itself ranks 0.615 vs the exact solver** — it mis-orders a large fraction of endgame
  sibling pairs, yet fixing screen-visible endgame regret (v2.10 cap6) didn't convert to games.
  Either endgame precision is strategically cheap in this game (exact-endgame hybrids were also
  outcome-neutral — consistent), or our game gate can't see what it buys. We don't know which.
- **The human anchor is still missing, and it's now purely an operational task.** The champion
  plays fair, runs on consumer hardware (phone-budget benched), and no code blocks a
  humans-vs-agent pilot. Every "superhuman?" judgment remains unmeasured while we spend on
  internal probes. If h6400+solver is *already* superhuman, the whole "dead end" framing inverts —
  the strength goal might be achieved and unproven; if it's far below expert humans, the internal
  elo ladder has been lying to us about scale. **Nothing in the project can currently distinguish
  these two worlds.**
- **The analyzer fallback** is pre-registered and ships value, but it was chosen inside the same
  frame that produced every other decision. Whether to fund one more strength push (scale/Gumbel,
  or something neither we nor two reviews have thought of) versus shipping is exactly the judgment
  we want challenged.

## Levers the team believes are genuinely dead (challenge only if a kill looks premature)

Learned value driving the MCTS leaf *at this scale* (weaned/convex/additive/frozen ×
scalar/structured × clairvoyant/fair × MSE/ranking objectives; now including the canonical sighted
cell with FPU fix, killed on the exact solver) · policy distillation from deeper teachers (killed
twice, powered) · ML compute schedulers · relational/GNN heads · symmetry augmentation ·
solver-screen-driven leaf tuning (v2.10) · deeper exact endgame as a *winrate* lever · external
bot anchors (none exist at usable strength).
