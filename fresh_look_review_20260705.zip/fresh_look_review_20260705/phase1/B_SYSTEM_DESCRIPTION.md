# B — The System As Built

*(Phase-1 material. A neutral description of the mechanism. The 12 load-bearing source files are
in [code/](code/) — **where this prose and the code disagree, the code is the truth.** Line-level
reading is encouraged; foundational mistakes hide in details.)*

## B.0 Code index

| file | what it is |
|---|---|
| `code/mcts.py` | all search: base `MCTS` (heuristic), `NeuralMCTS` (net priors), selection/backup/transposition table, Dirichlet noise, virtual loss, FPU knob, visit-distribution extraction |
| `code/network.py` | the ResNet (policy + value + auxiliary ownership heads; optional global-pool value head) |
| `code/board_repr.py` | board → tensor encoding (spatial input planes; opt-in farm-connectivity planes) |
| `code/features.py` | the scalar input features (opt-in bag histogram) |
| `code/action_space.py` | the 2511-action encoding |
| `code/game_wrapper.py` | AlphaZero-style Game facade: state transitions, terminal reward, value normalization constants |
| `code/virtual_score_v2.py` | the hand-crafted leaf evaluator ("v2.7" family), object implementation |
| `code/flat_leaf.py` | the production de-objectified (union-find) implementation of the same leaf |
| `code/leaf_v29.py` | opt-in v2.8/v2.9/v2.10 leaf variants (meeple-economy term / liquidity curve / caps / bag-close) |
| `code/fair_agent.py` | the fair-information (non-clairvoyant) production agent: PIMC determinizations, pooled-Q aggregation, marginalized endgame handoff |
| `code/selfplay.py` | self-play game generation: policy/value target construction, temperature, resign/overflow handling |
| `code/train_iter.py` | the training loop: losses, batching, checkpointing |

## B.1 Engine

A vendored, patched fork of the open-source `wingedsheep` Carcassonne engine provides rules, legal
moves, and scoring. The team fixed several real engine bugs over the project's life (tied-feature
scoring; a farmer-adjacency connectivity bug; a farm-scoring double-count; a tile-dictionary
duplicate). Board is a 35×35 grid; the network sees a centered **25×25 window**.

## B.2 The current production agent (as of 2026-07-02)

**Deep-classical, no neural net.** `HeuristicMCTS` — PUCT-family search with a **hand-crafted leaf
evaluator** (`v2.9.1 Bmild_cap8`: the v2.7 `virtual_score` base + a nonlinear meeple-liquidity
curve + closure cap 8) at **sims=6400, c_puct=3.0**, with an **exact alpha-beta solver handoff for
the last K≤4 tiles**, run in **fair-information mode** (`fair_agent.py`: PIMC — K determinizations
of the unseen deck order, **pooled-Q** aggregation across them, marginalized K≤2 endgame). Config:
[../phase2/sources/PRODUCTION.yaml](../phase2/sources/PRODUCTION.yaml) (config only — safe to
consult; everything else in phase2/ stays closed during Phase 1).

**A neural stack also exists and predated this champion** (it held the production title until
2026-07-02; how that changed hands is Phase-2 material). It is fully described below because most
of the project's work — and most of what you are reviewing — concerns it.

## B.3 The neural stack

**Network:** 96-channel × 6-block ResNet, ~7M parameters (`network.py`).
- **Input:** ~78 spatial channels over 25×25 — per-cell tile-edge terrains, placed meeples by
  player/type, occupancy — plus 12 scalars (free-meeple counts, scores, diffs, deck size, player
  index). **Opt-in extensions exist** (read the flags in `board_repr.py`/`features.py`): +3 live
  farm-connectivity planes (from the leaf's own union-find decomposition) and +32 per-tile-type
  bag-histogram scalars ("sighted" 81ch/44sc mode), and a global-pool value-head variant.
- **Action space: 2511** (`action_space.py`): 625 positions × 4 rotations, tile-pass, 5 regular
  meeple slots, 4 farmer slots, meeple-pass.
- **Heads:** policy → 2511 logits (legality-masked); value → scalar `tanh` ∈ [−1,1]; an auxiliary
  per-cell ownership head used only as a training loss.

**Search** (`mcts.py`): PUCT MCTS. Neural play plane: sims=200, c_puct=3.0; root Dirichlet noise;
temperature τ=1 for the opening plies then greedy; transposition table keyed by board state (with
de-aliasing of rotationally-symmetric actions); optional virtual loss; an **FPU (first-play
urgency) knob** for unvisited children. Read the selection/backup code directly.

**What evaluates a leaf (the signature design choice):** in the neural stack's standard
configuration, the value driving search is the **hand-crafted heuristic**, with the network's value
head added as a small residual:

```
leaf_value = tanh( virtual_score(state, player) / 15 ) + 0.25 · v_net     (clipped)
```

The network's **policy** provides priors; its **value** is a 25%-weight correction. Configurations
where the net's value fully drives the leaf (`--leaf-eval nn`), and weaned/additive blends, exist
as flags. Neural search descends the **true future tile order** (clairvoyant) in its standard
config; the PIMC fair mode above is the deployable alternative.

## B.4 The heuristic leaf (`virtual_score_v2.py` / `flat_leaf.py` / `leaf_v29.py`)

For the player to move: (1) **finish-the-game score diff** — flood-fill/union-find every
city/road/farm component and count final points per placed meeple; (2) a **closure-anticipation
bonus** per meeple on unfinished features, with closure probability a step function of open-edge
count (1 open → P=1.0, 2 → 0.5, 3 → 0.25, ≥4 → 0), farm bonuses per adjacent unfinished city, and
self/opponent caps; (3) a **meeple-economy term** — flat `k·(my_free − opp_free)` (v2.8), replaced
in v2.9 by a nonlinear per-count liquidity curve, with cap 8. Weeks of hand-tuning sit behind the
constants. The leaf reads the **current board only** — it does not read deck composition (what
remains to draw); an opt-in "bag-close" gate exists in `leaf_v29.py` (off in production).

## B.5 The self-play loop

One iteration (`selfplay.py`, `train_iter.py`): generate ~200–1200 games with the search above
(policy target = root visit distribution; value target configurable — game-outcome margin
`tanh(score_diff/15)` default, `score_diff_wide` = `tanh/40`, MCTS root-Q variants, or the residual
target `search_Q − heuristic_leaf`); train on a sliding window (policy CE + value MSE-or-ranking +
ownership auxiliary; batch 256, ~3 epochs, Adam); gate/promote vs the incumbent and/or a fixed
heuristic-search ruler, deck-paired.

## B.6 Evaluation methodology

- Head-to-head, **deck-paired** (same deck both colors). Reference σ: n=400 paired ≈ ±17.5 elo;
  n=100 ≈ ±35.
- The standard rulers are **HeuristicMCTS** agents (the hand-crafted leaf, no net) at various sims
  (`h200 … h6400, h12800`) — i.e., all internal game rulers share the heuristic-leaf ecosystem.
  There is no human/external anchor to date.
- Offline (non-game) evaluation uses **sibling-set ranking**: Kendall-τ / top-1 / held-out regret
  over ~10k position sets with all legal children labeled — either by a deep-search teacher
  (`h6400`; note such a teacher shares the leaf) or by the **exact solver** (below).
- An **exact alpha-beta solver** for the last K≈2–4 tiles provides non-circular ground truth,
  including a **marginalized (fair-information) K≤2 mode** used as a ~1,100-root ranking ruler.

## B.7 Scale, for calibration

By AlphaZero standards everything here is small: 7M params, ≤ ~1.2k games/iter, flywheels of ≤ ~17
iterations, offline rankers ~0.4M params, consumer hardware. Whether conclusions drawn at this
scale generalize is a legitimate review question.
