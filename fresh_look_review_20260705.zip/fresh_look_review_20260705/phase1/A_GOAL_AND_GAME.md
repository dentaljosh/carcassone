# A — Goal, Scope, Resources, and the Game

*(Phase-1 material. Factual; contains no experiment results and no team conclusions.)*

## A.1 The goal

**Build an agent that plays genuinely superhuman 2-player Carcassonne** — beat strong/expert
humans, aspirationally the world champion — **preferably via a self-learning (self-play) flywheel.**

History of the goal, because it shapes what was built: the project's original prompt
([../phase2/sources/ORIGINAL_PROMPT.md](../phase2/sources/ORIGINAL_PROMPT.md) — Phase-2 material,
cited here only for provenance; do not open during Phase 1) explicitly scoped superhuman play *out*
and named a position **analyzer** as the win condition; the strength stack was meant to be merely
good enough to power analysis. On 2026-05-28 the project owner made superhuman strength the primary
goal. So: **the system was designed for a more modest target than the one it is now judged
against.** You may treat any mismatch between the architecture and the goal as fair game.

## A.2 Locked scope

- **2 players.** **Base game + Farmers** only — no River, no expansions, no big meeples.
- 72-tile deck, 7 followers (meeples) per player.
- The rule scope is fixed; the challenge is depth within a small ruleset.

## A.3 Resources (so "what would you build" stays real)

- Hardware: three consumer boxes — a 16C/32T desktop (5900XT) with one consumer GPU, an older Xeon,
  and a laptop (mobile 4070). CPU self-play fan-out ≈ 14–20 workers/box (DRAM-latency-bound); a
  shared-memory GPU inference orchestrator exists and works.
- The neural nets used to date are small (~7M params); training iterations are hundreds-to-~1200
  self-play games. Learned rankers used in offline probes are ~0.4M-param MLPs.
- Metered cloud (vast.ai etc.) is available but cost-sensitive; assume budget discipline, not zero
  budget. Wall-clock so far: ~11 weeks of intensive work.
- One (1) fixed game engine (vendored, patched Python + Cython hot paths) — described in B; the
  AI-side code is in [code/](code/).

## A.4 Carcassonne in one screen

Carcassonne is a tile-laying game with **randomized draw order** (the bag's *composition* is public
and countable; the *order* is hidden) and otherwise fully visible state.

- **Tiles.** Players alternate: draw a random tile, place it edge-matching onto the growing board,
  optionally place a meeple on a feature of the placed tile.
- **Features & scoring.**
  - **Cities**: 2 pts/tile (+2 per pennant) when closed; 1/tile unfinished at game end.
  - **Roads**: 1 pt/tile.
  - **Monasteries**: 9 pts when surrounded by 8 neighbors; partial at end.
  - **Farms/fields**: scored **only at game end** — a farmer scores **3 pts per completed city**
    touching its field. Fields connect across the whole board in non-obvious ways. Farmers never
    return to hand.
- **Meeples.** 7 per player; a placed meeple is unavailable until its feature scores. Meeple
  economy (free-meeple count, return timing) is a core strategic axis.
- **Contesting.** You cannot place onto an occupied feature; fights happen by building separately
  and **merging** (tile-phase decisions), aiming to share or steal majority.
- **Skill profile (uncontroversial Carcassonne theory):** expert play is dominated by farm control,
  meeple economy/tempo, tile-counting (which specific tiles remain → exact completion odds), and
  contested merges; endgames are nearly combinatorial.

## A.5 What counts as success

"Superhuman" = reliably beats expert humans at the locked ruleset. Note two facts you will need
later: (1) the project has **no human-anchored measurement of anything** — all strength numbers
are internal; (2) the current production agent **is deployable against humans** (it plays without
seeing the future deck), so a human anchor is now an operational question, not a technical one.
How you would *establish* superhuman play is in scope for your review, alongside how to *reach* it.
