# Reviewer Prompt — Fresh-Look Review (first principles, round 3)

> Step-0 material: role, deliverables, ground rules. Contains no results. The operational way to
> run this in one shot is [KICKOFF_PROMPT.md](KICKOFF_PROMPT.md) (paste it to an agent with file
> access; the phase directories enforce the blindness). A human reviewer follows the same order.

---

You are an independent expert reviewer — assume deep familiarity with AlphaZero-family methods
(AZ/MuZero/Gumbel/KataGo), classical game AI (search, evaluation, imperfect information), and the
practice of ML experimentation. A small team has spent ~11 weeks trying to build a **genuinely
superhuman 2-player Carcassonne agent, preferably via a self-learning flywheel**, and believes it
has hit a dead end: every attempt to make the *learned* components carry strength past a
hand-crafted baseline has ended in a null, a crater, or a parity, and a fallback deliverable is
about to be adopted.

They are NOT asking you to referee their latest experiment. Prior reviews already engaged with
their framing; the most recent review's plan was executed to completion. They are asking for
something different:

> **Take a fresh look from first principles. Is there something that has been missed the whole
> time — in the game-theoretic setup, the architecture, the training signal, the search, the
> evaluation methodology, the scale, or the framing of the goal itself?**

## The phase protocol (strict)

**Phase 1 — blind diagnosis** (materials: `phase1/` only — goal/game, system description, and the
actual source code; you have NOT yet seen any results or conclusions):
1. List every design decision that strikes you as non-standard, questionable, or wrong **for the
   stated goal** — from game-theoretic structure down to encodings, formulas, targets, and
   constants. Read the code, not just the prose; flag anything the prose undersells.
2. Predict where this system's strength ceiling comes from, and why.
3. Say what you would build (or change first) if this were your project, at their resources.
4. Name the five cheapest measurements you would run first and what each decides.
Commit this list in writing before proceeding.

**Phase 2 — collision with the record, then your COMPLETE report** (materials: `phase2/`):
For each Phase-1 suspect: tested or not? If tested — convincingly? (Check n, pairing, sims regime,
baselines, which *ruler* scored it — the record documents one ruler that turned out to be circular
— and whether the *right variant* of the idea was the one tested.) Produce three lists:
**(i)** suspects fairly killed; **(ii)** suspects tested inadequately (say what a fair test looks
like); **(iii)** suspects never tested at all. Then — still without opening `phase3/` — write your
**complete, final report** (all deliverable sections below). It is final as of the end of this
phase; Phase 3 may only append.

**Phase 3 — cross-check, as a labeled addendum only** (material: `phase3/`):
The team's conclusions and self-critique are sequenced last precisely so they cannot anchor your
report. Append a **PHASE-3 ADDENDUM**: (1) a doubt-by-doubt verdict on the team's own doubts
(endorse / reject / qualify, with reasons); (2) anything on **neither** your list nor theirs — the
most valuable possible output; (3) explicit labeled amendments ("AMENDED: … because …") if the
appendix genuinely changes any of your conclusions — no silent rewrites. Include in the addendum
your audit of the team's live decisions: treating the learned-value route as closed at their
scale, and falling back to the analyzer deliverable while the human-anchor question stays
unmeasured.

## Deliverables (the report is written at the END of Phase 2; Phase 3 appends the addendum)

- **BLIND DIAGNOSIS** — your Phase-1 output, unedited by hindsight.
- **FACTS** — what the record actually establishes (cite `phase2/sources/` files / result rows).
- **THE MISSED THING** — your top 1–3 candidates for what has been missed the whole time. For
  each: the claim, why everything observed to date is consistent with it, and the **cheapest
  decisive experiment** (design, metric, success/kill criterion, rough cost at their resources).
- **VERDICT AUDIT** — which team kills were fair; which were premature and exactly what would
  reopen them.
- **THE PATH** — a prioritized, concrete plan toward superhuman play (with a self-learning
  flywheel if you honestly believe one is available; without, if not — say so plainly). Include
  how superhuman would be *established*, not just reached, given no human-anchored measurement
  exists yet.
- **STOP RULES** — the evidence that should make the team (a) declare the self-learning dream dead
  for good, and (b) declare superhuman reached.

## Ground rules

- Statistical floor: deck-paired head-to-heads; n=400 ≈ ±17.5 elo (1σ), n=100 ≈ ±35; a lone >1σ
  spike vs neighbors is noise. Offline metrics and in-game strength have dissociated repeatedly in
  this project — in both directions, and for both learned and hand-crafted components; treat any
  offline→online inference as suspect.
- Be adversarial about designs and interpretations, but do not manufacture doubt about heavily
  replicated measurements. If the honest answer is "nothing fundamental was missed; the dead end
  is real; here is the best remaining move," give that answer with the same rigor.
- The goal is a superhuman **agent**. Whether any particular component must be learned is a means
  question — treat it as open in both directions.
