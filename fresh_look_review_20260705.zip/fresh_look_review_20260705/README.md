# Fresh-Look Review — Superhuman Carcassonne AI (2026-07-05)

> **What this is.** A self-contained packet for an outside reviewer taking a **first-principles
> fresh look** at a game-AI project that believes it has hit a dead end. It supersedes all prior
> review packets (2026-06-07, 06-21, 06-29, 07-01).
>
> **The situation, in four sentences.** For ~11 weeks we have been building toward genuinely
> superhuman 2-player Carcassonne, ideally via a self-learning flywheel. Three external reviews
> have already happened; the most recent one's plan was executed to completion in the last four
> days — it changed real things (including which agent holds the production title and *why* one
> famous failure happened), but did not change the bottom line: every route we have tried to make
> *learned* components carry strength past our hand-crafted baseline has ended in a null, a
> crater, or a parity. We are about to fall back to a lesser deliverable. Before we do, we want
> one more set of fresh eyes with no inherited narrative: **is there something that has been
> missed the whole time?**
>
> **This packet is deliberately structured to protect your independence.** You are asked NOT to
> start from our framing (nor from the prior reviews' — they are deliberately excluded). Form your
> own diagnosis from the goal, the game, the system description, and the **actual source code**
> (`phase1/`) — *before* you read what we tried (`phase2/`) or what we concluded (`phase3/`).

---

## How to run this review in one shot

**Paste [KICKOFF_PROMPT.md](KICKOFF_PROMPT.md) as the first message to a fresh AI agent that has
file access** (claude.ai with code execution enabled + this zip attached; or Claude Code / any
agent pointed at the unzipped directory). The kickoff prompt drives all phases autonomously; the
directory structure makes the blindness real (an agent cannot see a file it hasn't read, and its
read log is the audit trail). A human reviewer follows the same order manually.

Plain chat without file access cannot run this honestly — the model would see every phase at once.

## The phase protocol

**Phase 1 — blind diagnosis.** Read ONLY [phase1/](phase1/):
[A_GOAL_AND_GAME.md](phase1/A_GOAL_AND_GAME.md) →
[B_SYSTEM_DESCRIPTION.md](phase1/B_SYSTEM_DESCRIPTION.md) → the source code in
[phase1/code/](phase1/code/). Write down, before proceeding: every design decision that strikes
you as non-standard/risky/wrong for the goal; where you predict the strength ceiling comes from;
what you would build instead; the five cheapest decisive measurements.

**Phase 2 — collision with the record.** Now read
[phase2/C_EXPERIMENT_RECORD.md](phase2/C_EXPERIMENT_RECORD.md) (every experiment, its measured
result, the team's call kept separate) and dig into [phase2/sources/](phase2/sources/) as needed.
For each Phase-1 suspect: fairly killed / tested inadequately / never tested.

**Phase 3 — the team's own self-critique, last, as an addendum only.** The reviewer's report is
**finalized at the end of Phase 2, before our conclusions are ever visible** — so our doubts
cannot anchor their recommendations. Only then do they read
[phase3/APPENDIX_TEAM_SELF_CRITIQUE.md](phase3/APPENDIX_TEAM_SELF_CRITIQUE.md) and append a
labeled addendum: verdicts on our doubts, anything on **neither** list, and explicit amendments
(never silent rewrites) if our appendix genuinely changes one of their conclusions.

Deliverables spec: [REVIEWER_PROMPT.md](REVIEWER_PROMPT.md).

## Packet contents

| item | role | phase |
|---|---|---|
| [KICKOFF_PROMPT.md](KICKOFF_PROMPT.md) | the one-shot prompt that runs the whole review | — |
| [REVIEWER_PROMPT.md](REVIEWER_PROMPT.md) | role, deliverables, ground rules (no results inside) | 0 |
| [phase1/A_GOAL_AND_GAME.md](phase1/A_GOAL_AND_GAME.md) | goal, scope, resources, Carcassonne primer | 1 |
| [phase1/B_SYSTEM_DESCRIPTION.md](phase1/B_SYSTEM_DESCRIPTION.md) | neutral description of the system as built (incl. the current production agent) | 1 |
| [phase1/code/](phase1/code/) | the 12 load-bearing source files, verbatim (~310KB) | 1 |
| [phase2/C_EXPERIMENT_RECORD.md](phase2/C_EXPERIMENT_RECORD.md) | complete factual experiment history through 2026-07-05 | 2 |
| [phase2/sources/](phase2/sources/) | primary evidence: verdict docs, pre-registered plans, governance CSVs, results subset | 2 |
| [phase3/APPENDIX_TEAM_SELF_CRITIQUE.md](phase3/APPENDIX_TEAM_SELF_CRITIQUE.md) | the team's conclusions + its own steelmen | 3 |
| [MANIFEST.json](MANIFEST.json) | machine-readable manifest | — |

## Provenance

Repo branch `rod_v2_flywheel`, packet date 2026-07-05. Code files are verbatim copies from the
repo at packet time. Every number in the record cites a file under `phase2/sources/` or a named
row in `phase2/sources/results_csv_relevant_rows.csv`. No experiments were run to build this
packet. One probe (a pre-registered capacity-scaling probe) was mid-run at packet time and is
included as-is.
