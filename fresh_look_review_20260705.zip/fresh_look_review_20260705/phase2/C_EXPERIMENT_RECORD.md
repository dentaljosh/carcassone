# C — The Experiment Record (Phase-2 material)

> **Do not read before completing Phase 1** (your blind diagnosis from A + B + code).
>
> This is the complete factual history. **FACT** columns are measured numbers (each citing a row in
> [sources/results_csv_relevant_rows.csv](sources/results_csv_relevant_rows.csv) or a verdict doc in
> [sources/](sources/)). **"Team's call"** is the team's interpretation — recorded for completeness,
> *not* to be inherited. Stats reminder: deck-paired; n=400 ≈ ±17.5 elo (1σ); n=100 ≈ ±35.

---

## C.1 Corrections & audits that gate everything (trust base)

| date | event | detail |
|---|---|---|
| 2026-05-29 | engine farm-connectivity bug fixed | farmer adjacency was non-bijective → farm regions start-dependent (~2.2% of games nondeterministic) |
| 2026-06-02 | 6-agent foundational audit ([sources/foundational_audit_2026-06-02.md](sources/foundational_audit_2026-06-02.md)) | found 2 live data-corrupting bugs, both fixed same day: **C1** farm scoring double-counted cities (~17% of farms over-scored → corrupted reward + leaf) and **C2** MCTS transposition visit double-count (~20% of decision nodes → corrupted every policy target). Also named architectural caps: value never in the search loop; representation blind to farm connectivity + bag; saturated `tanh(diff/15)` target; no symmetry aug; advisory (non-rejecting) promotion gate |
| 2026-06-02 | River dropped; base-only reframe | all pre-June "River-era" numbers demoted to historical |
| 2026-06-07 | clean-eval audit | runtime evaluator-provenance guards + 11 semantic contracts; several historical claims re-judged/invalidated |
| 2026-07-01 | **oracle-circularity correction (review "F4")** | offline rankers had been scored against an `h6400` teacher whose Q correlates **0.995** with the v2.9 leaf → "beats/approaches the leaf" claims on that ruler are circular. Fixed by re-scoring against the **exact solver** (marginalized K≤2, 1,119 roots) — the non-circular ruler used for everything after 07-01 |
| ongoing | results discipline | every eval writes a manifest; results.csv is the source of truth; deck-pairing standard |

## C.2 The hand-crafted leaf kept improving (classical line)

| date | leaf | change | FACT | team's call |
|---|---|---|---|---|
| 2026-05-14→17 | v2.5 → v2.7 | closure-anticipation + caps + dedup fixes, hand-tuned | became the production leaf & the baseline of everything | "strong-human by construction" |
| 2026-06-22 | **v2.8** | turn ON the flat meeple-economy term (`k=2`) | heur +179.5 elo @200 / +94.9 @800; `v28@200` beats `v27@800` (+202.6); lifts the neural agent too: `iter8+v2.8` vs `iter8+v2.7` **+154.5 (z9.8)** | real, large classical gain that lifts *everyone* — the learned agent still loses to deep search at equal leaf |
| 2026-06-25 | **v2.9** | nonlinear meeple "liquidity curve" (Bmild) + retuned cap 8 | vs real v2.8 production config: **0.579 wr / +55 elo / z+3.94** @s200, depth-robust | another real classical gain |
| 2026-07-02 | v2.9 at depth | the deferred deep arbiter | vs v2.8-prod at **h6400**, fresh band, n=399: **+64.3 elo / z=3.77 / wr 0.591** | promotion evidence (→ C.6, S1) |
| 2026-07-04/05 | **v2.10 arc — CLOSED NULL** | first *solver-screen-first* leaf loop: screen candidate changes on exact-solver endgame τ/regret, then game-gate the winners | Track A screen winner `cap6` (solver-τ 0.615→0.648, monotone in cap, replicated) — **game gate NULL** (+4.3 elo, z0.45, n=800); Track B `bag-close` gate **NULL** (−6.1, z0.40) | **the solver-endgame screen does NOT predict full-game leaf strength** — the offline↔online dissociation now demonstrated on the *classical* side too; v2.9 stays |

Note: the v2.8 term was **bit-identical to a legacy knob that had been OFF since v3** — killed
weeks earlier by an n=20 screen later shown to be noise.

## C.3 Self-play / flywheel attempts (games are the metric)

| date | run | FACT | team's call |
|---|---|---|---|
| 2026-05 | warmstart + recipes v1–v6 | NN-value-as-leaf self-play plateaued; a pure net-value leaf scored ~**−800 elo**; switching the leaf to the v2.7 heuristic was the breakthrough | net value catastrophic as sole leaf |
| 2026-06-07 | residual flywheel #1 (3 iters) | +14.3 elo cumulative (within noise) | no flywheel |
| 2026-06-10 | **residual flywheel #2 → champion `iter8`** | vs incumbent **+67.4 / z2.73** (sealed out-of-lineage ruler, n=400); vs `heur@800` **+58.7**; decomposition: ~95% of the gain is **policy**, residual-value contribution static ~+22, plateau by iter5 | real but bounded; production champion 2026-06-11 → 07-02 |
| 2026-06-17 | deepteacher (sims-800 teacher, 12 iters) | iter12 vs iter8 = **TIE** (+14.6 @s200 / +12.4 @s800, z<1); a later "+53.7/z2.14" for iter2 **refuted on a third fresh band 2026-07-02: +2.0/z0.09** | deeper policy teacher doesn't help (now powered, twice) |
| 2026-06-19 | ladder placement of iter8 | `iter8` vs heur ladder, same band: **+40.1 @800 → +24.4 @1600 → −28.7 @3200** | learned edge erased by deeper heuristic search |
| 2026-06-22 | **RoD** — continuation on the v2.8 leaf | `RoD_iter_01+v2.8` vs frozen parent `iter8+v2.8`: **+53.4 / z3.51** — the first continuation ever to beat its parent; vs `heur@3200+v2.8` (equal leaf, n=800): winrate +16.5 / margin −0.36 = **parity** | a stronger leaf unstuck a real gain, but only *to* parity with deep search |
| 2026-06-23 | v2.8 overnight flywheel (16 iters) | best iter: +33.1/z2.0 internal, but vs `heur@3200+v2.8` (n=800) **+6.5/z0.53 = TIE** | internal gain washed out vs the external ruler |
| 2026-06-24 | deeper-search ruler probe | `h6400` beats h3200 on margin (z+2.61); **RoD_iter_01 LOSES to h6400 (−45.4, margin z−3.24)**; h12800 > h6400 on margin | heuristic depth ladder not saturated; adopt h6400 as reference |
| 2026-06-24 | exact endgame hybrid (solver plays last K tiles) | Δmargin scales with K (+0.65 K2 → +1.94 K4) but **winrate NS at every depth** | margin-sharpening, outcome-neutral |
| 2026-06-27 | **RoD v2** — continuation on the v2.9 leaf (5 iters) | every iter LOSES to `h6400+v2.9` (−22…−32), no climb; root audit: policy prior diffuse, value-head corr flat | "the v2.9 leaf swap changed nothing; stop the blind flywheel" |

## C.4 Learned-component pilots (offline; sibling-ranking — note the C.1 F4 caveat: pre-07-01 rows used the near-circular h6400 ruler)

| date | pilot | FACT | team's call |
|---|---|---|---|
| 2026-06-19 | value-ranking kill-test (CL-021) | learned value/rankers rank siblings at τ≈0.03–0.10 vs the leaf's τ≈0.58–0.895 | value inert |
| 2026-06-27 | value/search autopsy (CL-032) | value residual scale 0/0.25/0.5 indistinguishable at the root; classical h200 agrees with h6400 **0.911** vs production neural 0.799; yet **in games** classical-vs-neural at matched compute = NS (z−1.19, slight lean *neural*) | root metrics don't predict game strength |
| 2026-06-28 | value resurrection (CL-033) | best blend α=**0** for every variant; net-alone τ peaked 0.105 vs leaf 0.895 | value stays inert vs the v2.9 leaf |
| 2026-06-28 | **feature-graph comparator (CL-034)** | 50 explicit structural/action scalars + linear/listwise ranker: **beats the leaf offline** — held-out regret **−41%** — the first learned object to clear the leaf; **but under MCTS@200** no integration beats plain search | offline win, washes out under search |
| 2026-06-28 | post-search residual / adaptive compute (CL-035) | escalation signal predictable (AUROC 0.78) but a one-line heuristic captures it; magnitudes tiny | no ML scheduler |
| 2026-06-29 | typed GNN on post-search residual (CL-036) | GNN generalizes worse than a flat MLP; **ablation: zeroing the graph embedding *improves* it** | relational structure inert |
| 2026-06-2x | policy-repair & distillation pilots (CL-030/031) | "hard-state" policy target signal-free (one-hot: 0.775 train → 0.061 test); high-gap distillation learns offline (top1 0→0.18) but **in games −64 elo** | policy distillation dead as a strength lever |

## C.5 The representation gates and closure probes (2026-06-29 → 07-01)

*(From a pre-registered plan with an explicit decision rule —
[sources/CHARTER_INTEGRATED_REVIEW_PLAN_2026-06.md](sources/CHARTER_INTEGRATED_REVIEW_PLAN_2026-06.md) §10.)*

| step | FACT | team's call |
|---|---|---|
| **Gate A — representation** ([sources/measurement_feature_planes_gate_STEP1_GATE_RESULTS.md](sources/measurement_feature_planes_gate_STEP1_GATE_RESULTS.md)) | Adding **farm-connectivity planes (+3)** and a **bag histogram (+32 scalars)**: held-out regret **−20.5%** vs blind baseline −1.9%, α 0.05>0, τ 0.140→0.207; shuffled-plane negative control collapses to +0.0%/α=0; farm-only −17.1% / bag-only −19.7% (**largely redundant substitutes**) | PASS — the old "α=0" was partly a representation confound; bag = information the heuristic cannot see. (Scored on the h6400 ruler — see C.1 F4) |
| **Gate B — the weaned flywheel** (rows `step2_*`; [sources/DECISIONS_excerpt_CL037_038_039.md](sources/DECISIONS_excerpt_CL037_038_039.md)) | A structure-aware sighted value **ranks well at every tree depth** (interior τ: d1 0.42 / d2-3 0.45 / d4-7 0.43; +43% offline) — yet at blend 0.27 play **craters vs its own parent**: convex/MSE wr **0.19 (−246 elo)**, additive **0.28 (−160)**, ranking 0.287, **frozen never-retrained 0.21 (−225, z−7.5)**; pure-heuristic anchor exactly 0.500 | FAIL — three nails excluded distribution-mismatch (τ flat by depth), heuristic-subtraction (additive craters too), retraining-drift (frozen craters). "Value can RANK but cannot DRIVE search." *(The mechanism was found later — C.6, M3.)* |
| **Probe A — structured value leaf** | 24-dim per-component value emit feasible (2.2–2.7× leaf cost, bit-exact); farm/bag independence on the structured head: Δ_indep **+0.05pp** vs a pre-registered ≥+3pp bar (~8σ below) | killed cheaply; "residual value signal is low-dimensional" |
| **Probe B — fair vs clairvoyant value targets** ([sources/measurement_probe_b_4a_PROBE_B_4A_RESULTS.md](sources/measurement_probe_b_4a_PROBE_B_4A_RESULTS.md)) | One-variable-clean, matched depth 800, full n: **all six arms inert (α=0)** — *including clairvoyant* (Gate A's α>0 had required h6400-deep targets) | depth-saturated → inconclusive alone; route closed "on the accumulated ledger"; deliverable **B1** = deployable fair-info agent |
| **Probe §5A — tempo third axis** ([sources/measurement_probe_5a_PROBE_5A_RESULTS.md](sources/measurement_probe_5a_PROBE_5A_RESULTS.md)) | gate-zero: naive tempo counts ≥0.72 reconstructible (dropped); a 10-feature residualized timing-depth core survives; single-seed `tempo_only` **+44.7%** on the h6400 ruler — but the control arm broke (init fragility) and the ruler is the circular one (F4) | initially "live offline lead"; resolved non-circularly in C.6 |

## C.6 The post-review program (2026-07-01 → 07-04) — a fresh-look review ran; its plan was executed

*(The review's plan: [sources/POST_REVIEW_PLAN.md](sources/POST_REVIEW_PLAN.md); the resulting
autopsy: [sources/AZ_VALUE_ROUTE_AUTOPSY_2026-07-01.md](sources/AZ_VALUE_ROUTE_AUTOPSY_2026-07-01.md).
It ordered five actions: S1/S2 strategic, M1/M2/M3 mechanism reopeners. All five read out.)*

| action | FACT | team's call |
|---|---|---|
| **S1 — promote the classical agent** | v2.9 `Bmild_cap8` vs real v2.8-prod at **h6400** (fresh band, n=399): **+64.3 elo / z=3.77** | **PRODUCTION FLIPPED (the first champion change of the project):** champion = **deep-classical HeuristicMCTS on the v2.9 leaf @ h6400 + exact K≤4 endgame handoff**; neural `iter8` demoted to lineage ([sources/PRODUCTION.yaml](sources/PRODUCTION.yaml)) |
| **S2 — external bot anchor** ([sources/measurement_bot_anchor_S2_BOT_ANCHOR_SCOPING.md](sources/measurement_bot_anchor_S2_BOT_ANCHOR_SCOPING.md)) | both readily-available open-source Carcassonne AIs are **weaker than a 1-ply greedy**: a MuZero implementation (195k net; also a rotation bug in its API makes it unbridgeable to a rules-correct engine) and an MCTS-RAVE implementation (rules-correct, bridgeable, sub-greedy) | **clean negative — no usable external bot anchor exists.** Remaining non-circular references: the exact solver + (deferred) humans |
| **M1 — deepteacher re-kill** | iter2 vs iter8, third fresh band, fixed-rung paired n=400: **Δ +2.0 elo, z=0.09** | the one surviving "maybe" was band noise; kill stands, powered |
| **M3 — Gate-B mechanism (calibration/tails)** | Full n=400 **FPU curve** on the additive weaned-value crater: fpu None **0.265** → 0.4 **0.391** → 0.6 **0.496 = PARITY** (z−0.15 vs the 0.500 anchor) → 0.8 0.483 → 1.0 0.476. Isotonic calibration recovered **less** than FPU | 🔥 **Gate-B is refuted as a law.** The crater was a **fixable search artifact**: the MCTS max-operator hunts the learned value's optimistic tail on unvisited children; FPU tames it. But recovery is **to parity, not past it** → "FPU removes the weak value's harm but cannot make it exceed the leaf; the exceed-lever is a better value" |
| **M2 — the never-run canonical-AZ cell** ([sources/measurement_canonical_az_M2_PLAN.md](sources/measurement_canonical_az_M2_PLAN.md); pre-registered read-out) | The one cell every prior null left structurally open — **sighted rep (81ch/44sc) × global-pool value head × `score_diff_wide` target × FPU=0.6 × the net's value fully driving the leaf** — ran a real 5-iteration self-play loop (orch-accelerated, gen parity bit-exact). **Primary read (non-circular):** value-head τ vs the **exact K≤2 solver** (1,119 marginalized roots) = **0.018 → 0.023 across iters, FLAT**, vs leaf **0.615** (paired sign-z −17; ~1 pt exact margin lost/root). Heads do track score-diff (corr 0.50→0.65) — the failure is **between-sibling discrimination**. **Conversion read:** rs-sweep 0/6 cells ≥2σ, non-monotone, harm at weight (−22…−68 elo); in-loop policy flat-negative ~−40 | ❌ **KILL on both pre-registered reads → the AZ-value route closure is now "EARNED"** (previously ledger-based, now anchored non-circularly). **Scope guard (the team's own):** valid *at this scale* — 7M params, ≤5 iters, sims≤200 — not at 10–100× or with Gumbel-style search |
| **§5A resolution — tempo re-scored non-circularly** | 12 retrains, solver pass vs the same 1,119-root exact ruler: `tempo_only` solver-τ mean **0.145** — genuine (~7× the M2 value heads' 0.02) but **leaf-dominated 4×** (leaf 0.615; best seed sign-z −9.2). The circular +44.7% was a tail draw; the broken control replicates as init fragility | REAL-BUT-DOMINATED; no route implication |

## C.7 Deployment & classical-side work (2026-07-04 → 07-05)

| item | FACT | team's call |
|---|---|---|
| **Fairness probe → production fair mode** ([sources/measurement_fairness_probe_README.md](sources/measurement_fairness_probe_README.md)) | exact-solver move regret at champion config (n=300, sims=1600, K=8 determinizations): CLAIR 0.447 / FAIR pooled-N 0.393 / **FAIR pooled-Q 0.383** (top1 0.807 ≥ clair 0.793); paired Δ NS; pooled-Q never blunders | **production runs fair (PIMC pooled-Q + marginalized K≤2 handoff)** — the champion is genuinely non-clairvoyant/deployable; the planned fair-vs-clair game-tax measurement was cancelled as decision-irrelevant ("fair is mandatory for deployment") |
| **v2.10 leaf arc** (C.2 last row) | solver-screen winners do **not** convert to game strength (cap6 +4.3/z0.45; bag-close −6.1/z0.40) | leaf-improvement-via-solver-screen closed; v2.9 stays |
| **Capacity probe** ([sources/measurement_capacity_probe_CAPACITY_PROBE.md](sources/measurement_capacity_probe_CAPACITY_PROBE.md)) | **RUNNING at packet time** (launched 07-04, thresholds pre-registered before any result): does ranker capacity (386K → f64b4 → f128b6) move the Q-label sibling-ranking ceiling (~0.13) toward the leaf (0.615) on the same data/labels/representation? | the pre-registered disambiguator for "would 10× scale help" |
| **Phone-budget bench** | single-thread ms/move harness for the v2.9 champion measured on local hardware | deployment sizing (analyzer / playable agent) |

## C.8 Where things stand (2026-07-05)

- **Production champion: deep-classical** — HeuristicMCTS + v2.9 leaf @ h6400 + exact K≤4 endgame
  handoff, in fair (PIMC pooled-Q) mode. The neural line (`iter8`) is lineage.
- **The AZ-value route is closed and the team now calls the closure "earned":** the canonical cell
  (sighted representation + pooled head + de-saturated target + FPU fix + value-driven leaf) was
  actually run and its value head ranks at τ≈0.02 vs the exact solver where the hand leaf ranks
  0.615. The Gate-B crater mechanism was identified (optimism-tail exploitation; FPU=0.6 recovers
  to parity, not beyond).
- **Explicitly open per the team's own scope guards:** the capacity probe (running); 10–100× scale
  and Gumbel-style search (named, unfunded); the **human anchor** (the only remaining external
  reference — no usable bot anchor exists; the champion is now deployable against humans).
- **Ship decision on the table:** the analyzer (the original win condition) + the deployable fair
  agent.
- The owner's request for this review: *"we're at a dead end and I want to see if there's something
  that's been missed the whole time."* This is the third external review; the packet's phase
  structure exists so you don't inherit the first two reviews' frames.
