# B — The System As Built

*(Phase-1 material. A neutral description of the mechanism. The 11 load-bearing source files are
in [code/](code/) — **where this prose and the code disagree, the code is the truth.** Line-level
reading is encouraged; foundational mistakes hide in details.)*

## B.0 Code index

| file | what it is |
|---|---|
| `code/mcts.py` | all search: base `MCTS` (heuristic), `NeuralMCTS` (net priors), selection/backup/transposition table, Dirichlet noise, virtual loss, visit-distribution extraction |
| `code/network.py` | the ResNet (policy + value + auxiliary ownership heads) |
| `code/board_repr.py` | board → tensor encoding (the spatial input planes) |
| `code/features.py` | the scalar input features |
| `code/action_space.py` | the 2511-action encoding |
| `code/game_wrapper.py` | AlphaZero-style Game facade: state transitions, terminal reward, value normalization constants |
| `code/virtual_score_v2.py` | the hand-crafted leaf evaluator ("v2.7"), object implementation |
| `code/flat_leaf.py` | the production de-objectified (union-find) implementation of the same leaf |
| `code/leaf_v29.py` | opt-in v2.8/v2.9 leaf variants (meeple-economy term / curve) |
| `code/selfplay.py` | self-play game generation: policy/value target construction, temperature, resign/overflow handling |
| `code/train_iter.py` | the training loop: losses, batching, checkpointing |

## B.1 Engine

A vendored, patched fork of the open-source `wingedsheep` Carcassonne engine provides rules, legal
moves, and scoring. The team fixed several real engine bugs over the project's life (tied-feature
scoring; a farmer-adjacency connectivity bug; a farm-scoring double-count; a tile-dictionary
duplicate). Board is a 35×35 grid; the network sees a centered **25×25 window**.

## B.2 Network

**96-channel × 6-block ResNet, ~7M parameters** (`network.py`). Production: `n_scalar_features=12`,
`value_global_pool=False`.

- **Input:** ~78 spatial channels over 25×25 — per-cell tile-edge terrains (4 sides × one-hot
  terrain), placed meeples by player/type, occupancy — plus **12 scalars** (free-meeple counts,
  scores, diffs, deck size, player index; normalizations in `features.py`/`game_wrapper.py`).
- **Action space: 2511** (`action_space.py`): 625 positions × 4 rotations, tile-pass, 5 regular
  meeple slots, 4 farmer slots, meeple-pass.
- **Heads:** policy → 2511 logits (legality-masked); value → scalar `tanh` ∈ [−1,1]; an auxiliary
  per-cell ownership head used only as a training loss.

## B.3 Search

PUCT-family MCTS (`mcts.py`). Production play/self-play plane: **sims=200, c_puct=3.0**; root
Dirichlet noise; temperature τ=1 for the opening plies then greedy; a transposition table keyed by
board state (with de-aliasing of rotationally-symmetric actions); optional virtual loss for
batched leaf evaluation. Read the selection/backup code directly rather than trusting summaries.

**What evaluates a leaf (read carefully — this is the system's signature design choice):** the
value driving search is a **hand-crafted heuristic**, `virtual_score` ("v2.7"), with the network's
value head added as a small residual:

```
leaf_value = tanh( virtual_score(state, player) / 15 ) + 0.25 · v_net     (clipped)
```

The network's **policy** provides priors; the network's **value** contributes a 25%-weight
correction on top of the heuristic. Search descends the **true future tile order** (clairvoyant —
there are no chance nodes; a single-determinization "fair" mode exists in the code but is not the
production path). A deployable fair-information variant ("B1") was built in late June 2026.

## B.4 The heuristic leaf (`virtual_score_v2.py` / `flat_leaf.py`)

For the player to move: (1) **finish-the-game score diff** — flood-fill/union-find every
city/road/farm component and count final points per placed meeple; (2) a **closure-anticipation
bonus** per meeple on unfinished features, with closure probability a step function of open-edge
count (1 open → P=1.0, 2 → 0.5, 3 → 0.25, ≥4 → 0), farm bonuses per adjacent unfinished city,
self/opponent caps (`CAP=12` / `OPP_CAP=8`); (3) a **meeple-economy term** — flat
`k·(my_free − opp_free)` in v2.8 (k=2), a nonlinear per-count curve plus retuned cap in v2.9. The
leaf is the product of weeks of hand-tuning; the production config is in
[../phase2/sources/PRODUCTION.yaml](../phase2/sources/PRODUCTION.yaml) (config only — safe to
consult, but everything else in phase2/ stays closed during Phase 1).

## B.5 The self-play loop

One iteration (`selfplay.py`, `train_iter.py`): generate ~200–1200 games with the search above
(policy target = root visit distribution; value target configurable — game-outcome margin
`tanh(score_diff/15)` by default, or MCTS root-Q "search_value" variants, or the residual target
`search_Q − heuristic_leaf`); train on a sliding window (policy CE + value MSE-or-ranking +
ownership auxiliary; batch 256, ~3 epochs, Adam); gate/promote vs the incumbent and/or a fixed
heuristic-search ruler, deck-paired.

## B.6 Evaluation methodology

- Head-to-head, **deck-paired** (same deck both colors). Reference σ: n=400 paired ≈ ±17.5 elo;
  n=100 ≈ ±35.
- The standard rulers are **HeuristicMCTS** agents (the same hand-crafted leaf, no net) at various
  sims — `h200 … h3200, h6400, h12800` — i.e., **all internal rulers share the heuristic-leaf
  ecosystem**, and standard evals are clairvoyant. There is no human/external anchor to date.
- Offline (non-game) evaluation uses **sibling-set ranking** vs a deep-search teacher (typically
  `h6400`): Kendall-τ / top-1 / held-out "regret" over ~10k position sets with all legal children
  labeled.
- An exact alpha-beta solver exists for the last K≈2–4 tiles (clairvoyant labels) and is used as
  non-circular ground truth for endgame probes.

## B.7 Scale, for calibration

By AlphaZero standards everything here is small: 7M params, ≤ ~1.2k games/iter, flywheels of ≤ ~17
iterations, consumer hardware. Whether conclusions drawn at this scale generalize is a legitimate
review question.
