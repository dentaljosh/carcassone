# Appendix — The Team's Own Conclusions and Self-Critique

> **Phase-3 material. Do not read until your Phase-1 (blind diagnosis) and Phase-2 (collision with
> the record) outputs are written.** This exists so you can (a) audit our reasoning and (b) find
> what appears on **neither** your list nor ours.

## The team's current conclusions (all interpretation)

1. **The value head's historical inertness was partly a representation confound** (Gate A: farm/bag
   inputs make it a real, weak ranker; the bag is information the heuristic structurally cannot see).
2. **But the sighted value cannot drive the MCTS leaf** (Gate B: −160…−246 elo craters across
   MSE/ranking/frozen arms; nails exclude distribution-mismatch, heuristic-subtraction,
   retraining-drift). Phrase: "can rank, can't drive." **No positive mechanism identified** — the
   nails only say what it isn't.
3. **The residual value signal beyond the leaf is low-dimensional** (farm/bag redundant; a
   structured per-component head extracts nothing more). Provisional: the third-axis probe (§5A,
   tempo) was still running at packet time.
4. **The AZ-value route is exhausted (scalar/structured/clairvoyant/fair), closed "on the ledger"**
   — no single screen carries it; the accumulated nulls do.
5. **Decision on the table:** ship the analyzer (the original win condition) + B1, per the
   pre-registered fallback; "fresh approaches to superhuman remain open."
6. Standing beliefs: offline/root metrics don't predict game strength (4+ dissociations, both
   directions); everything is in-ecosystem and unanchored; the heuristic depth ladder is not
   saturated.

## The team's own doubts (its steelmen against itself, written before your review)

- **Mechanism gap in Gate B.** Untested candidate mechanisms, each with a different remedy:
  (a) **within-sibling ranking ≠ cross-subtree calibration** — every "ranks well" number is
  within-sibling-set; an MCTS leaf must be comparable across subtrees/depths/phases; a
  position-dependent bias craters search with perfect sibling τ; (b) **variance/optimism
  exploitation** — search is a max-operator that hunts the evaluator's idiosyncratic optimistic
  errors ("delusion"); a smooth deterministic heuristic resists this, a learned value with heavy
  error tails doesn't — predicts exactly "ranks fine, craters as leaf"; never tested: error-tail
  comparison, ensembles, pessimistic (LCB) leaves, calibration layers; (c) **blend schedule** —
  craters measured at blend 0.27; the offline-optimal α was 0.05; blend-response curve in games
  unmeasured; (d) **search knobs** (c_puct/FPU/virtual-loss) tuned for the heuristic's value scale,
  never re-swept under the learned leaf — the project's own lesson says optima shift.
- **Ledger epistemics.** The closure's entries share teachers, root pools, protocol families, and
  architecture lineage — correlated nulls, counted as independent. And the ledger contains two
  protocol-sensitive *positives* (Gate A when the representation changed; the CL-034 comparator
  when the object changed), which fits "haven't found the right formulation" nearly as well as
  "route exhausted."
- **"Low-dimensional" from two redundant axes** is really *one* axis (both plausibly encode
  completability). If completability is the whole residual, the cheapest fix may be **classical**:
  tile-counting closure probabilities in the leaf, not a net.
- **The value monoculture.** Every recent experiment attacks the value side; the only in-game
  positives ever were **policy/search-side** (the +67 champion; RoD's +53) and **classical** (v2.8
  +179; v2.9 +55; the unsaturated depth ladder). Never scoped: (a) a **classical route to
  superhuman** (deeper search via engine speedups, tile-counting leaf, exact endgame, opening prep
  — the "learned must exceed heuristic" requirement is self-imposed, tied to the flywheel
  preference, not to the goal); (b) a **sighted-policy / modern-AZ route** (the policy was closed on
  distillation experiments predating the Gate-A representation; Gumbel-style low-sims improvement
  never tried; policy scale never tried).
- **The anchor.** B1 makes an external/human anchor cheap for the first time; it remains unfunded.
  Every strategic call above is made blind on the only axis the goal defines.
- **The fallback itself.** The pre-registered "(a) passes, (b) fails → analyzer" rule was written
  inside the AZ-value frame; it hard-codes that no third option exists between "learned value
  drives search" and "give up on strength."

## Levers the team believes are genuinely dead (challenge only if you think a kill was premature)

Learned value driving the MCTS leaf (weaned/convex/additive/frozen; scalar+structured;
MSE+ranking; at blend 0.27, sims=100 games) · policy distillation from deeper teachers (in the old
representation era) · ML compute schedulers · relational/GNN heads · symmetry augmentation ·
c_puct/cap re-tuning · deeper exact endgame as a *winrate* lever.
