# Execution Plan — Carcassonne Superhuman Program (Integrated Charter, 2026-06-29)

## Context

The project's central conclusion — *"the learned components are inert, the heuristic is a ceiling, the AlphaZero flywheel is closed"* — is **not yet earned by the evidence**. Two independent external reviews (R1, R2) converged on why: the system was never run as AlphaZero. The MCTS leaf value is the hand-crafted v2.7/v2.9 heuristic; the net value is only a **25% passive residual** (`leaf = clip(tanh(virtual_score/15) + 0.25·v_net, ±1)`), so the net value is **never forced to become the value function**. Five of the six "independent" nulls run on one board representation the 2026-06-02 audit found **blind to farm connectivity and the bag** — and the one pilot that varied representation (CL-034) **beat the v2.9 leaf offline by −41% decisive regret**, reversing the α=0 verdict before washing out under search.

So the charter's claim is: the heuristic leaf is more likely a **crutch** than a ceiling, and the program stopped one experiment short of finding out. This plan executes the charter's path: **fix value-target hygiene (cheap) → fix the representation and re-run the value test (cheap, the decision gate) → only then run a net-value leaf weaned off the heuristic on a sighted representation, gated on games.** Each step carries a pre-registered kill criterion. **Honest endgame either way:** if the value head stays inert *with* farm+bag vision and a weaned loop, accept the classical ceiling and ship the analyzer (the original Phase-5 win condition); if it ignites, the question becomes scale + the human anchor.

**This plan is grounded in a full code map (3 Explore passes, 2026-06-29).** The two big de-riskers: the **de-saturated value target already exists** (`score_diff_wide` = tanh/40 in `selfplay.py`) and the **residual blend is env-var controlled** (`CARCASSONNE_V25_RESIDUAL_SCALE` in `evaluators.py`) — so "anneal heuristic weight high→0" is a launcher-loop change, not new blend math. Only **leaf dropout** and **per-iter annealing/exploration schedules** need new code.

**⚠️ One landmine the new thread MUST clear before Step 1** (§ "Step 1" pre-flight): a version of the representation probe was *already run and killed* on 2026-06-04 — `docs/PHASE1_BUILD_SPEC_2026-06-02.md` is banner-stamped *"Stage C KILLED — the C4a representation-probe refutation removed its premise."* Step 1 is only valid if it is provably the *untested* form (input planes into the net, not CL-034's handcrafted scalars-into-a-linear-model). Reconcile or the step is dead on arrival.

---

## 0. Kickoff (do in order, before any modeling)

1. Repo at branch `rod_v2_flywheel`, commit `6c00fd8`. Confirm champion `flywheel2_champion_iter8` (sha `0d355002…`) and `governance/PRODUCTION.yaml` unchanged (champion: `flywheel_residual_attempt2/ckpt/iter8.pt`, residual_scale `0.25`, leaf `virtual_score_v2`, `USE_FLAT_LEAF=1`).
2. New work registers as **CL-037 onward** (`governance/CLAIM_REGISTRY.csv`; latest is CL-036 / FGSR). Each concluded step runs the **5-touch close-out** (results.csv → DECISIONS index → spec-doc status banner → governance row flip → STATUS top block) then `python3 scripts/doc_lint.py`.
3. **First concrete action: §6.1 sign audit** — the cheapest thing that could invalidate the entire value-head conclusion, upstream of everything.

---

## §6 — Two evidence corrections (cheap, no cluster, FIRST)

### §6.1 — Audit the value-TARGET POV sign convention *(the potential whole-story bug)*

CL-033 found `scripts/rod_v2/value_search/forced_move.py` `_child_root_pov()` (lines ~76–95) is sign-inverted on **same-player TILES roots** (the TILES action does not flip `current_player`). The team treated this as harmless because it made the leaf look *better*. **The unasked question: does the same POV convention touch the value TRAINING target at the TILES→MEEPLE same-player boundary?**

**Trace path** (all read-only audit):
- Value-target builder: `src/carcassonne_ai/selfplay.py`.
  - Outcome targets (`score_diff` / `score_diff_wide` / `wl`): backfilled at lines ~448–467, sign-flipped **per ply** via `z_p0 if players_arr[i]==0 else -z_p0`.
  - Search-value targets (`search_value`, `v2_7`, `residual`): lines ~334–358, recorded already-current-player-POV, **no extra flip**.
- The check: at same-player TILES→MEEPLE transitions, does `players_arr[i]` (the per-ply POV used for the flip) actually equal the player-to-move at that recorded position? If a fraction of nodes are sign-inconsistent, that **alone produces apparent inertness** (the value head learns a target that flips sign on a subset of structurally-similar nodes).
- Cross-check against `forced_move.py` and the residual builder (`mcts.root_value(board) − _v27_leaf_value(...)`).

**Success:** targets are POV-consistent at same-player roots. **Kill/branch:** if wrong, **fix it and re-baseline the value-head claims (CL-021/CL-033) before any further value conclusion stands** — this could be the whole story. Report findings before proceeding to Step 0.

### §6.2 — Restate the "deepteacher washout" correctly (doc hygiene)

The dramatic **+82.8@200 → +8.1@800** washout was measured against the **stale `residual.pt` (iter0) baseline** (the CL-020 provenance defect), not iter8. The clean **iter12-vs-iter8** comparison is **+14.6@200 (z0.65) / +12.4@800 (z0.51) — a tie at both planes** (CL-019). Honest statement: *a deeper teacher does not raise strength over iter8 at either plane.*

**Action (edits, not just prose):** purge the +82.8 framing wherever it is load-bearing — restate as iter12≈iter8. Targets: `STATUS.md`, any `measurement/` doc citing +82.8, and **the auto-memory note `feedback_sims_washout_net_eval`** (currently carries the +82.8/z3.48 framing — correct it to the iter12-vs-iter8 tie, or it will keep re-seeding the wrong story into future threads).

---

## Step 0 — Value-target hygiene *(days; sign part no-cluster, det probe small-GPU)* — gate for everything below

**Hypothesis:** apparent inertness is partly a corrupted value target (§6.1) and/or clairvoyant single-determinization noise the net can't predict (F-B2).

**Experiments:**
- (a) The §6.1 sign audit (above).
- (b) **Determinization-averaged vs single-determinization value targets.** *Note: averaging does NOT exist today* — `selfplay.py` seeds one deck per game (`_random.seed(seed)`) and uses the single realized outcome. Build a small labeling probe: for a sample of roots, draw K determinizations of the unseen deck (reuse `scripts/measurement_infra/root_replay.py` + `snapshot.py`), compute the outcome/oracle value per determinization, average → the "fair" target; compare against the single-realization target. Train a value head on each; compare held-out value loss.

**Success:** targets POV-consistent **and** single-det ≈ averaged (clairvoyant-target contamination ruled out). **Kill/branch:** if both clean → proceed to Step 1 *without* the fair-target fix (confound removed for free, defer it to Step 4). If sign is wrong → fix and re-baseline first.

---

## Step 1 — Fix the representation, re-run the value test *(1–2 weeks, no cluster)* — **THE DECISION GATE**

This is the single highest-information experiment and the gate for whether the expensive Step 2 runs.

**Pre-flight (mandatory — clears the landmine):** read `docs/CEILING_AND_C4C6_2026-06-04.md` and the CL-034 search screen (`measurement/feature_graph_comparator/FEATURE_GRAPH_SEARCH_RESULTS.md` + `FEATURE_GRAPH_DECISION.md`). Establish exactly what the 2026-06-04 C4a probe tested and **prove the proposed experiment is the untested form**: CL-034 used **handcrafted scalars in a linear/listwise model**; Step 1 puts **farm/bag/open-edge INPUT planes into the trained net** and re-runs sibling ranking. If they are not cleanly distinct, the step is dead on arrival — document the distinction or stop.

**Hypothesis:** the value head's optimal blend weight α stops being 0 once it can see farm connectivity and the bag.

**Build the planes** (per `docs/PHASE1_BUILD_SPEC_2026-06-02.md` C4a–d; `encode_board` is `src/carcassonne_ai/board_repr.py:310–415`, currently `N_CHANNELS=78`):
- **C4a — farm-connectivity input planes:** new *live-board* ownership/connectivity (NOT the terminal-only `src/carcassonne_ai/aux_targets.py` recorder). Use `FarmUtil.find_farm` flood-fill + current meeple majority → ~2–3 channels projected onto the window. Bump `N_CHANNELS`.
- **C4b — bag-composition histogram:** per-tile-type remaining counts from `state.deck` (~24 base types) → normalized **scalar** features in `src/carcassonne_ai/features.py` (today there is only the scalar `tiles_remaining/72`).
- **C4c — open-feature completion planes:** per-cell city open-edge count / monastery neighbor count.
- **C4d — turn ON farm scalars** (`include_farm_scalars=True`; currently OFF).
- **Guard:** add a test (mirror `tests/test_v29_variants.py`) asserting the v2.7/v2.9 leaf is **bit-identical** with planes off, and a `board_repr` shape/round-trip test. One-retrain discipline: batch all rep changes into ONE warmstart→train cycle.

**Re-run the test** on the **existing 10,067 h6400_v2.9 sibling sets** (the exact CL-033/CL-034 data: `measurement/high_gap_distillation/scaled/qprobe_A/probe.jsonl ∩ pool_A.jsonl`, joined by `(seed, ply)` via `replay_to()` — **zero cluster, no relabel**). Harness already exists: `scripts/rod_v2/value_resurrection/{dump_dataset,leaf_audit,train_eval}.py`, the CL-033 ranking protocol `scripts/probe_decision_ranking.py` (Kendall-τ / top1 / regret), and `listwise_ranking_loss` in `scripts/train_iter.py`. Train an action-conditioned ranker/value with the new planes against `h6400` / exact / fair labels on held-out roots. *(Requires a from-scratch base-only warmstart at the new channel width — a GPU train, not cluster self-play.)*

**Success — TWO SEPARATE GATES (do not conflate; refined per external review 2026-06-29):**
- **Gate A — the scientific lock (offline ranking):** net-alone τ moves materially toward the leaf's 0.895 (say **>0.4**), **OR** `leaf+α·net` selects **α>0** with a real regret reduction AND the `both_shuffled` negative control collapses to the `none` noise floor (no sub-`none` val-loss leak). This proves the *representation* carries value signal the blind net could not access (refutes CL-033's "inert as an architecture-independent law"). **This is the load-bearing result and the only thing Step 1 locks.** With τ<0.4 the lock rests on the α>0 clause alone → *weak-but-nonzero ranker, NOT rivals-the-leaf.*
- **Gate B — conversion through search (de-risk signal, NOT a Step-1 kill):** a post-search-residual target or search-integrated root screen improves without ordinary-position regression. A **pass** materially de-risks the 2–4 week Step 2; a **fail is allowed and downgrades confidence — it does NOT kill** (CL-034's bigger −41% offline washed out at the sims=200 screen; the **loop**, which reshapes trajectories + evolves policy targets across iters, is the arbiter a fixed-position screen structurally cannot be). Run it only if cheap. *Our −20.5% is on the right object (a leaf-style value head ordering children) whereas CL-034's −41% was a sibling-relative ranker — smaller number, more relevant object. The α>0 flip justifies the Step 2 bet; it does not de-risk it.*

**Kill (Gate A only):** α stays 0 **with farm+bag vision** AND τ<~0.3 (≈ CL-033 unchanged) → cleanest possible evidence to **accept the classical ceiling and pivot to the analyzer**. Do **not** scale this representation. A Gate-B (search-screen) failure with Gate A passing does **not** trigger this kill — it goes to Step 2 eyes-open.

> **This is the branch point. Gate A α>0 → run Step 2/3 AND launch Step 7 stage-1 (bot port) in parallel (its trigger is exactly this). Gate A α=0/τ<0.3 → §12 endgame 2 (analyzer).**

---

## Step 2 — The net-value leaf, weaned *(pilot = days → full run 2–4 wks; full cluster; Step 1 PASSED Gate A)* — **the decisive experiment**

**Hypothesis:** with a sighted representation **and** a regime that *forces* the net value to be the value function, the loop produces a net that exceeds the **v2.9** heuristic in games at equal compute.

**Reference leaf = v2.9 everywhere (NOT v2.7).** v2.9 (Bmild_cap8, hash `7fc930b82801cb43`) is the strongest classical leaf and is already the Step-1 teacher/ruler. The heuristic we anneal *out*, the warmstart/teacher target, and the eval ruler are all v2.9 — beating v2.7 while still below v2.9 would be a hollow win. (The production champion checkpoint was selected under the older `virtual_score_v2`; that's lineage history, irrelevant to what Step 2 weans off.)

**Execution shape (LOCKED 2026-06-29 — cost-disciplined; turns "one 4-week commit" into pilot-gates-full):**
1. **Primitives first (hard gating dependency).** The substrate (input width) is baked in at warmstart and FIXED for the whole run — changing a primitive mid-run = re-warmstart = restart. So the primitive list must be LOCKED before warmstart. This is the real critical path; everything expensive sits behind it.
2. **Warmstart the value head on h6400_v2.9 DEEP-SEARCH targets** (the 10,067 sibling-set oracle_q we already have from Step 1), **NOT** on the static v2.9 leaf. Starts the value at *deep-search quality* instead of *static-heuristic quality* → it does not begin anchored to the ceiling we're trying to beat. (Warmstarting on the static leaf is the subtle trap that bakes the ceiling in.) Warmstart the prior strongly (so self-play isn't random), the value more lightly (let the loop move it).
3. **Pilot gates the full run.** Run a SHORT cheap pilot (~8–12 iters, fewer games/iter, lean eval) purely to read arm B's **derivative**. Positive/recovering slope → scale to the full 30–50 iter run. Craters and stays flat → **kill in days, not weeks.** Explicit early-kill: by iter ~8–10 arm B must be climbing back toward arm A from its wean dip.
4. **Eval split (the weeks live here — lean it down):** **in-loop progress screen = lean + frequent** — a cheaper heuristic (h1600/h3200, calibrated to where our nets sit — pull the rodv2-iter-N-vs-hX numbers from results.csv to set it), or a frozen-net anchor (net-vs-net is far cheaper than vs a 6400-sim search), or the low-sim **Ameneyro** opponent (cheap AND circularity-free). **Promotion/verdict = h6400_v2.9 + the ≥2σ paired test, run seldom** (only on candidates that clear the cheap screen). ~3–5× eval-cost cut.
5. **2-arm design isolates the variable** (below) so a win is attributable to the *wean*, not a confound — we are NOT rolling all changes into one undifferentiated run.

**Code to build** (knobs that are NOT yet plumbed — launcher is `scripts/rod_v2/run_rod_v2_flywheel.sh`, gen `scripts/rod_v2/gen_flywheel_v29.sh`, trainer `scripts/train_iter.py`, self-play `scripts/run_selfplay_iter.py`):
- **Residual-scale annealing high→0:** make `CARCASSONNE_V25_RESIDUAL_SCALE` (already read by `src/carcassonne_ai/evaluators.py` `make_v25_value_wrapper`) a **function of iteration index** in the launcher loop (currently static `SCALE=0.25`). No new blend math.
- **Leaf dropout:** new logic in `evaluators.py` (`make_v25_value_wrapper` + batched variant) — with prob *p*, skip the heuristic `h` and return pure `v_nn` at the leaf. New env var e.g. `CARCASSONNE_V25_LEAF_DROPOUT`.
- **De-saturated value target:** use the **existing** `--value-target score_diff_wide` (tanh/40). (W/L+BCE is a fallback; BCE is not implemented — `score_diff_wide` is the cheap path.)
- **Real exploration:** raise dirichlet noise fraction toward **~0.53** and widen the temperature window (defaults today: `dirichlet_alpha=0.3`, `dirichlet_eps=0.25`, `temp_threshold=15` in `run_selfplay_iter.py`); plumb per-iter.
- **Iteration count ~30–50** (an order of magnitude past the iter5 plateau; currently hardcoded `ITERS=13`).

**Design — two arms, same seeds/compute/eval bands (compute-frugal default; Step 1 already settled the representation axis offline):**
- **(A) control:** sighted representation, **fixed** heuristic residual.
- **(B) treatment:** sighted representation, heuristic weight **annealed high→0** + **leaf dropout**.
- *(Optional, if compute allows the cleanest causal read: full 2×2 representation × annealing. The 2-arm is the default for the 3-box cluster.)*

**Cluster discipline:** all 3 boxes work-stealing (memory `feedback_use_all_cluster_boxes`); orch ON at high-W for gen+eval (`feedback_use_orch_for_eval_and_gen`, carc-orch via `rust/carc-orch/run_server.sh`); `git bundle` sync to xeon/laptop first; detach (`setsid`/`nohup`) + `nice -n 19`; pre-launch process census; per-box W = laptop 20 / 5800x 14 / xeon 10 (re-bench after the rep code-era change).

**Success:** arm (B) recovers from initial weakness, shows a **positive slope over several iterations**, beats control (A) on **fresh deck bands**, and any checkpoint **beats `h6400_v2.9` in games at matched compute beyond 2σ** — the first "learned > heuristic at equal leaf," the breakthrough. (Ruler harness: `scripts/rod_v2/run_heur_eval_v29.sh`, `--paired`, `HSIMS=6400`.)

**Kill:** after the pre-registered budget the annealed net-value leaf is still hundreds of elo below heuristic h200, α=0, and full-game slope is flat across **two** deck bands → crutch hypothesis wrong, heuristic is a real ceiling → §12 endgame 2.

---

## Step 3 — Comparator-in-loop *(short; gated on Step 1, runs alongside Step 2)*

**Hypothesis:** CL-034's washout is a one-shot artifact; the comparator might compound if used as a prior/reranker **inside** policy improvement, not as a one-off leaf swap.

**Experiment:** take CL-034's offline-winning ranker (`scripts/feature_graph/{build_feat_dataset,train_eval}.py`) and insert it into a short self-play loop as a prior/reranker vs a compute-matched control loop with no comparator.

**Success:** after several iters, comparator-loop checkpoints beat control **in games** against fixed in-ecosystem rulers (not merely offline). **Kill:** no game edge + root/search metrics repeat the washout → close.

---

## Step 4 — Fair-information value targets *(second-order; gated on a positive signal in Steps 1–2)*

**Hypothesis:** clairvoyant single-future targets poison value learning even though the direct elo gap is small.

**Experiment:** replace true-deck value labels with **fair-information labels** — sampled deck-expectation at roots / chance-node / IS-MCTS targets, or outcomes from non-clairvoyant self-play with the bag histogram (Step 1's C4b planes) as input. Builds on Step 0's determinization-averaging code. `scripts/clairvoyance_gap.py` (`--mode nonclair --K …`) already isolates the clairvoyance delta.

**Success:** value calibration / sibling ranking improves vs fair/exact labels, and the value transfers to fair-information play **without losing the ~25-elo clairvoyance discount**. **Kill:** no improvement → keep clairvoyance as a deployability/claim issue, not a modeling priority. **Do NOT rebuild as MuZero** — rules and bag are known; a determinization-correct MCTS with explicit bag inputs is cheaper and more diagnostic.

---

## Step 5 — Modern AZ sample-efficiency *(accelerant, only after Steps 1–2 show a positive derivative)*

**Hypothesis:** Gumbel AlphaZero (guaranteed low-sim policy improvement), playout-cap randomization, and auxiliary ownership/component targets make the brittle sims=200 regime less brittle. (`aux_targets.py` ownership infra already exists — extend as an aux head; `train_iter.py` already has `--aux-weight`.)

**Experiment:** add to the representation-correct net-value loop vs a non-Gumbel control. **Success:** same compute → faster improvement + better game strength than control. **Kill:** base loop has no positive derivative → don't spend here.

---

## Step 6 — Scale *(only after a small loop clears its gates)*

**Hypothesis:** scale is required, but only once the loop is pointed the right way.

**Experiment:** one **5–10× scale-up** (games/iter, iterations, possibly capacity) after the small loop passes its pre-registered gates. **Success:** scaling improves **slope**, not just final noise; the larger run beats the small run and fixed rulers on fresh bands. **Kill:** same α=0 / no value usefulness / no ruler gain → stop claiming compute is the missing piece. **Scale on the crutch architecture only distills the heuristic faster — a red herring until Steps 1–2 succeed.**

---

## Step 7 — External / human anchor *(DEFERRED — named track, signal-gated)*

**Per the scope decision: do NOT start until Step 1 returns α>0 OR Step 2 shows a positive slope.** (Charter says "parallel from day one"; we defer to avoid building an anchor for an agent the gates may kill first. It gates the *superhuman claim*, never *progress* — Steps 1–6 are fully measurable in-house against `h6400_v2.9` without it.)

When triggered, staged cheapest-first:
1. **Port one out-of-ecosystem bot** — `SamuelScheit/carcassonne-ai`, `Carcassython`, or the Ameneyro-2020 chance-node baseline. Not a human anchor, but breaks the v2.7-family ecosystem and reveals overfitting. Days–weeks, no human data.
2. **Expert-annotated position suite** — 100–300 positions stratified by phase / farms / meeple scarcity / city closure / tile-counting; strong humans choose+rank+explain. Feeds the analyzer directly.
3. **Online human logs** — only if ToS-clean (BGA exports/permissions/volunteers; **do not scrape against platform rules**).
4. **Direct expert matches last** — fair-information deployable agent (not clairvoyant search); report CIs.

---

## Settled — DO NOT re-run (charter §3)

Re-running these burns compute and re-confirms the confound. Policy distillation (deepteacher CL-019, hard-policy-repair CL-030, high-gap CL-031, value/search autopsy CL-032 — dead at sims=200 inside the crutch); v2.8/v2.9 leaf tuning (real classical gains, **stop tuning the heuristic** except as a reference/teacher — every win deepens the crutch); symmetry aug, c_puct/leaf-cap eval-time tuning, the ML compute scheduler (CL-035, captured by a one-line heuristic); exact/deeper endgame as a *win* lever (outcome-neutral — keep only for value-calibration/analyzer); and "root/offline metrics predict game strength" (they don't — which is exactly why offline screens are **gates, not final kills** for in-loop candidates).

---

## Methodology guardrails (keep live throughout — charter §11)

- **n-discipline:** n=400 paired ≈ ±17.5 elo (1σ); **+20 elo is NOT resolvable at n=400** (need 2σ ≈ ±35 elo). Power-escalate ambiguous z∈[1.5,2.5]. Same-band paired comparisons compose; cross-band stack noise. A lone >1σ spike vs neighbors is noise, not a peak.
- **Gate on GAMES, not root/offline metrics** (four-times-burned rule). Offline screens are gates, not final kills.
- **Margin ≠ winrate.** For "beats humans," match outcome is the strength signal; margin is diagnostic/training only.
- **Keep distinctions sharp:** clairvoyant vs fair-information; in-ecosystem ruler vs human-anchored; strongest *practical* agent vs optimal/superhuman.
- **Allow sub-heuristic runs** in Step 2 — the canonical AZ value path requires the net onto the learning path while still weak; budget for the initial dip.
- **One-retrain discipline; batch 256; provenance** (E6 clean-ruler era; runtime-verify leaf identity + residual firing via `eval_provenance.py`; 1e9 seed floor; deck hashes; both agents' full effective config in each `manifest.json`).

---

## Program-level decision rule (charter §10)

**Abandon AZ-style self-learning** and commit to the classical program (v2.9+ deep heuristic MCTS + exact/endgame handoff + adaptive-compute efficiency + analyzer + human-anchored eval) **iff BOTH:** (a) Step 1 fails (α=0, τ<~0.3, post-search-residual gates fail *with* farm+bag planes); **and** (b) the weaned Step 2 fails (can't reach parity in games after ~20–30 iters, flat slope across two bands). If (a) passes but (b) fails: value can rank but can't drive search — keep the analyzer, representation was the issue. **Do NOT abandon on the basis of *more of what's already been done*** (another policy flywheel, another offline screen vs the heuristic-as-incumbent, more scale on the crutch — all the same experiment, all say α=0).

---

## Verification

- **Per step:** the pre-registered success/kill gate above is the test — each is a measured number (τ, α, paired-z vs `h6400_v2.9`), written to `experiments/results.csv` with a per-run `manifest.json`.
- **Step 1 plane build:** `pytest tests/test_v29_variants.py`-style bit-identity test (leaf unchanged with planes off) + a `board_repr` shape/round-trip test must pass before any retrain. `tests/test_measurement_infra.py` stays green.
- **Step 2 loop:** confirm the leaf actually reaches the MCTS search leaf at the annealed scale (runtime-verify via `eval_provenance.py` / the R1/R7 guards, as the RoD v2.8 probe did at `run_selfplay_iter.py:354`); verify worker parallelism with `ps -o %cpu` immediately after launch; pre-flight smoke at production knobs.
- **Program:** the §10 decision rule is the end-to-end verdict. Either endgame is a real result (§12): ignition → scale + anchor; ceiling confirmed → ship the analyzer.

## Two honest endgames (charter §12)

1. **Steps 1–2 succeed** → a learned component exceeds the heuristic at equal leaf; question becomes scale (Step 6) + human anchor (Step 7) for the superhuman claim.
2. **Steps 1–2 fail the gates** → the heuristic is a genuine ceiling at this scale → **ship the analyzer** (the original Phase-5 win condition, shippable on current classical strength, served by the §9.2 expert-position suite). Neither is a failure; the current framing's mistake is treating endgame 2 as a forced loss when endgame 1 was never attempted.

**Epistemic status:** two independent reviewers converging raises confidence but is not proof — they may share a blind spot. The team's α=0 results are genuinely strong; the steelman for "real ceiling" is that Step 1 also returns α=0 *with* farm+bag vision, which is exactly why that is the pre-registered kill criterion. Let the gates, not the agreement, decide.
