# C — The Experiment Record (Phase-2 material)

> **Do not read before completing Phase 1** (your blind diagnosis from A + B + code).
>
> This is the complete factual history. **FACT** columns are measured numbers (each citing a row in
> [sources/results_csv_relevant_rows.csv](sources/results_csv_relevant_rows.csv) or a verdict doc in
> [sources/](sources/)). **"Team's call"** is the team's interpretation — recorded for completeness,
> *not* to be inherited. Stats reminder: deck-paired; n=400 ≈ ±17.5 elo (1σ); n=100 ≈ ±35.

---

## C.1 Corrections & audits that gate everything (trust base)

| date | event | detail |
|---|---|---|
| 2026-05-29 | engine farm-connectivity bug fixed | farmer adjacency was non-bijective → farm regions start-dependent (~2.2% of games nondeterministic) |
| 2026-06-02 | 6-agent foundational audit ([sources/foundational_audit_2026-06-02.md](sources/foundational_audit_2026-06-02.md)) | found 2 live data-corrupting bugs, both fixed same day: **C1** farm scoring double-counted cities (~17% of farms over-scored → corrupted reward + leaf) and **C2** MCTS transposition visit double-count (~20% of decision nodes → corrupted every policy target). Also named architectural caps: value never in the search loop; representation blind to farm connectivity + bag; saturated `tanh(diff/15)` target; no symmetry aug; advisory (non-rejecting) promotion gate |
| 2026-06-02 | River dropped; base-only reframe | all pre-June "River-era" numbers demoted to historical |
| 2026-06-07 | clean-eval audit | runtime evaluator-provenance guards + 11 semantic contracts; several historical claims re-judged/invalidated |
| ongoing | results discipline | every eval writes a manifest; results.csv is the source of truth; deck-pairing standard |

## C.2 The hand-crafted leaf kept improving (classical line)

| date | leaf | change | FACT | team's call |
|---|---|---|---|---|
| 2026-05-14→17 | v2.5 → v2.7 | closure-anticipation + caps + dedup fixes, hand-tuned | became the production leaf & the baseline of everything | "strong-human by construction" |
| 2026-06-22 | **v2.8** | turn ON the flat meeple-economy term (`k=2`) | heur +179.5 elo @200 / +94.9 @800; `v28@200` beats `v27@800` (+202.6); lifts the neural agent too: `iter8+v2.8` vs `iter8+v2.7` **+154.5 (z9.8)** | real, large classical gain; "raises the floor for everyone" |
| 2026-06-25 | **v2.9** | nonlinear meeple "liquidity curve" (Bmild) + cap 5→8 | vs real v2.8 production config: **0.579 wr / +55 elo / z+3.94**, depth-robust | another real classical gain; not promoted (production stays v2.7) |

Note: the v2.8 term was **bit-identical to a legacy knob that had been OFF since v3** — killed
weeks earlier by an n=20 screen later shown to be noise.

## C.3 Self-play / flywheel attempts (games are the metric)

| date | run | FACT | team's call |
|---|---|---|---|
| 2026-05 | warmstart + recipes v1–v6 | NN-value-as-leaf self-play plateaued; a pure net-value leaf scored ~**−800 elo**; switching the leaf to the v2.7 heuristic was the breakthrough | net value catastrophic as sole leaf |
| 2026-06-07 | residual flywheel #1 (3 iters) | +14.3 elo cumulative (within noise) | no flywheel |
| 2026-06-10 | **residual flywheel #2 → champion `iter8`** | vs incumbent **+67.4 / z2.73** (sealed out-of-lineage ruler, n=400); vs `heur@800` **+58.7**; decomposition: ~95% of the gain is **policy**, residual-value contribution static ~+22, plateau by iter5 | real but bounded; still production champion today |
| 2026-06-11→17 | deepteacher (sims-800 teacher, 12 iters) | iter12 vs iter8 = **TIE** (+14.6 @s200 / +12.4 @s800, z<1) | deeper policy teacher doesn't help |
| 2026-06-19 | ladder placement of iter8 | `iter8` vs heur ladder, same band: **+40.1 @800 → +24.4 @1600 → −28.7 @3200** | learned edge erased by deeper heuristic search |
| 2026-06-22 | **RoD** — continuation on the v2.8 leaf | `RoD_iter_01+v2.8` vs frozen parent `iter8+v2.8`: **+53.4 / z3.51** — the first continuation ever to beat its parent; vs `heur@3200+v2.8` (equal leaf, n=800): winrate +16.5 / margin −0.36 = **parity** | the stronger leaf unstuck a real gain, but only *to* parity with deep search, not past it |
| 2026-06-23 | v2.8 overnight flywheel (16 iters) | best iter (08): +33.1/z2.0 internal, but vs `heur@3200+v2.8` (n=800) **+6.5/z0.53 = TIE**; tail iters no better | internal gain washed out vs the external ruler |
| 2026-06-24 | deeper-search ruler probe | `h6400` beats h3200 on margin (z+2.61); **RoD_iter_01 LOSES to h6400 (−45.4, z−3.24 margin)**; h12800 > h6400 on margin | heuristic depth ladder not saturated; adopt h6400 as reference |
| 2026-06-24 | exact endgame hybrid (solver plays last K tiles) | Δmargin scales with K (+0.65 K2 → +1.94 K4) but **winrate NS at every depth** | margin-sharpening, outcome-neutral |
| 2026-06-27 | **RoD v2** — continuation on the v2.9 leaf (5 iters) | every iter LOSES to `h6400+v2.9` (−22…−32), no climb; root audit: policy prior diffuse, value-head corr flat | "the v2.9 leaf swap changed nothing; stop the blind flywheel" |

## C.4 Learned-component pilots (mostly offline; sibling-ranking vs the h6400 teacher)

| date | pilot | FACT | team's call |
|---|---|---|---|
| 2026-06-19 | value-ranking kill-test (CL-021) | learned value/rankers rank siblings at τ≈0.03–0.10 vs the leaf's τ≈0.58–0.895 | value inert |
| 2026-06-27 | value/search autopsy (CL-032) | value residual scale 0/0.25/0.5 indistinguishable at the root; classical h200 agrees with h6400 **0.911** vs production neural 0.799; yet **in games** classical-vs-neural at matched compute = NS (z−1.19, slight lean *neural*) | root metrics don't predict game strength (4th such instance) |
| 2026-06-28 | value resurrection (CL-033) | best blend α=**0** for every variant; net-alone τ peaked 0.105 vs leaf 0.895 | value stays inert vs the v2.9 leaf |
| 2026-06-28 | **feature-graph comparator (CL-034)** | 50 explicit structural/action scalars + linear/listwise ranker: **beats the leaf offline** — held-out regret **−41%** (top1 0.464→0.535, decisive tail −44/−52%) — the first learned object to clear the leaf; **but under MCTS@200** no integration beats plain search (search alone cuts the leaf's decisive regret ~6×; explores every sibling) | "representation, not reweighting" — offline win, washes out under search |
| 2026-06-28 | post-search residual / adaptive compute (CL-035) | escalation signal predictable (AUROC 0.78) but a one-line heuristic captures it; magnitudes tiny | no ML scheduler |
| 2026-06-29 | typed GNN on post-search residual (CL-036) | GNN generalizes worse than a flat MLP; **ablation: zeroing the graph embedding *improves* it** | relational structure inert |
| 2026-06-2x | policy-repair & distillation pilots (CL-030/031) | "hard-state" policy target is signal-free (one-hot memorizes 0.775 train → 0.061 test); high-gap distillation learns + generalizes offline (top1 0→0.18) but **in games −64 elo** vs parent | policy distillation dead as a strength lever |

## C.5 The final arc: representation gates and closure probes (2026-06-29 → 07-01)

*(These came from a pre-registered plan with an explicit decision rule —
[sources/CHARTER_INTEGRATED_REVIEW_PLAN_2026-06.md](sources/CHARTER_INTEGRATED_REVIEW_PLAN_2026-06.md) §10.)*

| step | FACT | team's call |
|---|---|---|
| **Gate A — representation** ([sources/measurement_feature_planes_gate_STEP1_GATE_RESULTS.md](sources/measurement_feature_planes_gate_STEP1_GATE_RESULTS.md)) | Adding **farm-connectivity planes (+3)** and a **bag histogram (+32 scalars)** to the same ranking protocol: regret **−20.5%** vs blind baseline −1.9%, α 0.05>0, τ 0.140→0.207; shuffled-plane negative control collapses to +0.0%/α=0; ablation: farm-only −17.1%, bag-only −19.7% (**largely redundant substitutes**) | PASS — the old "α=0" was partly a representation confound; bag = information the heuristic cannot see |
| **Gate B — the weaned flywheel** (results rows `step2_*`; [sources/DECISIONS_excerpt_CL037_038_039.md](sources/DECISIONS_excerpt_CL037_038_039.md)) | A structure-aware 89-scalar value substrate **ranks well at every tree depth** (interior τ: d1 0.42 / d2–3 0.45 / d4–7 0.43; +43% offline). Weaning it into the MCTS leaf at blend 0.27 **craters games vs its own parent**: convex/MSE wr **0.19 (−246 elo)**, additive-at-full-heuristic-weight **0.28 (−160)**, ranking-objective 0.287, **frozen never-retrained value 0.21 (−225, z−7.5)**; pure-heuristic anchor exactly 0.500 (n=100–172, sims=100 evals) | FAIL, "genuine": three nails exclude distribution-mismatch (τ flat by depth), heuristic-subtraction (additive craters too), retraining-drift (frozen craters). **"Value can RANK but cannot DRIVE search."** Verdict survived an external challenge + 3-round code review (5 bugs fixed; results verified not poisoned) |
| **Probe A — structured value leaf** | 24-dim per-component value emit feasible (2.2–2.7× leaf cost, bit-exact); farm/bag independence on the structured head: Δ_indep = **+0.05pp** vs pre-registered ≥+3pp bar (~8σ below) | killed cheaply; "the residual value signal is genuinely low-dimensional; the scalar wasn't the bottleneck" |
| **Probe B — fair vs clairvoyant value targets** ([sources/measurement_probe_b_4a_PROBE_B_4A_RESULTS.md](sources/measurement_probe_b_4a_PROBE_B_4A_RESULTS.md)) | One-variable-clean (identical datasets except targets), matched depth 800, full n: **all six arms inert (α=0, +0.0%)** — *including clairvoyant* (Gate A's α>0 had required h6400-deep targets) | screen "depth-saturated," inconclusive alone; clairvoyance question deliberately left unresolved. Deliverable: **B1**, a leak-fixed deployable fair-information agent |
| **Probe §5A — tempo third axis** ([sources/measurement_probe_5a_PROBE_5A_RESULTS.md](sources/measurement_probe_5a_PROBE_5A_RESULTS.md)) | gate-zero: naive tempo counts ≥0.72 reconstructible from existing features (dropped); a 10-feature residualized tempo core survives (mean R² 0.28) | **IN FLIGHT at packet time** — 4-arm verdict pending |

## C.6 Where things stand (2026-07-01)

- The team has **closed the "AZ-value" route** (scalar / structured / clairvoyant / fair) — on the
  accumulated ledger of C.4–C.5, per the pre-registered decision rule — and decided to build the
  **analyzer** (the original project's win condition) plus ship **B1**, while stating "fresh
  approaches to superhuman remain open."
- Nothing was ever promoted from any of this: the production champion is still `iter8` (+ the v2.7
  leaf + 0.25 residual), unchanged since 2026-06-11.
- **No human/external anchor has ever been measured.** All strength numbers are internal to the
  heuristic-leaf ecosystem, and (except B1) clairvoyant.
- The owner's request for this review: *"we're at a dead end and I want to see if there's something
  that's been missed the whole time."*
