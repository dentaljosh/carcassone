# KICKOFF — paste this file, in one shot, as the first message to the reviewing agent

> **How to run:** attach `fresh_look_review_20260701.zip` to a fresh session of an AI agent that
> has file access (claude.ai with code execution / analysis enabled, Claude Code pointed at the
> unzipped directory, ChatGPT with code interpreter, etc.), and paste everything below the line as
> the first message. Nothing else is needed; the agent works through all phases autonomously.
> A no-file-access chat cannot run this protocol honestly (the model would see all phases at once).

---

You are conducting an independent, first-principles review of a game-AI project that believes it
has hit a dead end. The full brief is inside the packet — but the packet enforces a **blind-first
protocol via its directory structure**, and your compliance is part of the review's validity:

**Rules (strict, auditable):**
- You may open files ONLY in the order below. Do **not** list, read, grep, or extract anything
  under `phase2/` or `phase3/` before the earlier phase's written output is complete. Your
  tool/read log is the audit trail; reading ahead invalidates the review.
- If the packet is still zipped, extract it fully first — extraction is allowed; *reading* is what
  is phase-gated.

**Step 0 — Orientation.** Read `README.md` and `REVIEWER_PROMPT.md` (top level — they contain the
role, deliverables, and ground rules, and no results).

**Step 1 — Blind diagnosis (phase1/ only).** Read `phase1/A_GOAL_AND_GAME.md`,
`phase1/B_SYSTEM_DESCRIPTION.md`, and **all 11 source files in `phase1/code/`** — actually read
the code, not just the prose; where they disagree, the code is the truth. Then WRITE OUT IN FULL
(as `PHASE1_DIAGNOSIS.md` if you can write files, otherwise verbatim in your reply):
1. every design decision that strikes you as non-standard, risky, or wrong for the stated goal —
   from game-theoretic structure down to encodings, formulas, targets, and constants;
2. your prediction of where this system's strength ceiling comes from;
3. what you would build instead (or change first) at the team's stated resources;
4. the five cheapest measurements you would run first and what each decides.
Do not proceed until this is written.

**Step 2 — Collision with the record (phase2/).** Now read `phase2/C_EXPERIMENT_RECORD.md`, and
dig into `phase2/sources/` wherever you need primary evidence. For each Step-1 suspect, classify:
**(i) fairly killed** · **(ii) tested inadequately** (say what a fair test looks like) ·
**(iii) never tested**. Write this out before proceeding.

**Step 3 — Cross-check (phase3/).** Now read `phase3/APPENDIX_TEAM_SELF_CRITIQUE.md` (the team's
own conclusions and doubts). Identify anything on **neither** your list nor theirs — that is the
most valuable possible output. Then audit the team's two live decisions: closing the "AZ-value"
route, and falling back to the analyzer deliverable.

**Final deliverable — one report** (write `REVIEW.md` if you can write files, else in your reply),
with these sections strictly separated:
- **BLIND DIAGNOSIS** — your Step-1 output, unedited by hindsight.
- **FACTS** — what the record actually establishes (cite `phase2/sources/` files / result rows).
- **THE MISSED THING** — your top 1–3 candidates for what has been missed the whole time; for
  each: the claim, why everything observed so far is consistent with it, and the cheapest decisive
  experiment (design, metric, success/kill criterion, rough cost at their resources).
- **VERDICT AUDIT** — which of the team's kills were fair; which were premature and what exactly
  would reopen them.
- **THE PATH** — a prioritized concrete plan toward superhuman play (with a self-learning flywheel
  if you honestly believe one is available; if not, say so plainly), including how superhuman
  would be *established* given no human-anchored measurement exists yet.
- **STOP RULES** — what evidence should make the team (a) declare the self-learning dream dead for
  good, and (b) declare superhuman reached.

Ground rules: deck-paired head-to-heads; n=400 ≈ ±17.5 elo (1σ), n=100 ≈ ±35; a lone >1σ spike vs
neighbors is noise; offline-ranking and in-game strength have dissociated repeatedly in this
project (both directions) — treat offline→online inference as suspect. Be adversarial about
designs and interpretations, but do not manufacture doubt about heavily replicated measurements.
The goal is a superhuman **agent**; whether any component must be learned is a means-question —
open in both directions. If the honest answer is "nothing fundamental was missed," say so with the
same rigor, and give the best remaining move.

Begin with Step 0 now.
