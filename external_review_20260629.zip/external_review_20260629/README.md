# External Review Packet — Superhuman Carcassonne AI (2026-06-29)

> **What this is.** A self-contained snapshot of an AlphaZero-style Carcassonne AI project,
> assembled for an **outside reviewer** with no prior access to the codebase. The project has
> reached a strong internal conclusion that it is *stuck*. We want you to (a) look for **obvious
> mistakes** in the approach, and (b) suggest **how to move forward toward genuinely superhuman
> play, ideally with a self-learning flywheel**.
>
> **The one thing we are most afraid of: a local minimum.** The team and its AI assistant have
> been steeped in this project for weeks and have converged on a particular story ("the heuristic
> is a ceiling, the learned components are inert, measurement is the blocker, the flywheel is
> closed"). That story may be correct — or it may be the rut we cannot see out of. This packet is
> deliberately built to let you **disagree with us**. Facts are separated from the team's
> interpretations throughout, and [06_ASSUMPTIONS_TO_CHALLENGE.md](06_ASSUMPTIONS_TO_CHALLENGE.md)
> exists specifically to hand you the load-bearing assumptions and invite you to break them.

---

## The 60-second orientation

- **Goal (since 2026-05-28):** genuinely **superhuman** play at **2-player Carcassonne, Base game +
  Farmers** (no River, no other expansions). Aspirationally, beat the world champion.
- **Method:** AlphaZero-style — a ResNet (policy + value) guiding MCTS. **But with a twist that
  matters for everything below:** the MCTS leaf is evaluated by a *hand-crafted heuristic*
  ("v2.7 / v2.9"), not by the network's value head. The network's value head is a small *residual*
  correction on top of the heuristic.
- **Current champion:** `flywheel_residual_attempt2/ckpt/iter8.pt` (a 96×6 ResNet, ~7M params).
  Full config in [sources/PRODUCTION.yaml](sources/PRODUCTION.yaml).
- **Strongest reference / ruler:** deep heuristic MCTS (`heur@3200`, and more recently `h6400`).
  Treated as the *strongest known practical agent*, **not** as ground truth or optimal.
- **The team's bottom line:** the champion is a real but *bounded* gain (~95% policy distillation,
  capped by the heuristic leaf). Every attempt to make a *learned* component **exceed** the
  heuristic has failed or washed out. The team believes two "structural blockers" gate the goal:
  **(1) measurement** (no non-saturated, non-clairvoyant, human-anchored reference exists) and
  **(2) the heuristic-leaf ceiling** (the learned value head is inert against it).

That bottom line is the team's **interpretation**. Your job is partly to decide whether it is
*supported* — and partly to decide whether it is the *right frame at all*.

---

## How to read this packet (in order)

| File | What it gives you |
|---|---|
| [01_GOAL_SCOPE_AND_RULES.md](01_GOAL_SCOPE_AND_RULES.md) | The goal, the mid-project goal change (and the original prompt it overrode), the locked rule scope, and a short Carcassonne primer so the game terms make sense. |
| [02_HOW_THE_SYSTEM_WORKS.md](02_HOW_THE_SYSTEM_WORKS.md) | The actual mechanism: engine, network architecture, MCTS, the heuristic leaf, the self-play loop, the "residual value head" idea. Concrete and factual. |
| [03_WHAT_WAS_TRIED.md](03_WHAT_WAS_TRIED.md) | The chronological arc: leaf evolution (v2.5→v2.9), every flywheel attempt, the six recent "can a learned component beat the leaf?" pilots, and the measurement story. **FACTS vs INTERPRETATION are labeled.** |
| [04_RESULTS_DIGEST.md](04_RESULTS_DIGEST.md) | The load-bearing numbers, each citing a row in [sources/results_csv_relevant_rows.csv](sources/results_csv_relevant_rows.csv) or a verdict doc. |
| [05_THE_TEAMS_CONCLUSIONS.md](05_THE_TEAMS_CONCLUSIONS.md) | The team's current beliefs, stated plainly **and labeled as interpretation**, with how confident the team is in each. |
| [06_ASSUMPTIONS_TO_CHALLENGE.md](06_ASSUMPTIONS_TO_CHALLENGE.md) | **★ The heart of this packet.** The assumptions the whole conclusion rests on, the evidence *for and against* each, where the evidence is thinner than the conclusion, and directions the team has **not** tried. Written to help you escape our local minimum, not confirm it. |
| [REVIEWER_PROMPT.md](REVIEWER_PROMPT.md) | A standalone brief you can paste into a fresh context (human or model). |
| [sources/](sources/) | Primary evidence: the foundational audit, the measurement spec, governance CSVs, the verdict docs for every recent pilot, and a relevant subset of the results table. |

---

## Ground rules we ask you to respect (statistical hygiene)

These are the project's own discipline rules; honoring them keeps your critique on target:

- **n=400 paired ≈ ±17.5 elo (1σ).** A +20 elo effect is *not* resolvable at n=400. A lone result
  that beats its neighbors by >1σ is a noise signature, not a peak.
- **Same-band paired comparisons compose; cross-band ones do not.** Composing elo across different
  deck "bands" stacks noise and has produced phantom effects in this project's history.
- Keep these distinctions sharp: **clairvoyant** (search sees the true future deck) vs
  **fair-information**; **in-ecosystem ruler** (built on the same heuristic leaf) vs
  **human-anchored**; **strongest known *practical* agent** vs **optimal / superhuman**.

But also: **do not manufacture doubt where the evidence is sound.** If a kill was correct, say so.
We want the local minimum broken *only if it is really there*.

---

## Provenance

- Repo branch at packet creation: `rod_v2_flywheel`, commit `6c00fd8`.
- Packet date: 2026-06-29. Every number cites a source file under [sources/](sources/) or a named
  row in the results table. No new experiments were run to build this packet.
- Two earlier packets exist in the repo (`outside_review/` 2026-06-07, `clean_room_review_20260621/`
  2026-06-21) and are **superseded** by this one — a great deal happened in the eight days since the
  last packet (the entire v2.8/v2.9 leaf line, the "RoD" continuation that *beat its parent*, and
  six learned-component pilots). Where this packet and the older ones disagree, **this one wins.**
