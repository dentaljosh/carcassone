# 5 — The Team's Current Conclusions (all INTERPRETATION)

Everything in this file is the team's **reading** of the facts in files 03–04. It is stated plainly
so you know exactly what we believe — and so you can attack it. Each carries the team's own
confidence. **Treat none of it as established for the purpose of your review.**

## 5.1 The five load-bearing beliefs

**C1 — The champion is a real but *bounded* gain.** `iter8` is a genuine, significant strength gain
over its incumbent (+67.4 / z2.73 on a sealed out-of-lineage ruler), but the gain is **~95% policy
distillation, capped by the v2.7 heuristic leaf** — not a ceiling break, not superhuman.
*Team confidence: high.*

**C2 — Blocker #2: the learned value head is inert against the heuristic leaf.** Across the residual
flywheel, deepteacher, and six dedicated pilots, no learned value/ranking formulation beats the leaf
at sibling ordering (optimal blend weight α=0; net τ ≤ 0.10 vs leaf τ ≈ 0.90). The one offline win
(the feature-graph comparator, −41%) washed out under search. *Team confidence: high (with one
asterisk — see C5 and file 06).*

**C3 — Learned gains wash out under search.** Improvements measured at the leaf or at low sims
shrink toward zero at play depth (deepteacher +82@200 → +8@800; the comparator's offline win → none
under MCTS@200). The mechanism: MCTS at 200 sims already explores every sibling and extracts the
decisive move from the existing prior, so improving leaf-level ranking is redundant. *Team
confidence: medium-high.*

**C4 — Root/offline metrics do not predict game strength.** Four times now, a clear root-level edge
(value τ, policy agreement, oracle regret removal) produced **no** edge in full games at matched
compute. The team's rule: **gate on games, not on root metrics.** *Team confidence: high.*

**C5 — Blocker #1: measurement gates the superhuman *claim*.** Every elo is clairvoyant and
in-ecosystem (v2.7-family leaf). The strongest reference (deep heuristic search) is not optimal and
not human-anchored. "Beats expert humans" is unmeasurable without external/human data, which the
team lacks. *Team confidence: high that it gates the claim; **uncertain** whether it gates progress.*

## 5.2 The resulting strategic stance (as of 2026-06-29)

- **The AlphaZero-style "blind" self-play flywheel is treated as CLOSED for strength.** Decision from
  the RoD-v2 autopsy: "stop the AlphaZero-style blind flywheel; classical v2.9 is the strength."
- **The only gains that still land are *classical* leaf improvements** (v2.8, v2.9) — but these are
  explicitly **not** ML/superhuman levers; they raise the floor for everyone and the learned agent
  still only reaches parity with deep search.
- **The named-but-not-started EV-positive direction** is endgame/exact-solver play — but that, too,
  was measured **outcome-neutral** (beats deep heuristic on score margin, not on winrate).
- **The standing program is "measurement-first"** ([sources/MEASUREMENT_FIRST_SPEC_2026-06-18.md](sources/MEASUREMENT_FIRST_SPEC_2026-06-18.md)):
  build a non-saturated reference, because both strength levers (policy iteration, learned value)
  are believed exhausted.
- **The fallback** named in the project charter is to accept strong-amateur-plus strength and pivot
  to the **analyzer** (the original prompt's Phase 5 win condition).

## 5.3 What the team is *not* claiming (to keep you calibrated)

- Not claiming the agent is superhuman, or even that it beats deep heuristic search.
- Not claiming "no learned value can *ever* work" — only that *the tested formulations at this scale*
  are disfavored.
- Not claiming clairvoyance is a major strength artifact (measured small).
- Not claiming the bugs invalidate later numbers (the two real bugs were fixed 2026-06-02, before
  all the v2.8/v2.9/pilot work).

## 5.4 The question the team cannot answer about itself

> Are we at the genuine frontier of what this approach can do on this game — or have we *defined* the
> problem ("learned must beat the heuristic at sibling ranking, measured in games at sims=200, on an
> in-ecosystem clairvoyant ruler") in a way that makes our own success impossible to detect and our
> own architecture impossible to fix? That is what we want the external review to adjudicate.
