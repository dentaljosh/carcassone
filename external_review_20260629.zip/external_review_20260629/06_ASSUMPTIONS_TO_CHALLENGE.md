# 6 — Assumptions to Challenge (the anti-local-minimum file)

> **Why this file exists.** The team and its AI assistant have spent weeks inside this problem and
> have converged on the story in file 05. This file is built to *help you break that story* if it
> deserves breaking. For each load-bearing assumption we give: the team's evidence FOR, a deliberate
> **steelman of the opposite**, and **what was never actually tested**. The steelmen are *prompts for
> you*, **not** the team's view and **not** necessarily correct — your job is to judge which (if any)
> are real. Where the evidence is genuinely solid, we say so, so you don't waste effort.

---

## Assumption A — "This is AlphaZero, and the heuristic leaf is a *ceiling*."

**FOR.** A pure network-value leaf scored ~−800 elo; the residual (25%) design is what produced the
champion; RoD showed a *stronger* leaf restarts gains — consistent with "the leaf sets the level."

**Steelman of the opposite — the leaf is a *crutch*, not a ceiling.** In canonical AlphaZero the
**network's own value** evaluates leaves and is forced, over millions of games, to *become* the
value function; search bootstraps the value, the value sharpens search. **In this system the value
that drives search is ~the heuristic, and the net value is a 25% passive residual** (file 02, §2.3).
The net is therefore *never required* to learn to evaluate positions — the heuristic always rescues
it. That is exactly the condition under which a value head stays "inert": not because it can't
learn, but because nothing ever makes it. The −800 result was an *early, tiny, pre-bug-fix* run that
flipped the leaf to 100% net at once — **not** a committed from-scratch AZ run with a net-value leaf,
exploration, and enough games. **The team has never run that experiment.** A crutch that makes you
strong on day one and prevents you from ever learning to walk is the textbook local minimum.

**In fairness — what *was* tried:** a **cheap** "value-in-the-loop" retrain (the audit's "Stage B")
and a value-blend probe were run, and both were **worse** (blend at 50% net scored −123 elo). So the
team is not ignorant of F-B1. **But** these were short, warm-started, fixed-representation retrains
that flipped or blended the value in abruptly — not the committed version below.

**Never tested:** a committed, properly-scaled, from-scratch (or long warm-then-*wean*) AZ loop where
the **net value gradually becomes the leaf** (heuristic weight annealed toward 0 over many
iterations), on a **fixed representation that can see farms and the bag** (Assumption B), with real
exploration and a low-variance value target. The abrupt cheap swaps failing is *weak* evidence
against the gradual scaled version — arguably the decisive untested experiment for the whole project.

---

## Assumption B — "The learned value head is inert (it cannot beat the leaf)."

**FOR.** Strong and repeated: α=0 across many formulations, net τ ≤ 0.10 vs leaf τ ≈ 0.90, three
independent pilots converging.

**Steelman of the opposite — it's the *representation*, not the value head.** Two facts cut hard
against the strong reading:
1. **The comparator (CL-034) beat the leaf offline by −41% decisive regret** the moment it was given
   **explicit structural/action features** instead of the raw board encoding — the *first* learned
   object to ever clear the leaf, and it **reversed** the prior "α=0, value hopeless" verdict
   (file 04, §4.5). So "learned value can't beat the leaf" is **false as stated**; the correct
   statement is "the value head *on the current board representation* can't."
2. The 2026-06-02 audit found the net is **structurally blind to farm connectivity and to the bag**
   (the highest-skill, highest-variance axis of the game — file 01, §1.3). A 6-block conv literally
   cannot reconstruct board-spanning fields, and there is **no bag-composition input at all**.

**What was never tested:** the audit's representation fixes were **not** actually built. The
farm-connectivity probe (C4a) was killed by a **~30-minute offline proxy** that used *terminal
ownership planes as an oracle stand-in* and scored *outcome prediction*, not beat-the-leaf — the
team's own notes flag it as "a bet, not a sure thing." The **bag-composition / tile-counting
representation (C4b) was never tested at all.** Tile-counting (which specific tiles remain → exact
completion probability) is *the* thing expert humans do that the heuristic only approximates and the
net cannot represent. **This is the most concrete untested hole in the project.**

---

## Assumption C — "Learned gains wash out under search, so they're irrelevant."

**FOR.** deepteacher +82@200 → +8@800; the comparator's offline win vanished under MCTS@200. Real,
reproduced.

**Steelman of the opposite — the washout is a property of the *test*, not the *game*.** Every
washout was measured by **swapping a learned scorer into the leaf at fixed sims and checking offline
sibling regret or a short head-to-head**. But AlphaZero strength does **not** come from a learned
component beating search *at a fixed position* — it comes from the value/prior **reshaping the
search trajectories themselves, compounded over a self-play loop**. A component that is "redundant
with what 200-sim search already extracts" at a position can still **change which positions get
visited** and **what the policy target becomes next iteration**. The comparator was judged on an
offline screen and **never put back into a training loop** to see if it compounds. "Redundant in a
one-shot screen" ≠ "won't compound in a flywheel." Also: the washout finding has a second reading —
if net gains vanish by sims=800, perhaps **the search is already near the leaf's ceiling at these
depths and the bottleneck is the leaf's value, not the net** (which loops back to A and B).

**Never tested:** integrating the comparator (or any offline-winning learned ranker) as the prior/
value **inside a full self-play retrain** and measuring multi-iteration compounding in *games*.

---

## Assumption D — "Measurement is the blocker (no human anchor → can't progress)."

**FOR.** Genuinely true that "beats expert humans" is unmeasurable in-house; clairvoyant + in-
ecosystem rulers can't certify superhuman.

**Steelman of the opposite — measurement gates the *claim*, not the *work*.** You do not need a human
anchor to detect **"learned component > heuristic at equal leaf in games."** That is measurable today
against the in-ecosystem ruler — and if it ever happened, you'd see it. The project has *never seen
it*, which is a **modeling** result, not a measurement gap. Treating "we lack a human anchor" as the
binding blocker risks using an unfixable-in-house problem as the reason not to attempt the fixable-
in-house modeling work (A, B, C). Moreover, **external anchors do exist and were never pursued**:
online Carcassonne platforms (e.g. BoardGameArena) with ranked 2-player logs, public/academic
Carcassonne bots that could be ported as out-of-ecosystem opponents, and expert-annotated positions.
The team called the human anchor "weeks of data acquisition" and deferred it indefinitely.

**Never tested:** any out-of-ecosystem opponent (a non-v2.7 bot), any human/online game corpus.

---

## Assumption E — "Scale isn't the unlock; the runs are representative of the method's ceiling."

**FOR.** Symmetry augmentation was a clean null; several scale-adjacent knobs were flat.

**Steelman of the opposite — the runs are *tiny* and may simply be under-fueled.** ~7M params,
hundreds-to-~1200 games/iter, fewer than ~20 iterations, on a consumer cluster. AlphaZero-class
results used **orders of magnitude** more games, parameters, and iterations. The team's own
flywheels "plateau by iter5" — but iter5 is *nothing* by AZ standards; a real flywheel's interesting
behavior is often hundreds of iterations in. "Plateau at iter5" and "the method is exhausted" are
very different claims. The team **asserts** "scale is not the unlock" but the decisive scaled run
(bigger net + many more games + many more iters, with a net-value leaf per A) was **never run** —
partly because of (justified) compute-cost discipline.

**Never tested:** a meaningfully larger net and/or a much longer flywheel; whether the iter5 plateau
moves with capacity or data volume.

---

## Assumption F — "Clairvoyance is a settled, minor issue."

**FOR.** The clairvoyance *strength* gap was measured at ~+27 elo, z−0.9 (not significant). Fair.

**Steelman of the opposite — clairvoyance is settled for *search strength* but not for *value
learning* or for *the goal*.** Carcassonne is an imperfect-information game; the bag order is hidden.
The system searches the **true future deck** and trains value on **single-determinization** targets,
which (the audit notes) "encode unlearnable information the net can't see" and inflate value-target
variance. The project has **no chance-node search and no information-set treatment** — the entire
modern toolkit for stochastic/imperfect-information games (information-set MCTS, perfect-information-
Monte-Carlo done right, **Stochastic MuZero** which *learns* the chance dynamics) is unused. A
superhuman *human-facing* agent must also play **without** seeing the future deck; the deployable,
non-clairvoyant agent was never built. It is at least possible that the "value head can't learn"
wall is partly "the value target is clairvoyant noise the net is structurally forbidden from
predicting."

**Never tested:** any imperfect-information-correct search; a deployable non-clairvoyant agent;
MuZero-style learned dynamics over the bag.

---

## Assumption G — "Stop the flywheel; classical is the strength."

**Steelman of the opposite — the team stopped right after the first positive signal.** RoD was the
**first continuation in the entire project to beat its parent** (+53.4 / z3.51) and the first leaf
change to **restart compounding** — and the response was to confirm it only reached *parity* with
deep search and then declare the flywheel closed. A positive derivative was met with a stop. Reaching
*parity with deep heuristic search at equal leaf* using a 200-sim policy net is arguably a *milestone
that argues for pushing the same direction harder* (bigger net, more iters, a net-value leaf, a
better target), not for stopping. The "blind flywheel is closed" decision may be over-fitting to a
sequence of *small, short, under-powered* runs.

---

## Quick map: directions the team has **NOT** committed to (for your menu, not as recommendations)

1. **A from-scratch / wean-off AZ loop with the net value as the leaf** (Assumption A) — the missing
   canonical experiment.
2. **Bag-composition + farm-connectivity input planes** and a real (not proxy) test of whether they
   let the value head beat the leaf (Assumption B).
3. **Re-inserting the offline-winning comparator into a full self-play retrain** to test compounding
   (Assumption C).
4. **An out-of-ecosystem / human-anchored opponent** — port a public Carcassonne bot, or pull online
   ranked logs (Assumption D, reviewer question F).
5. **A meaningfully larger net and/or a 10× longer flywheel** (Assumption E).
6. **Imperfect-information-correct search** (IS-MCTS / determinization done right) and/or a
   **MuZero-style learned model** of the bag (Assumption F).
7. **Modern AZ sample-efficiency tricks** — e.g. **Gumbel AlphaZero** (strong policy improvement at
   *low* sims, which directly attacks the "sims=200 / washout" regime), KataGo-style auxiliary
   targets and playout-cap randomization.
8. **Deep search at play time** — superhuman agents aren't capped at 200 sims; what does the agent do
   at sims=3200+ with a value head that scales?

## Quick map: levers the team believes are genuinely dead (challenge only if you think the kill was premature)

- **Symmetry augmentation** — clean A/B null (net already encodes rotation). *Solid.*
- **c_puct / leaf-cap eval-time tuning** — flat at proper n; one famous noise-spike. *Solid.*
- **Policy distillation from a deeper teacher** (deepteacher; high-gap distillation) — learnable but
  does not convert to game strength. *Strong, but note it's all at sims=200 and within the same
  crutch architecture.*
- **An ML "when to search deeper" scheduler** — a one-line heuristic captures the signal. *Solid as a
  strength lever; possibly useful for efficiency.*
- **Deeper exact-endgame play** — beats deep heuristic on margin but is **outcome-neutral**. *Solid.*

---

## The one-paragraph challenge we most want answered

If the heuristic leaf is a **crutch** (A) rather than a ceiling, and the value head is starved by a
**blind representation** (B) and **never forced to drive search** (A) and **judged by a one-shot
offline screen instead of in-loop compounding** (C), then *every* "the learned component is inert /
washes out" result in this packet could be **a consistent artifact of the same design choice** —
and the project's central conclusion would be wrong in a way that is invisible from inside it. We
are not claiming that is the case. We are asking you to determine whether it *could* be, and what the
cheapest experiment is that would tell us either way.
