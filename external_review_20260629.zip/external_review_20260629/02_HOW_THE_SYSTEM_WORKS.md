# 2 — How the System Actually Works

This is a factual description of the mechanism. Numbers come from the codebase
(`src/carcassonne_ai/`) and [sources/PRODUCTION.yaml](sources/PRODUCTION.yaml). No editorializing
here — the critique lives in files 05 and 06.

## 2.1 Engine

A vendored, patched fork of the open-source `wingedsheep` Carcassonne engine provides rules,
legal-move generation, and scoring. The team patched several real bugs in it (tied-feature scoring,
a farmer-adjacency/farm-connectivity bug, numpy 2.x, headless operation) and added fast paths
(in-place state mutation for rollouts, an `open_positions` adjacency tracker). Two **training-data-
corrupting** bugs found in the 2026-06-02 audit were fixed then (see §2.6).

## 2.2 Network

A **96-channel × 6-block ResNet, ~7M parameters** (`network.py`). Production config:
`value_global_pool=False`, `n_scalar_features=12`.

- **Input:** a spatial board tensor over a **25×25 window** (centered on the growing board; the
  engine grid is 35×35) with ~78 channels encoding, per cell: the tile's 4 edge terrains (city /
  road / grass / none, one-hot per side), placed meeples by player and type (normal / farmer), and
  an occupancy mask. Plus **12 scalar features**: both players' free-meeple counts, both running
  scores, score/meeple differences, deck size, player index (normalized).
- **Action space: 2511 actions.** 625 board positions × 4 rotations = 2500 tile placements, + 1
  tile-phase pass, + 5 normal-meeple slots + 4 farmer-corner slots + 1 meeple-phase pass.
- **Heads:** policy head (1×1 conv → flatten → concat scalars → dense → 2511 logits, masked to
  legal moves at inference); value head (1×1 conv → flatten → concat scalars → dense → `tanh` ∈
  [−1, 1]); plus a **training-only auxiliary ownership head** (per-cell city/road/farm ownership
  prediction, used as representation pressure).

## 2.3 The MCTS

Standard PUCT MCTS (`mcts.py`). Production play plane: **sims=200, c_puct=3.0**. Root Dirichlet
noise for exploration; temperature τ=1 for the opening then greedy. Transposition table keyed by
board string (with a fix for rotationally-symmetric tiles that used to double-count, §2.6).

**Crucial detail — what evaluates a leaf.** In production self-play and play, the value of an MCTS
leaf is **not** the network's value head. It is a **hand-crafted heuristic** called
`virtual_score` ("v2.7"), with the network's value head added only as a small *residual*:

```
leaf_value = tanh( virtual_score(state, player) / 15 )  +  RESIDUAL_SCALE · v_net
             \_______________ the heuristic ______________/    \__ residual __/
RESIDUAL_SCALE = 0.25   (the network value contributes a 25%-weight correction)
```

So the **policy** is the network's; the **value that drives search is ~the heuristic**. The network
value head is a passive correction, not the engine of search. (This is by design — see §2.5 — and
is central to the review questions.)

**Search is clairvoyant.** The MCTS descends the *true* future tile order. There are no chance
nodes. A `fair_chance` (single-determinization) mode exists but is unwired in production.

## 2.4 The heuristic leaf (`virtual_score`, v2.7 → v2.9)

A de-objectified, union-find implementation (`flat_leaf.py`, `CARCASSONNE_USE_FLAT_LEAF=1`, bit-
exact to and ~2.3× faster than the object version). It computes, for the player to move:

1. **Base score diff** — current points + a finish-the-game estimate (flood-fill each city/road/
   farm component, count points per placed meeple), minus the opponent's.
2. **Closure-anticipation bonus** — for each placed meeple on an *unfinished* feature, a
   probability-weighted estimate of the points it will eventually score. Closure probability is a
   step function of the number of open edges (1 open → P=1.0, 2 → 0.5, 3 → 0.25, ≥4 → 0). Farms get
   a bonus per distinct unfinished city they touch. Self bonus capped (`CAP=12`), opponent
   (`OPP_CAP=8`); `DROP_THREE_OPEN=1` treats ≥4-open as unreachable.
3. **Meeple-economy term** — values having more free meeples than the opponent. In **v2.7** this is
   a flat linear term `meeple_k·(my_free − opp_free)` (production uses `meeple_k`); **v2.8** turns
   this term on at `k=2` (a large classical gain, §3); **v2.9** replaces the flat term with a
   nonlinear "liquidity curve" (`Bmild`) plus a tuned cap (`cap8`).

The v2.7 leaf is the product of weeks of hand-tuning and bug-fixing; the team treats it as a
strong-human-level encoding of Carcassonne theory.

## 2.5 The self-play flywheel

One iteration:

1. **Generate** ~200–1200 games of self-play with NeuralMCTS (the config above).
   - **Policy target:** root visit distribution (canonical AlphaZero).
   - **Value target:** configurable — game-outcome margin `tanh(score_diff/15)` by default, or
     MCTS root-Q (`search_value`), or a tree-interior variant. The residual head is trained to
     predict `search_Q − heuristic_leaf` (the "residual" target).
2. **Train** the ResNet on a sliding window of recent iterations (policy cross-entropy + value MSE
   /ranking + the auxiliary ownership loss). Batch 256, ~3 epochs, Adam.
3. **Gate / promote.** Compare the new net to the incumbent (and/or to a fixed heuristic ruler),
   deck-paired, n≥400, and keep it only if it clears a significance bar. (Earlier loops used an
   *advisory* gate that did not actually reject regressions — a flaw, fixed later.)

**The "residual value head" idea (the attempt-2 champion, 2026-06-05+).** Rather than have the net
predict absolute value (which collapsed — a pure-net leaf scored ~−800 elo), train it to predict the
*residual* between deep search-Q and the heuristic leaf, and add it at 25% weight. This *inherits*
the heuristic's sibling ranking by construction and only nudges margins. It produced the current
champion, `iter8` (+58.7 elo vs a deep heuristic ruler on a sealed panel).

## 2.6 What was audited and fixed (so you can trust the later numbers)

A 6-agent foundational audit on 2026-06-02 ([sources/foundational_audit_2026-06-02.md](sources/foundational_audit_2026-06-02.md))
found two **live correctness bugs** that corrupted training data, both **fixed** that day:

- **C1 — farm scoring double-counted cities** (~17% of farms over-scored) → corrupted both the true
  reward and the heuristic leaf. Fixed by deduping cities by position-set.
- **C2 — MCTS transposition double-counted visits** (~20% of decision nodes) → corrupted every
  policy target toward symmetric placements. Fixed by collapsing aliased children.

The same audit named **architectural caps** that were *not* simple bugs (value head not in the
search loop; representation blind to farm connectivity and the bag; saturated value target; no
symmetry augmentation; advisory gate). Their fate is the subject of [03](03_WHAT_WAS_TRIED.md) and
[06](06_ASSUMPTIONS_TO_CHALLENGE.md) — and not all of them were actually closed.

## 2.7 Scale, for calibration

The runs are **small by AlphaZero standards**: a 7M-param net, hundreds to ~1200 games per
iteration, single-digit-to-~17 iterations per flywheel, on a 3-box CPU/consumer-GPU cluster (a
5900X, a Xeon, a laptop). For reference, the original AlphaZero/AlphaGo Zero used orders of
magnitude more games, parameters, and compute. Whether the team's conclusions reflect *Carcassonne*
or reflect *this scale* is an open question (file 06, Assumption E).
