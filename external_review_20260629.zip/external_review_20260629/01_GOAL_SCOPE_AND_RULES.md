# 1 — Goal, Scope, and a Carcassonne Primer

## 1.1 The goal (and the mid-project pivot)

**Current goal (set 2026-05-28):** build an agent that plays **genuinely superhuman** 2-player
Carcassonne — beat strong/expert humans, aspirationally the world champion.

This **overrode the original project prompt**, which is worth knowing because it shapes how mature
the superhuman target is. The original prompt ([sources/ORIGINAL_PROMPT.md](sources/ORIGINAL_PROMPT.md))
explicitly scoped superhuman play *out* — "This is not a 'build superhuman Carcassonne AI'
project… We're not going to" — and named an **analysis tool** (a "Phase 5" position analyzer /
move explainer) as the actual win condition. The strength work (self-play, MCTS) was meant to be
*good enough to power a useful analyzer*, not to be world-class in itself.

On 2026-05-28 the project owner changed the primary objective to superhuman strength, demoting the
analyzer to a downstream/fallback deliverable. **This is a research-grade goal that the original
prompt deliberately avoided** (the note in the project's own instructions observes that academic
attempts at strong Carcassonne AI since ~2020 have stalled).

> **For the reviewer:** the superhuman goal is ambitious and was adopted *after* the architecture
> and tooling were already built around a more modest target. One legitimate question is whether
> the *system that was built* is even the right vehicle for the *goal that was later chosen*.

## 1.2 Locked scope (do not assume otherwise)

- **2 players** only.
- **Base game + Farmers** (fields). No River, no Inns & Cathedrals, no Abbots, no Big Meeples.
  (River was dropped 2026-06-02; competitive 2-player play is base-only.)
- 72-tile base deck, 7 followers per player.
- The rule scope is intentionally fixed. The interesting difficulty here is *depth of play within a
  small ruleset*, not breadth of rules.

## 1.3 Carcassonne in one screen (so the terms make sense)

Carcassonne is a tile-laying game of **imperfect information** (you don't know the draw order of the
remaining tiles) and **no hidden state** otherwise (the board is fully visible).

- **Tiles & the bag.** Players alternately draw a random tile from a bag and place it adjacent to
  the existing board so edges match (city-to-city, road-to-road, field-to-field). The *composition*
  of the bag is known (it's a fixed deck), but the *order* is random — so completion odds are a
  tile-counting / probability problem.
- **Features.** Tiles build four kinds of feature:
  - **Cities** (walled areas) — score 2 pts per tile (+2 per pennant) when *closed*; 1 pt/tile if
    unfinished at game end.
  - **Roads** — 1 pt per tile.
  - **Monasteries/Cloisters** — 9 pts when fully surrounded by 8 neighbors (partial at game end).
  - **Farms/Fields** — the high-variance, high-skill axis. Scored **only at game end**: a farmer in
    a field scores **3 pts for each completed city that the field touches**. Fields connect across
    the whole board in non-obvious ways, and you cannot place a meeple on a feature already occupied.
- **Meeples (followers).** You have 7. You place one (optionally) on a feature you just built, it
  scores when that feature closes (or at game end), and only then returns to your hand. **Farmers**
  are followers committed to a field — they never come back (fields close only at game end), so
  farm play is a commitment of a scarce resource. **Meeple economy** (how many you have free, when
  they return) is a core strategic lever.
- **Contesting.** Because you can't place on an occupied feature, the way to fight over a city/field
  is to build separately and then *merge* the two parts so you share (or steal majority on) it.
  In 2-player base, mid-game "steal a meeple" plays don't exist; contesting is a tile-placement
  (merge) decision.

**Why this matters for the AI:** the highest-skill, highest-variance scoring (farms) requires
reasoning about (a) board-spanning field connectivity and (b) which cities will *close*, which in
turn depends on (c) what tiles remain in the bag. A model that cannot *see* field connectivity or
bag composition is structurally handicapped on exactly the part of the game that separates strong
from expert play. (Hold this thought — it returns in [06_ASSUMPTIONS_TO_CHALLENGE.md](06_ASSUMPTIONS_TO_CHALLENGE.md).)

## 1.4 What "superhuman" requires here (the team's own framing)

The team argues superhuman play requires the **learned** components to **exceed** the hand-crafted
heuristic that currently carries the agent's strength — because that heuristic is, by construction,
a strong-human-level encoding of known Carcassonne theory, and you cannot surpass expert humans by
distilling an expert-human heuristic. Whether this framing is right (and whether the heuristic is
truly a *ceiling* rather than a removable *crutch*) is one of the central questions for review.
