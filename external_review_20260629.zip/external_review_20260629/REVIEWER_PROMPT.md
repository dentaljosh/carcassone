# Reviewer Prompt — External Review of a Superhuman Carcassonne AI Effort

> Paste everything below the line into a fresh context (or hand it to a human expert) **together
> with this packet directory**. The reviewer should need only this packet and its
> [sources/](sources/) — not the original project history.

---

You are an **independent external reviewer** of an AlphaZero-style game-AI project. The team has
spent weeks trying to build a **genuinely superhuman** 2-player Carcassonne agent (Base game +
Farmers, no expansions), ideally via a **self-improving (self-play) flywheel**. They have reached a
strong internal conclusion that they are **stuck**, and they are worried that this conclusion is
itself a **local minimum** — a rut that they, and the AI assistant helping them, can no longer see
out of.

Your job is **not** to rubber-stamp their conclusion. It is to:

1. **Look for obvious mistakes** — in the method, the experiments, the statistics, the architecture,
   or the framing.
2. **Stress-test the framing.** Treat the team's load-bearing beliefs as **hypotheses to test, not
   facts**: that the hand-crafted heuristic leaf is a "ceiling," that the learned value head is
   "inert," that learned gains "wash out under search," that "measurement is the blocker," and that
   "the AlphaZero flywheel is closed." For each, decide whether the evidence actually supports it,
   or whether it could be an artifact of *how it was tested*.
3. **Chart a path forward toward superhuman play, preferably with a self-learning flywheel** — even
   if that means telling them their current approach is the wrong tree to bark up.

You have been given a self-contained packet. Read it in this order:
`README.md` → `01_GOAL_SCOPE_AND_RULES.md` → `02_HOW_THE_SYSTEM_WORKS.md` → `03_WHAT_WAS_TRIED.md`
→ `04_RESULTS_DIGEST.md` → `05_THE_TEAMS_CONCLUSIONS.md` → `06_ASSUMPTIONS_TO_CHALLENGE.md`.
`sources/` holds the primary evidence (foundational audit, measurement spec, governance CSVs, per-
pilot verdict docs, a results-table subset).

## Context you must hold onto

- **The system is not "pure" AlphaZero.** The MCTS leaf is evaluated by a *hand-crafted heuristic*
  (`virtual_score`, "v2.7"/"v2.9"), and the network's value head only contributes a small *residual*
  correction (scale 0.25) on top of it. The network's value has **never** been the sole driver of
  search in a committed, full-length training run. (See `02_…` §3 and `06_…` Assumption A.)
- **The search is clairvoyant.** MCTS descends the *true future tile deck*; chance/imperfect-
  information is not modeled with chance nodes. The team measured the clairvoyance *strength* gap as
  small (~+27 elo, not significant), but the **value-learning** consequences were never fully closed.
- **The recurring empirical pattern** the team leans on: a learned component can look good on
  offline/root-level metrics yet show no edge in full games at matched compute ("root metrics don't
  predict game strength"), and policy gains measured at low search depth shrink toward zero at high
  depth ("washout"). Decide whether this is a deep truth about the domain or an artifact of the
  evaluation protocol.

## Statistical ground rules (the team's own, please honor them)

- n=400 paired ≈ ±17.5 elo (1σ); a +20 elo effect is **not** resolvable at n=400. A lone >1σ spike
  vs neighbors is noise, not a peak.
- Same-band paired comparisons compose; cross-band ones stack noise.
- Distinguish in every sentence: **clairvoyant** vs **fair-information**; **in-ecosystem ruler** vs
  **human-anchored**; **strongest known *practical* agent** vs **optimal / superhuman**.
- **Do not manufacture doubt where the evidence is sound.** If a lever was correctly killed, say so.

## Answer these, in order

**A. Obvious mistakes.** What is plainly wrong, risky, or non-standard about the approach as
described — architecturally, methodologically, or statistically? Rank by how much it could matter.

**B. The framing audit.** For each of the team's five load-bearing claims (heuristic-is-a-ceiling;
value-head-is-inert; gains-wash-out-under-search; measurement-is-the-blocker; flywheel-is-closed):
is it **established**, **plausible-but-undertested**, or **likely an artifact**? Cite the evidence.

**C. The crutch question.** The heuristic leaf made early iterations strong quickly, but it also
means the value head is never *forced* to become the value function. Is the heuristic leaf a
**ceiling** the team is fighting, or a **crutch** that prevents the flywheel from ever igniting?
What experiment would distinguish these?

**D. The untested holes.** The packet flags several things that were *never actually run* — a from-
scratch net-value-driven AZ loop; a bag-composition / tile-counting representation (only an oracle
*proxy* was tested); a proper imperfect-information / chance-node search; modern AZ variants (Gumbel
AZ, MuZero) and meaningful scale (the runs are tiny by AZ standards). Which of these holes is most
likely to be load-bearing, and which are red herrings?

**E. The path forward.** Give a concrete, prioritized plan toward superhuman play with a self-
learning flywheel. For each step: the hypothesis, the cheapest decisive experiment, the success
metric, and the kill criterion. Be explicit about what you would do **differently** from the team.

**F. The measurement question.** Is "we cannot prove superhuman without a human anchor" a genuine
blocker on *progress*, or only on the *claim*? What is the cheapest credible way to get an external/
human-anchored signal (online-platform self-play pools, public game logs, engine ports of other
Carcassonne bots, expert-annotated positions)?

## Output format — keep these sections strictly separate

- **FACTS** — what the packet's evidence actually establishes (cite `sources/` files / result rows).
- **INTERPRETATIONS** — defensible readings beyond the raw numbers; mark each as such.
- **SPECULATION** — hypotheses not yet tested; label clearly.
- **RECOMMENDATIONS** — your prioritized path (question E), plus your single highest-information next
  experiment and a decision rule for when the team should abandon the AlphaZero approach entirely.

Be adversarial where it matters. If any team conclusion would collapse under a different deck band,
a deeper heuristic rung, a fair-information label, a larger network, a longer run, or a human anchor,
say so explicitly — and say what *cheap* test would expose it. If the team is genuinely at the
frontier of what this approach can do, say that too, and tell them where to spend next.
